let STEP = 50;
var h = (parseFloat(document.querySelector("#drawarea_h").value) / 10);
var w = (parseFloat(document.querySelector("#drawarea_w").value) / 10);


function setup() {
  createCanvas(w, h);
  background(255);
  drawGrid();
  noLoop();
}

function drawGrid() {
  background(255);
  
  // line color
  stroke(202, 220, 199);
  
  // font color
  fill(255, 255, 255);
  
  // draw horizontal lines
  for(let y = 0; y < height; y+=STEP) {
    strokeWeight(1);
    line(0, y, width, y);
    strokeWeight(0);
    text(y+"", 2, y+12);
  }
  
  // draw vertical lines
  for(let x = 0; x < width; x+=STEP) {
    strokeWeight(1);
    line(x, 0, x, height);
    strokeWeight(0);
    text(x+"", x+2, 12);
  }
}

function updatew() {
  resizeCanvas(innerWidth, innerHeight);
  drawGrid();
}

function copycanvas() {
  copy(canvas)
}

