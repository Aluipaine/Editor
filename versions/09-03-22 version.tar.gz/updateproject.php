<?php 
// Include config file
require "vendor/config.php";


// Count total files
$wall = $_POST['wall'];
$room = $_POST['room'];
$step = $_POST['step'];
$settings = $_POST['settings'];
$kokonaisalue = $_POST['kokonaisalue'];


// $meta = mysqli_query($db, "INSERT INTO `projectmeta` (`meta_id`, `id`, `meta_key`, `meta_value`) VALUES (NULL, $id, 'prc_3_email', '$prc_3_email')");

$meta = mysqli_query($db, "UPDATE `projectmeta` SET `meta_value`='$wall' WHERE `id`=$id AND `meta_key`='wall'");

$meta = mysqli_query($db, "UPDATE `projectmeta` SET `meta_value`='$room' WHERE `id`=$id AND `meta_key`='room'");

$meta = mysqli_query($db, "UPDATE `projectmeta` SET `meta_value`='$step' WHERE `id`=$id AND `meta_key`='step'");

$meta = mysqli_query($db, "UPDATE `projectmeta` SET `meta_value`='$settings' WHERE `id`=$id AND `meta_key`='settings'");

$meta = mysqli_query($db, "UPDATE `projectmeta` SET `meta_value`='$kokonaisalue' WHERE `id`=$id AND `meta_key`='kokonaisalue'");


   



 ?>