
<form class="step_screen drawscreen_section form__butsection" action="/updateproject.php" enctype='multipart/form-data' id="drawscreen_section_four">
     </div>
    <input type="hidden" value="drawscreen_section_four" name="step" class="step">
    <input type="hidden" value="" name="wall" class="wall">
    <input type="hidden" value="" name="room" class="room">
    <input type="hidden" value="" name="id" class="id">
    <input type="hidden" value="" name="settings" class="settings">
    <input type="hidden" value="" name="mittapisteet" class="mittapisteet">
    <input type="hidden" value="" name="aukot" class="aukot">
    <input type="hidden" value="" name="reijat" class="reijat">
    <input type="hidden" value="" name="saumat" class="saumat">
    <input type="hidden" value="" name="levyt" class="levyt">
    <input type="hidden" value="" name="rangat" class="rangat">
    <input type="hidden" value="" name="listat" class="listat">
    <input type="hidden" value="" name="kokonaisalue" class="kokonaisalue">
    <input type="hidden" value="" name="levytettava_alue" class="levytettava_alue">
    <input type="hidden" value="" name="poisjaava_alue" class="poisjaava_alue">
    <input type="hidden" value="" name="keskusmittapiste_cord" class="keskusmittapiste_cord">
    <input type="hidden" value="" name="reklamaatiot" class="reklamaatiot">
    <section class="nav">
      <nav>
        <ul>
          <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_three');">Edellinen</div></li>
           <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_one');" class="nav__comleted">Origo</div></li>
          <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_two');" class="nav__comleted">Aukot</div></li>
          <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_three');" class="nav__comleted">Reijät</div></li>
          <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_four');" class="nav_current">Saumat</div></li>
          <li><div onclick="saumoita();refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_five');">Levyt</div></li>
          <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_tyostot');">Kiinnitykset</div></li>
          <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_esikatselu');">Esikatselu</div></li>
          <li><div onclick="saumoita();refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_six');">Rangat</div></li>
          <li><div onclick="saumoita();refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_seven');">Listat</div></li>
          <li><div onclick="saumoita();refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_five');">Seuraava</div></li>
        </ul>

      </nav>

    </section>

  <div class="modal-container">
   <div class="modal-background">
     <div class="modal">
        <div class="modal_close_btn"><svg width="20" height="18" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20 1.87367L17.9857 0.0703049L10 7.21983L2.01429 0.0703049L0 1.87367L7.98572 9.0232L0 16.1727L2.01429 17.9761L10 10.8266L17.9857 17.9761L20 16.1727L12.0143 9.0232L20 1.87367Z" fill="#444444"/></svg></div>
        <h2>Sauma-asetukset</h2>
        <section>
          <h4>Levytyksen suunta</h4>
          <fieldset>
            <input type="radio" id="settings__sauma_pysty" name="sauma__suunta" onclick="saumoitus__examplephoto()" checked>
            <label for="settings__sauma_pysty">Levytys pystyyn</label>
            <input type="radio" id="settings__sauma_vaaka" name="sauma__suunta" onclick="saumoitus__examplephoto()">
            <label for="settings__sauma_vaaka">Levytys vaakaan</label>
          </fieldset>
        </section>
        <section>
          <h4>Saumoituksen tyyppi</h4>
          <fieldset>
            <input type="radio" id="settings__saumahanta-oik" name="sauma__type" onclick="saumoitus__examplephoto()" checked>
            <label for="settings__saumahanta-oik">Häntä oikealle</label>
            <input type="radio" id="settings__saumahanta-vas" name="sauma__type" onclick="saumoitus__examplephoto()">
            <label for="settings__saumahanta-vas">Häntä vasemmalle</label>
            <input type="radio" id="settings__saumahanta-tasoitus" name="sauma__type" onclick="saumoitus__examplephoto()">
            <label for="settings__saumahanta-tasoitus">Pyri tasoittamaan</label>
          </fieldset>
        </section>
        <section>
          <div class="row">
            <div class="col-6">
              <h4>Saumoitus</h4>
              <fieldset style="flex-direction: column;display: flex;">
                <input type="checkbox" id="saumoitus__sauma_one" name="sauma__saumoitus" value="Levytys aukkojen yli" onclick="saumoitus__examplephoto();" onfocus="saumoitus__examplephoto();document.getElementById('saumoitus__sauma_two').checked = false;document.getElementById('saumoitus__sauma_three').checked = false;" checked>
                <label for="saumoitus__sauma_one">Levytys aukkojen yli</label>
                <input type="checkbox" id="saumoitus__sauma_two" name="sauma__saumoitus" value="Pystysaumat aukkojen mukaan" onclick="saumoitus__examplephoto();" onfocus="saumoitus__examplephoto();document.getElementById('saumoitus__sauma_one').checked = false;">
                <label for="saumoitus__sauma_two">Pystysaumat aukkojen mukaan </label>
                <input type="checkbox" id="saumoitus__sauma_three" name="sauma__saumoitus" value="Vaakasaumat aukkojen mukaan" onclick="saumoitus__examplephoto();" onfocus="saumoitus__examplephoto();document.getElementById('saumoitus__sauma_one').checked = false;">
                <label for="saumoitus__sauma_three">Vaakasaumat aukkojen mukaan</label>
              </fieldset>
            </div>
            <div class="col-6">
              <h4>Rakennekuva</h4>
              <img src="/img/levytys-h.png" id="sauma__saumoitus_photo" style="max-width: 100%;">
            </div>
          </div>
        </section>

        <section>
            <h4>Tavoitelu levyn koko  (mm) </h4>
            <!-- <i>Muistathan lisätä +10mm saumaa varten.</i> -->
            <fieldset style="display: flex;flex-direction: column;">
              <label for="settings__sauma_intervalx">Leveys</label>
              <input type="number" id="settings__sauma_intervalx" min="0" step="15" placeholder="numero tähän.." onchange="document.querySelector('#settings__sauma_interval_x').value = this.value" value="1250">
              
              <label for="settings__sauma_intervaly">Pituus</label>
              <input type="number" id="settings__sauma_intervaly" min="0" step="15" placeholder="numero tähän.." onchange="document.querySelector('#settings__sauma_interval_y').value = this.value" value="3000">

              <input type="hidden" id="settings__sauma_interval_x" value="1260">
              <input type="hidden" id="settings__sauma_interval_y" value="3010">
            </fieldset>
        </section>
       <div class="modal_close_btn drawarea__controls_btn" onclick="saumoita();refresh__drawcontrols();updatearea();">Saumoita</div>
     </div>
   </div>
  </div>
</form>


