<form class="step_screen drawscreen_section form__butsection" action="/updateproject.php" enctype='multipart/form-data' id="drawscreen_section_esikatselu">
      <input type="hidden" value="drawscreen_section_tyostot" name="step" class="step">
      <input type="hidden" value="" name="wall" class="wall">
      <input type="hidden" value="" name="room" class="room">
      <input type="hidden" value="" name="id" class="id">
      <input type="hidden" value="" name="settings" class="settings">
      <input type="hidden" value="" name="mittapisteet" class="mittapisteet">
      <input type="hidden" value="" name="aukot" class="aukot">
      <input type="hidden" value="" name="reijat" class="reijat">
      <input type="hidden" value="" name="saumat" class="saumat">
      <input type="hidden" value="" name="levyt" class="levyt">
      <input type="hidden" value="" name="rangat" class="rangat">
      <input type="hidden" value="" name="listat" class="listat">
      <input type="hidden" value="" name="kokonaisalue" class="kokonaisalue">
      <input type="hidden" value="" name="levytettava_alue" class="levytettava_alue">
      <input type="hidden" value="" name="poisjaava_alue" class="poisjaava_alue">
      <input type="hidden" value="" name="keskusmittapiste_cord" class="keskusmittapiste_cord">
      <input type="hidden" value="" name="reklamaatiot" class="reklamaatiot">

      <section class="nav" style="position:relative;">
             <nav>
                <ul>
                   <li>
                      <div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_four');">Edellinen</div>
                   </li>
                   <li>
                      <div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_one');" class="nav__comleted">Origo</div>
                   </li>
                   <li>
                      <div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_two');" class="nav__comleted">Aukot</div>
                   </li>
                   <li>
                      <div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_three');" class="nav__comleted">Reijät</div>
                   </li>
                   <li>
                      <div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_four');" class="nav__comleted">Saumat</div>
                   </li>
                   <li>
                      <div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_five');" class="nav__comleted">Levyt</div>
                   </li>
                   <li>
                      <div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_tyostot');" class="nav__comleted">Kiinnitykset</div>
                   </li>
                   <li>
                      <div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_esikatselu');" class="nav_current">Esikatselu</div>
                   </li>
                   <li>
                      <div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_six');">Rangat</div>
                   </li>
                   <li>
                      <div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_seven');">Listat</div>
                   </li>
                   <li>
                      <div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_six');">Seuraava</div>
                   </li>
                </ul>
             </nav>
          </section>
</form>