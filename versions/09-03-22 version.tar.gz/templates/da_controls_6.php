<div class="drawarea__controls drawarea__controls_six">
   <h2>Rangat</h2>
   <p>Voit hallita ja säätää rankoja asetuksista</p>
   <div class="drawarea__controls_btns taso__btns">
      <fieldset>
         <input type="checkbox" checked id="rangoitus__lvl_one" class="drawarea__controls_btn taso__btns_one" onclick="rangat__navigation();"><label for="rangoitus__lvl_one" class="taso__btns_one">Taso 1</label>
         <input type="checkbox" checked id="rangoitus__lvl_two" class="drawarea__controls_btn taso__btns_two" onclick="rangat__navigation()"><label for="rangoitus__lvl_two" class="taso__btns_two">Taso 2</label>
      </fieldset>
      <div class="drawarea__controls_settingsbtn drawarea__controls_btn m_btn">
         Asetukset
      </div>
      <div class="form-group st_question"><input type="checkbox" name="stjarj" id="stjarj" checked><label for="stjarj">Standard?</label></div>
      <div onclick="move_origo(this);" class="drawarea__controls_origoset">Origo oikealle</div>
   </div>
</div>