<div class="drawarea__controls drawarea__controls_five">
   <h2>Levyt</h2>
   <div class="drawarea__controls_settingsbtn drawarea__controls_btn m_btn">
      Levyjen asetukset
   </div>
   <div class="drawarea__controls_btn" onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_tyostot');">
     Kiinnikenäyttöön
   </div>
   <div class="form-group st_question"><input type="checkbox" name="stjarj" id="stjarj" checked><label for="stjarj">Standard?</label></div>
   <div onclick="move_origo(this);" class="drawarea__controls_origoset">Origo oikealle</div>
</div>
