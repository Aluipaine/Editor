<div class="drawarea__controls drawarea__controls_seven">
   <h2>Listat</h2>
   <p>Voit hallita ja säätää listoja asetuksista</p>
   <div class="drawarea__controls_btns">
      <div class="drawarea__controls_settingsbtn drawarea__controls_btn m_btn">
         Asetukset
      </div>
      <div class="drawarea__controls_settingsbtn drawarea__controls_btn " style="background-color: #FF6B00;">
         Asunnon nimi ja seinä
      </div>
      <div class="drawarea__controls_btn" onclick="refresh__drawcontrols();window.location.href='#drawscreen_section_eight';">
         Seuraava seinä
      </div>
      <div class="form-group st_question"><input type="checkbox" name="stjarj" id="stjarj" checked><label for="stjarj">Standard?</label></div>
      <div onclick="move_origo(this);" class="drawarea__controls_origoset">Origo oikealle</div>
      <div class="kumoa" onclick="console.log('/troll')">Kumoa</div>
   </div>
</div>
