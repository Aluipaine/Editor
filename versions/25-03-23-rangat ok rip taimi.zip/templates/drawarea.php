<section class="row drawarea__section">
    <section class="row levy__section" style="display: none;">
         <?php include('./templates/da_controls_5-5.php'); ?>
      </section>
   <div class="drawarea__section_container">
      
      <div class="drawarea box-wrapper da__mediumscale" id="box-wrapper">
         <div class="drawarea__navigation">
            <div class="wall_prev">&larr;</div>
            <div class="wall_next">&rarr;</div>
         </div>
         <div class="drawarea__mm drawarea__height"><input type="tel" value="<?= $post["room_one_a-h"]; ?>" class="lineinput" id="box_h" onchange="gridify();" max="3650"> </div>
         <div class="drawarea__mm drawarea__lenght"> <input type="tel" value="<?= $post["room_one_a-w"]; ?>" class="lineinput" id="box_w" onchange="changesize__bottom();gridify();" max="9975"></div>
         <div class="drawarea__control drawarea__left">
           <div class="drawarea__left_container">
            <div class="drawarea__h_cord">
               
            </div>
             <div class="box__lower_lowerdecor box__decor" style="left: calc(21px + (-1) * <?= $post["room_one_a-h"]; ?>px / 10);">
               <input class="box__lower_mm lineinput drawarea__boxdecor_mm" value="0" type="number"  onchange="changesize__frominput();">
            </div>
            <div class="box__upper_upperdecor box__decor" style="max-width:  calc(<?= $post["room_one_a-h"]; ?>px / 10);">
               <input class="box__upper_mm lineinput drawarea__boxdecor_mm" value="0" type="number" onchange="changesize__frominput();"> 
            </div>
             <div class="sauma__downctrl_container disabled">
               
             </div>
           </div>
         </div>

         <div class="drawarea__control drawarea__top m_btn" onclick="draw__point();">
            <div class="drawarea__top_item drawarea__top_itemtwo drawarea__top_ovi" onclick="settings__aukko();document.querySelector('#type__door').checked = true;change__aukko_sizecord();">Ovi</div>
            <div class="drawarea__top_item drawarea__top_itemtwo drawarea__top_ikkuna" onclick="settings__aukko();document.querySelector('#type__window').checked = true;change__aukko_sizecord();">Ikkuna</div>
            <div class="drawarea__top_item drawarea__top_itemtwo drawarea__top_palkki" onclick="settings__aukko();document.querySelector('#type__palkki').checked = true;change__aukko_sizecord();">Palkki</div>
            <div class="drawarea__top_item drawarea__top_itemtwo drawarea__top_pilari" onclick="settings__aukko();document.querySelector('#type__collar').checked = true;change__aukko_sizecord();">Pilari</div>
            <div class="drawarea__top_item drawarea__top_itemtwo drawarea__top_ikkuna" onclick="settings__aukko();document.querySelector('#type__ventilation').checked = true;change__aukko_sizecord();">Ilmastointi</div>

            <div class="drawarea__top_item drawarea__top_circle sahkoputki" style="font-size: 10px;align-items: center;background: #eee;" onclick="settings__mitta();document.querySelector('#lapiviennit__sade_muucord').value = this.innerHTML;">27</div>
             <div class="drawarea__top_item drawarea__top_circle" style="font-size: 10px;align-items: center;background: #eee;" onclick="settings__mitta();document.querySelector('#lapiviennit__sade_muucord').value = this.innerHTML;">40</div>

             <div class="drawarea__top_item drawarea__top_circle" style="font-size: 10px;align-items: center;background: #eee;" onclick="settings__mitta();document.querySelector('#lapiviennit__sade_muucord').value = this.innerHTML;">60</div>
             <div class="drawarea__top_item drawarea__top_circle" style="font-size: 10px;align-items: center;background: #eee;" onclick="settings__mitta();document.querySelector('#lapiviennit__sade_muucord').value = this.innerHTML;">85</div>
             <div class="drawarea__top_item drawarea__top_circle" style="font-size: 10px;align-items: center;background: #eee;" onclick="settings__mitta();document.querySelector('#lapiviennit__sade_muucord').value = this.innerHTML;">125</div>

             <div class="drawarea__top_item drawarea__top_circle sahkoputki" style="background: #eee;font-size: 10px;align-items: center;" onclick="settings__mitta();document.querySelector('#lapiviennit__sade_muucord').innerHTML = this.innerHTML;">72</div>

             <div class="drawarea__top_item drawarea__top_circle" style="font-size: 10px;align-items: center;background: #eee;" onclick="settings__mitta();document.querySelector('#lapiviennit__sade_muucord').value = this.innerHTML.replace('IV ','');">IV 110</div>
             <div class="drawarea__top_item drawarea__top_circle" style="font-size: 10px;align-items: center;background: #eee;" onclick="settings__mitta();document.querySelector('#lapiviennit__sade_muucord').value = this.innerHTML.replace('IV ','');">IV 135</div>
             <div class="drawarea__top_item drawarea__top_circle" style="font-size: 10px;align-items: center;background: #eee;" onclick="settings__mitta();document.querySelector('#lapiviennit__sade_muucord').value = this.innerHTML.replace('IV ','');">IV 160</div>

               <div class="drawarea__top_item drawarea__top_circle drawarea__top_custom" style="background: #eee;" onclick="settings__mitta();">x</div>

               <div class="drawarea__top_item drawarea__top_circle drawarea__top_custom" style="border-radius: 0;background: #eee;" onclick="settings__mitta();">x</div>

            <!-- <div class="drawarea__top_item drawarea__top_itemeight m_btn" onclick="document.querySelector('#reclamation__item_first').checked = true; create__reclamation();">Naarmu</div>
            <div class="drawarea__top_item drawarea__top_itemeight m_btn" onclick="document.querySelector('#reclamation__item_second').checked = true; create__reclamation();">Ruuvi puuttuu</div>
            <div class="drawarea__top_item drawarea__top_itemeight m_btn" onclick="document.querySelector('#reclamation__item_third').checked = true; create__reclamation();">Vinossa</div>
            <div class="drawarea__top_item drawarea__top_itemeight m_btn" onclick="document.querySelector('#reclamation__item_fourth').checked = true; create__reclamation();">Tukiranka näkyvissä</div>
            <div class="drawarea__top_item drawarea__top_itemeight m_btn" onclick="document.querySelector('#reclamation__item_fifth').checked = true; create__reclamation();">EPDM repsottaa</div> -->
         </div>
         <div class="drawarea__control drawarea__bottom">
            <div class="drawarea__w_cord"></div>
            <div class="drawarea__bottom_container">
             <div class="box__left_leftdecor box__decor" style="left: calc(<?= $post["room_one_a-h"]; ?>px / 10) - 21px;">
               <input class="box__left_mm lineinput drawarea__boxdecor_mm" value="0" type="number" max="3600"  onchange="changesize__frominput();">
            </div>
            <div class="box__right_rightdecor box__decor">
               <input class="box__right_mm lineinput drawarea__boxdecor_mm" value="0" type="number" max="9975" onchange="changesize__frominput();">
            </div>
           </div>

         </div>
         <div class="drawarea__control drawarea__right recl_btn"><span>Reklamaatiot ja huomiot</span>

              <div class="sauma__rightctrl_container disabled">
               <div class="sauma__rightctrl_innercontainer">
               
               </div>
             </div>
          </div>

         <!-- Origo -->
         <div class="drawarea__origo" id="drawarea__origo_central" style="left: 1px;bottom: 1px;"></div>


         <div class="box" id="box_upper" style="width: 100%; height: 1px;min-height: 0.5px; max-height: 100%;min-width: 100%;top: 0px;">
            <div class="dot bottom-mid" id="box_upper__bottom-mid"></div>
         </div>
         <div class="box" id="box_lower" style="width: 100%; height: 1px;min-height: 0.5px; max-height: 100%;max-width: 100%;bottom: 0px;">
            <div class="dot top-mid" id="box_lower__top-mid"></div>
         </div>
         <div class="box" id="box_right" style="height: 100%; width: 1px;min-height: 100%; min-width: 0.5px; max-width: 100%;max-width: calc((<?= $post["room_one_a-w"]; ?>px / 10));right: 0;">
            <div class="dot left-mid" id="box_right__left-mid"></div>
         </div>
         <div class="box" id="box_left" style="height: 100%; width: 1px;min-height: 100%; min-width: 0.5px; max-width: 100%;max-width: calc((<?= $post["room_one_a-w"]; ?>px / 10));left: 0;">
            <div class="dot right-mid" id="box_left__right-mid"></div>
         </div>
         <main class="canvas" style="width: 100%;"><span onclick="this.classList.toggle('comment__visible')" class="aukko ikkuna" id="aukko08385a138f18d" title="1500,2000,2000,500" style="width: 399px; height: 300px; bottom: 100px; left: 101px;"><input type="hidden" name="aukko__attentions"><input type="hidden" name="aukko__commmets"><b class="newDiv__height">1500</b><b class="newDiv__width">2000</b><i class="newDiv__y">Y: 2000</i><i class="newDiv__x">X: 500</i></span><span onclick="this.classList.toggle('comment__visible')" class="mp" id="mpacdfbf4a274f6" data-no="1" style="bottom: 100px; left: 100px;"><input type="hidden" name="attentions"><input type="hidden" name="commmets"></span>
            
            
            
            <table class="grid-container">
              <tbody><tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>
              <tr class="grid-row" style="width: 100px;">
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
                 <td class="grid-item" style="width: 100px; height: 100px;"></td>
              </tr>

            </tbody></table>
      <div class="saumat__grandrow"><div class="horizontalrow_saumat"><div data-no="1" class="sauma sauma__horizontal sauma__horizontal_last lastsauma_horizontalf70c6db5d40a9" id="lastsauma_horizontalf70c6db5d40a9" name="lastsauma_horizontalf70c6db5d40a9" onclick="" style="bottom: 100px; margin-top: unset; top: unset; z-index: 3;"><div class="sauma__controls lastsauma_horizontalf70c6db5d40a9" name="lastsauma_horizontalf70c6db5d40a9"><input class="sauma__horizontal_ctrl sauma__horizontal_ctrl-righted sauma__control lastsauma_horizontalf70c6db5d40a9" name="lastsauma_horizontalf70c6db5d40a9" onchange="changedimensions_sauma(this);" data-from="500" style="height: 100px;"><b class="sauma__horizontal_ctrldown sauma__control_down lastsauma_horizontalf70c6db5d40a9" name="lastsauma_horizontalf70c6db5d40a9" style="height: 100px;">490</b><div class="sauma__controls_del lastsauma_horizontalf70c6db5d40a9" name="lastsauma_horizontalf70c6db5d40a9" onclick="sauma__del(this);" style="display: block;">A</div></div></div><div data-no="1" class="sauma sauma__horizontal sauma__horizontal_last lastsauma_horizontal8fb810cb08de7" id="lastsauma_horizontal8fb810cb08de7" name="lastsauma_horizontal8fb810cb08de7" onclick="" style="bottom: 400px; margin-top: unset; top: unset; z-index: 3;"><div class="sauma__controls lastsauma_horizontal8fb810cb08de7" name="lastsauma_horizontal8fb810cb08de7"><input class="sauma__horizontal_ctrl sauma__horizontal_ctrl-righted sauma__control lastsauma_horizontal8fb810cb08de7" name="lastsauma_horizontal8fb810cb08de7" onchange="changedimensions_sauma(this);" data-from="1500" style="height: 300px;"><b class="sauma__horizontal_ctrldown sauma__control_down lastsauma_horizontal8fb810cb08de7" name="lastsauma_horizontal8fb810cb08de7" style="height: 300px;">1490</b><div class="sauma__controls_del lastsauma_horizontal8fb810cb08de7" name="lastsauma_horizontal8fb810cb08de7" onclick="sauma__del(this);" style="display: block;">B</div></div></div><div data-no="1" class="sauma sauma__horizontal sauma__horizontal_last lastsauma_horizontal2e9728ac46d35" id="lastsauma_horizontal2e9728ac46d35" name="lastsauma_horizontal2e9728ac46d35" onclick="" style="bottom: 480px; margin-top: unset; top: unset; z-index: 3;"><div class="sauma__controls lastsauma_horizontal2e9728ac46d35" name="lastsauma_horizontal2e9728ac46d35"><input class="sauma__horizontal_ctrl sauma__horizontal_ctrl-righted sauma__control lastsauma_horizontal2e9728ac46d35" name="lastsauma_horizontal2e9728ac46d35" onchange="changedimensions_sauma(this);" data-from="400" style="height: 80px;"><b class="sauma__horizontal_ctrldown sauma__control_down lastsauma_horizontal2e9728ac46d35" name="lastsauma_horizontal2e9728ac46d35" style="height: 80px;">390</b><div class="sauma__controls_del lastsauma_horizontal2e9728ac46d35" name="lastsauma_horizontal2e9728ac46d35" onclick="sauma__del(this);" style="display: block;">C</div></div></div></div><div class="verticalrow_saumat"><div data-no="2" class="sauma sauma__vertical lastsauma_vertical7716ebecc6811" id="lastsauma_vertical7716ebecc6811" name="lastsauma_vertical7716ebecc6811" style="left: 100px; z-index: 3;"><div class="sauma__controls lastsauma_vertical7716ebecc6811" name="lastsauma_vertical7716ebecc6811"><input class="sauma__vertical_ctrl sauma__vertical_ctrl-lefted sauma__control lastsauma_vertical7716ebecc6811" type="text" name="lastsauma_vertical7716ebecc6811" data-from="500" onchange="changedimensions_sauma(this);" style="left: -100px; right: 0px;"><b class="sauma__vertical_ctrldown sauma__control_down lastsauma_vertical7716ebecc6811" name="lastsauma_vertical7716ebecc6811" style="width: 100px; left: -100px;">490</b><div class="sauma__controls_del lastsauma_vertical7716ebecc6811" name="lastsauma_vertical7716ebecc6811" onclick="sauma__del(this);" style="display: block;">0</div></div></div><div data-no="2" class="sauma luo__sauma_vertical sauma__vertical sauma18d8c501eb9d6" id="sauma18d8c501eb9d6" name="sauma18d8c501eb9d6" onclick="" style="position: absolute; left: 300px; width: 0px; z-index: 3;"><div class="sauma__controls sauma18d8c501eb9d6" name="sauma18d8c501eb9d6"><input class="sauma__vertical_ctrl sauma__vertical_ctrl-lefted sauma__control sauma18d8c501eb9d6" type="text" name="sauma18d8c501eb9d6" data-from="1000" onchange="changedimensions_sauma(this);" style="left: -200px; right: 0px;"><b class="sauma__vertical_ctrldown sauma__control_down sauma18d8c501eb9d6" name="sauma18d8c501eb9d6" style="width: 200px; left: -200px;">990</b><div class="sauma__controls_del sauma18d8c501eb9d6" name="sauma18d8c501eb9d6" onclick="sauma__del(this);" style="display: block;">1</div></div></div><div data-no="3" class="sauma sauma__vertical lastsauma_vertical9d1832d5f640a" id="lastsauma_vertical9d1832d5f640a" name="lastsauma_vertical9d1832d5f640a" style="left: 500px; z-index: 3;"><div class="sauma__controls lastsauma_vertical9d1832d5f640a" name="lastsauma_vertical9d1832d5f640a"><input class="sauma__vertical_ctrl sauma__vertical_ctrl-lefted sauma__control lastsauma_vertical9d1832d5f640a" type="text" name="lastsauma_vertical9d1832d5f640a" data-from="1000" onchange="changedimensions_sauma(this);" style="left: -200px; right: 0px;"><b class="sauma__vertical_ctrldown sauma__control_down lastsauma_vertical9d1832d5f640a" name="lastsauma_vertical9d1832d5f640a" style="width: 200px; left: -200px;">990</b><div class="sauma__controls_del lastsauma_vertical9d1832d5f640a" name="lastsauma_vertical9d1832d5f640a" onclick="sauma__del(this);" style="display: block;">2</div></div></div><div data-no="2" class="sauma sauma__vertical lastsauma_vertical1d306761fc346" id="lastsauma_vertical1d306761fc346" name="lastsauma_vertical1d306761fc346" style="left: 700px; z-index: 3;"><div class="sauma__controls lastsauma_vertical1d306761fc346" name="lastsauma_vertical1d306761fc346"><input class="sauma__vertical_ctrl sauma__vertical_ctrl-lefted sauma__control lastsauma_vertical1d306761fc346" type="text" name="lastsauma_vertical1d306761fc346" data-from="1000" onchange="changedimensions_sauma(this);" style="left: -200px; right: 0px;"><b class="sauma__vertical_ctrldown sauma__control_down lastsauma_vertical1d306761fc346" name="lastsauma_vertical1d306761fc346" style="width: 200px; left: -200px;">990</b><div class="sauma__controls_del lastsauma_vertical1d306761fc346" name="lastsauma_vertical1d306761fc346" onclick="sauma__del(this);" style="display: block;">3</div></div></div></div></div><div class="levyt"><div class="levy dir_y" title="490,490,5,5" data-levy="0" style="height: 99px; width: 99px; position: absolute; bottom: 1px; left: 1px;"><b> <div class="levy_name"> _A1</div><i>490x490mm</i></b><div class="levy_h" style="display: none;">490</div><div class="levy_w" style="display: none;">490</div><input type="hidden" class="l_meta"><div class="closer closer_1" onclick="">X</div><div class="closer closer_2" onclick="">X</div><div class="closer closer_3" onclick="">X</div><div class="closer closer_4" onclick="">X</div></div><div class="levy dir_y" title="990,490,5,505" data-levy="1" style="height: 99px; width: 199px; position: absolute; bottom: 1px; left: 101px;"><b> <div class="levy_name"> _B1</div><i>990x490mm</i></b><div class="levy_h" style="display: none;">990</div><div class="levy_w" style="display: none;">490</div><input type="hidden" class="l_meta"></div><div class="levy dir_y" title="990,490,5,1505" data-levy="2" style="height: 99px; width: 199px; position: absolute; bottom: 1px; left: 301px;"><b> <div class="levy_name"> _C1</div><i>990x490mm</i></b><div class="levy_h" style="display: none;">990</div><div class="levy_w" style="display: none;">490</div><input type="hidden" class="l_meta"><div class="closer closer_1" onclick="">X</div><div class="closer closer_2" onclick="">X</div><div class="closer closer_3" onclick="">X</div><div class="closer closer_4" onclick="">X</div></div><div class="levy dir_y" title="990,490,5,2505" data-levy="3" style="height: 99px; width: 199px; position: absolute; bottom: 1px; left: 501px;"><b> <div class="levy_name"> _D1</div><i>990x490mm</i></b><div class="levy_h" style="display: none;">990</div><div class="levy_w" style="display: none;">490</div><input type="hidden" class="l_meta"></div><div class="levy dir_y" title="490,1490,505,5" data-levy="4" style="height: 299px; width: 99px; position: absolute; bottom: 101px; left: 1px;"><b> <div class="levy_name"> _A2</div><i>490x1490mm</i></b><div class="levy_h" style="display: none;">490</div><div class="levy_w" style="display: none;">1490</div><input type="hidden" class="l_meta"><div class="closer closer_1" onclick="">X</div><div class="closer closer_2" onclick="">X</div><div class="closer closer_3" onclick="">X</div><div class="closer closer_4" onclick="">X</div></div><div class="levy dir_y" title="990,1490,505,505" data-levy="5" style="height: 299px; width: 199px; position: absolute; bottom: 101px; left: 101px;"><b> <div class="levy_name"> _B2</div><i>990x1490mm</i></b><div class="levy_h" style="display: none;">990</div><div class="levy_w" style="display: none;">1490</div><input type="hidden" class="l_meta"></div><div class="levy dir_y" title="990,1490,505,1505" data-levy="6" style="height: 299px; width: 199px; position: absolute; bottom: 101px; left: 301px;"><b> <div class="levy_name"> _C2</div><i>990x1490mm</i></b><div class="levy_h" style="display: none;">990</div><div class="levy_w" style="display: none;">1490</div><input type="hidden" class="l_meta"><div class="closer closer_1" onclick="">X</div><div class="closer closer_2" onclick="">X</div><div class="closer closer_3" onclick="">X</div><div class="closer closer_4" onclick="">X</div></div><div class="levy dir_y" title="990,1490,505,2505" data-levy="7" style="height: 299px; width: 199px; position: absolute; bottom: 101px; left: 501px;"><b> <div class="levy_name"> _D2</div><i>990x1490mm</i></b><div class="levy_h" style="display: none;">990</div><div class="levy_w" style="display: none;">1490</div><input type="hidden" class="l_meta"></div><div class="levy dir_y" title="490,390,2005,5" data-levy="8" style="height: 79px; width: 99px; position: absolute; bottom: 401px; left: 1px;"><b> <div class="levy_name"> _A3</div><i>490x390mm</i></b><div class="levy_h" style="display: none;">490</div><div class="levy_w" style="display: none;">390</div><input type="hidden" class="l_meta"><div class="closer closer_1" onclick="">X</div><div class="closer closer_2" onclick="">X</div><div class="closer closer_3" onclick="">X</div><div class="closer closer_4" onclick="">X</div></div><div class="levy dir_y" title="990,390,2005,505" data-levy="9" style="height: 79px; width: 199px; position: absolute; bottom: 401px; left: 101px;"><b> <div class="levy_name"> _B3</div><i>990x390mm</i></b><div class="levy_h" style="display: none;">990</div><div class="levy_w" style="display: none;">390</div><input type="hidden" class="l_meta"></div><div class="levy dir_y" title="990,390,2005,1505" data-levy="10" style="height: 79px; width: 199px; position: absolute; bottom: 401px; left: 301px;"><b> <div class="levy_name"> _C3</div><i>990x390mm</i></b><div class="levy_h" style="display: none;">990</div><div class="levy_w" style="display: none;">390</div><input type="hidden" class="l_meta"><div class="closer closer_1" onclick="">X</div><div class="closer closer_2" onclick="">X</div><div class="closer closer_3" onclick="">X</div><div class="closer closer_4" onclick="">X</div></div><div class="levy dir_y" title="990,390,2005,2505" data-levy="11" style="height: 79px; width: 199px; position: absolute; bottom: 401px; left: 501px;"><b> <div class="levy_name"> _D3</div><i>990x390mm</i></b><div class="levy_h" style="display: none;">990</div><div class="levy_w" style="display: none;">390</div><input type="hidden" class="l_meta"></div></div></main>
      </div>
     
      <?php include('./templates/da_controls_1.php'); ?>
      <?php include('./templates/da_controls_2.php'); ?>
      <?php include('./templates/da_controls_3.php'); ?>
      <?php include('./templates/da_controls_4.php'); ?>
      <?php include('./templates/da_controls_5.php'); ?>
      <?php include('./templates/da_controls_5-esikatselu.php'); ?>
      
      <?php include('./templates/da_controls_6.php'); ?>
      <?php include('./templates/da_controls_7.php'); ?>

   </div>
