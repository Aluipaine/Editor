<?php

// $content = trim(file_get_contents("php://input"));
// $_arr = json_decode($content, true);
$content = str_replace("'", "", urldecode($_GET["data"]));
$_arr = json_decode($content, true);

$filename = urldecode($_GET["name"]) . ' _levyt.csv';

function array_to_csv_download($array, $filename = "export.csv", $delimiter="	") {
    // open raw memory as file so no temp files needed, you might run out of memory though
    $f = fopen('php://memory', 'w'); 
    // loop over the input array
    fputs( $f, "\xEF\xBB\xBF" );
    foreach ($array as $line) { 
        // generate csv lines from the inner arrays
        fputcsv($f, $line, $delimiter); 
    }
    // reset the file pointer to the start of the file
    fseek($f, 0);
    // tell the browser it's going to be a csv file
    header('Content-Encoding: UTF-8');
    header('Content-Type: text/csv; charset=UTF-8');
    // tell the browser we want to save it instead of displaying it
    header('Content-Disposition: attachment; filename="'.$filename.'";');
    // make php send the generated csv lines to the browser
    fpassthru($f);
}

array_to_csv_download($_arr,  $filename);
