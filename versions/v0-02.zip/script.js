let STEP = 100;

function setup() {
  createCanvas(600, 400);
  background(255);
  drawGrid();
  noLoop();
}

function drawGrid() {
  background(255);
  
  // line color
  stroke(0);
  
  // font color
  fill(0, 0, 0);
  
  // draw horizontal lines
  for(let y = 0; y < height; y+=STEP) {
    strokeWeight(1);
    line(0, y, width, y);
    strokeWeight(0);
    text(y+"", 2, y+12);
  }
  
  // draw vertical lines
  for(let x = 0; x < width; x+=STEP) {
    strokeWeight(1);
    line(x, 0, x, height);
    strokeWeight(0);
    text(x+"", x+2, 12);
  }
}

// function windowResized() {
//   resizeCanvas(innerWidth, innerHeight);
//   drawGrid();
// }