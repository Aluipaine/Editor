<div class="drawarea__controls drawarea__controls_four">
   <h2>Pystysaumat</h2>
   <ol class="drawarea__controls_four-pysty drawarea__controls_fouritems" reversed>
   </ol>
   <h2>Vaakasaumat</h2>
   <ol class="drawarea__controls_four-vaaka drawarea__controls_fouritems" reversed>
   </ol>
   <div class="drawarea__controls_btns">
      <div class="drawarea__controls_settingsbtn drawarea__controls_btn m_btn">
         Saumojen asetukset
      </div>
      <div class="drawarea__controls_btn" onclick="refresh__drawcontrols();$('#step_drawscreen').val('drawscreen_section_five');levyta();">
         Saumoita
      </div>
      <div class="form-group st_question"><input type="checkbox" name="stjarj" id="stjarj" checked><label for="stjarj">Standard?</label></div>
      <div onclick="move_origo(this);" class="drawarea__controls_origoset">Origo oikealle</div>
   </div>
</div>