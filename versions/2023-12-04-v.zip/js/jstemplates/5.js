function luo__levy(h, w, dex, col, b, l) {
  dex += 1;
  var ind;
  title_index = h + "," + w + "," + b + "," + l;
  roomname = document.querySelector(".room").value;
  wallname = document.querySelector(".wall").value;
  if (roomname == "") {
    roomname = "Seinän levy";
  }
  r = wallname.replace("SEINÄ ", "").replace("1. ", "").replace("2. ", "").replace("3. ", "").replace("4. ", "").replace("5. ", "").replace("6. ", "").replace(
    "KATTO ", "").replace("LATTIA ", "");
  var levy__interval_horizontal = parseFloat(h) / 5 + 1;
  var levy__interval_vertical = parseFloat(w) / 5 + 1;
  var levy = document.createElement("div");
  var levy_h = document.createElement("div");
  var levy_w = document.createElement("div");
  var levy_name = document.createElement("div");
  levy.classList.add("levy");
  levy_h.classList.add("levy_h");
  levy_w.classList.add("levy_w");
  levy_name.classList.add("levy_name");
  if (document.getElementById("settings__sauma_pysty").checked) {
    levy.classList.add("dir_y");
  }
  else if (document.getElementById("settings__sauma_vaaka").checked) {
    levy.classList.add("dir_x");
  }
  ind = String.fromCharCode(65 + col);
  levy_h.innerHTML = h
  levy_w.innerHTML = w;
  levy_name.innerHTML = r + "_" + ind + dex;
  levy.innerHTML = "<b> <div class='levy_name'> " + levy_name.innerHTML + "</div><i>" + h + "x" + w + "mm</i></b>";
  levy.setAttribute("title", title_index);
  levy.style.height = (parseFloat(levy__interval_vertical)) + 'px';
  // levy.style.width = (parseFloat(levy__interval_horizontal)) + 'px';
  levy.style.width = (parseFloat(levy__interval_horizontal)) + 'px';
  levy_h.style.display = "none";
  levy_w.style.display = "none";
  levy.appendChild(levy_h);
  levy.appendChild(levy_w);
  levy.style.position = "absolute";
  levy.style.bottom = (parseFloat(b) / 5) + "px";
  if (document.getElementById("settings__saumahanta-oik").checked || document.getElementById("settings__saumahanta-tasoitus").checked || document
    .getElementById("settings__saumahanta-vas").checked && document.querySelector("#saumoitus__sauma_two").checked || pystyhanta_oikealle === true) {
    levy.style.left = (parseFloat(l) / 5) + "px";
  }
  else if (document.getElementById("settings__saumahanta-vas").checked && document.querySelector("#saumoitus__sauma_one").checked) {
    levy.style.right = (parseFloat(l) / 5) + "px";
  }
  else {
    levy.style.right = (parseFloat(l) / 5) + "px";
  }
  // levy.appendChild(levy_name);
  var l_meta = document.createElement("input");
  l_meta.type = "hidden";
  l_meta.classList = "l_meta";
  levy.appendChild(l_meta);
  return levy;
  levy_array.append(levy);
}

function levyta() {
  fixmissing__saumoitus();
  levy_c = -1;
  levy_array = [];
  if (document.querySelector(".levy") || document.querySelector(".levyt") || document.querySelector(".levysarake")) {
    let levy = document.querySelectorAll(".levy");
    for (var i = 0; i < levy.length; i += 1) {
      levy[i].remove();
    }
    let levyrow = document.querySelectorAll(".levyt");
    for (var i = 0; i < levyrow.length; i += 1) {
      levyrow[i].remove();
    }
    let levysarake = document.querySelectorAll(".levysarake");
    for (var i = 0; i < levysarake.length; i += 1) {
      levysarake[i].remove();
    }
    // let verticalrow_saumat = document.querySelectorAll(".verticalrow_saumat");
    // for (var i=0;i<verticalrow_saumat.length;i+=1){
    //   verticalrow_saumat[i].style.position = "absolute";
    // }
    // let horizontalrow_saumat = document.querySelectorAll(".horizontalrow_saumat");
    // for (var i=0;i<horizontalrow_saumat.length;i+=1){
    //   horizontalrow_saumat[i].style.position = "absolute";
    // }
  }
  let vaakamitat = document.querySelectorAll(".sauma__horizontal_ctrldown");
  let pystymitat = document.querySelectorAll(".sauma__vertical_ctrldown");
  var levyt = document.createElement("div");
  var canvas = document.querySelector("#box-wrapper > main");
  myDivs_horizontal = [],
    myDivs_vertical = [],
    i = 0, 2
  j = 0;
  levycount = parseFloat(vaakamitat.length * pystymitat.length);
  if (document.getElementById("settings__sauma_pysty").checked) {
    document.querySelector("#settings__levy_levysizew").value = document.querySelector("#settings__sauma_interval_x").value;
    document.querySelector("#settings__levy_levysizeh").value = document.querySelector("#settings__sauma_interval_y").value;
    document.querySelector("#k_settings__levy_levysizew").value = document.querySelector("#settings__sauma_interval_x").value;
    document.querySelector("#k_settings__levy_levysizeh").value = document.querySelector("#settings__sauma_interval_y").value;
    if (drawarea.querySelector("#drawscreen_section_tyostot .visible")) {
      drawarea.querySelector("#drawscreen_section_tyostot .visible").classList.add("dir_y");
    }
  }
  else if (document.getElementById("settings__sauma_vaaka").checked) {
    document.querySelector("#settings__levy_levysizeh").value = document.querySelector("#settings__sauma_interval_y").value;
    document.querySelector("#settings__levy_levysizew").value = document.querySelector("#settings__sauma_interval_x").value;
    document.querySelector("#k_settings__levy_levysizeh").value = document.querySelector("#settings__sauma_interval_y").value;
    document.querySelector("#k_settings__levy_levysizew").value = document.querySelector("#settings__sauma_interval_x").value;
    if (drawarea.querySelector("#drawscreen_section_tyostot .visible")) {
      drawarea.querySelector("#drawscreen_section_tyostot .visible").classList.add("dir_x");
    }
  }
  levyt.classList.add("levyt");
  // if (document.getElementById("settings__saumahanta-vas").checked) {
  //   levyt.style.flexDirection = "row-reverse";
  // }
  if (input_step == 'drawscreen_section_four') {
    var prev_b = 0;
    var preh_l = 0;
    for (var i = 0; i < vaakamitat.length; i++) {
      var levysarake = document.createElement("div");
      levysarake.classList.add("levysarake");
      levysarake.setAttribute("title", "s" + i);
      prev_b += parseFloat(vaakamitat[i].innerHTML);
      b = prev_b - parseFloat(vaakamitat[i].innerHTML) + 10 * [i] + 5;
      preh_l = 0;
      //LEFT
      for (var j = 0; j < pystymitat.length; j++) {
        h = parseFloat(pystymitat[j].innerHTML);
        w = parseFloat(vaakamitat[i].innerHTML);
        preh_l += parseFloat(pystymitat[j].innerHTML);
        l = preh_l - parseFloat(pystymitat[j].innerHTML) + 10 * [j] + 5;
        levyt.append(luo__levy(h, w, i, j, b, l))
        // levy_array.push(luo__levy(h,w,i,j,b,l))
      }
      // levyt.append(levysarake);
    }
    canvas.append(levyt);
    // var saumat__grandrow = document.querySelector(".saumat__grandrow");
    // var verticalrow_saumat = document.querySelector(".verticalrow_saumat");
    // saumat__grandrow.style.position = "absolute";
    // verticalrow_saumat.style.top = "0";
    // saumat__grandrow.remove();
    let levy = document.querySelectorAll(".levy");
    for (var i = 0; i < levy.length; i += 1) {
      raksita(levy[i]);
    }
    if (document.querySelector(".levy") || document.querySelector(".levyt") || document.querySelector(".levysarake")) {
      let levy = document.querySelectorAll(".levy");
      for (var i = 0; i < levy.length; i += 1) {
        // levy[i].style.background = "transparent";
        levy[i].classList.add("levy_transparent");
      }
      let closer = document.querySelectorAll(".closer");
      for (var i = 0; i < closer.length; i += 1) {
        closer[i].style.zIndex = 4;
        closer[i].style.opacity = 1;
      }
      // let verticalrow_saumat = document.querySelectorAll(".verticalrow_saumat");
      // for (var i=0;i<verticalrow_saumat.length;i+=1){
      //   verticalrow_saumat[i].style.position = "absolute";
      // }
      // let horizontalrow_saumat = document.querySelectorAll(".horizontalrow_saumat");
      // for (var i=0;i<horizontalrow_saumat.length;i+=1){
      //   horizontalrow_saumat[i].style.position = "absolute";
      // }
    }
  }
    aukkojenallapoisto();
}

function poista__aukkoala() {
  aukkos = canvas.querySelectorAll(".aukko");
  levys = canvas.querySelectorAll(".levy");
  for (var i = aukkos.length - 1; i >= 0; i--) {
    a_title_ = aukkos[i].title;
    a_title = a_title_.split(",");
    aukko_h = parseFloat(a_title[0]);
    aukko_w = parseFloat(a_title[1]);
    aukko_l = parseFloat(a_title[3]);
    aukko_b = parseFloat(a_title[2]);
    for (var l = levys.length - 1; l >= 0; l--) {
      l_title_ = levys[l].title;
      l_title = l_title_.split(",");
      levy_h = parseFloat(l_title[1]);
      levy_w = parseFloat(l_title[0]);
      levy_l = parseFloat(l_title[3]);
      levy_b = parseFloat(l_title[2]);
      //DELETE IF COMPLETELY SAME
      if (levy_h === aukko_h - 10) {
        // levys[l].style.background = "green";
        // console.log("aukko_h " + aukko_h + " levy_h: " + levy_h);
      }
      if (levy_w === (aukko_w - 10)) {
        // levys[l].style.background = "blue";
        // console.log("aukko_w " + aukko_w + " levy_w: " + levy_w);
      }
      if (levy_l - 5 === aukko_l) {
        // levys[l].style.background = "yellow";
        // console.log("aukko_l " + aukko_l + " levy_l: " + levy_l);
      }
      if (levy_b - 5 === aukko_b) {
        // levys[l].style.background = "purple";
        // console.log("aukko_b " + aukko_b + " levy_b: " + levy_b);
      }
      if (levy_h === aukko_h - 10 && levy_w === (aukko_w - 10) && levy_l - 5 === aukko_l && levy_b - 5 === aukko_b) {
        levys[l].remove();
      }
    }
  }
}

function raksita(levy) {
  levy_c += 1;
  var closer_1 = document.createElement("div");
  var closer_2 = document.createElement("div");
  var closer_3 = document.createElement("div");
  var closer_4 = document.createElement("div");
  closer_1.classList.add("closer");
  closer_2.classList.add("closer");
  closer_3.classList.add("closer");
  closer_4.classList.add("closer");
  closer_1.classList.add("closer_1");
  closer_2.classList.add("closer_2");
  closer_3.classList.add("closer_3");
  closer_4.classList.add("closer_4");
  closer_1.innerHTML = "X";
  closer_2.innerHTML = "X";
  closer_3.innerHTML = "X";
  closer_4.innerHTML = "X";
  closer_1.setAttribute("onclick", "");
  closer_2.setAttribute("onclick", "");
  closer_3.setAttribute("onclick", "");
  closer_4.setAttribute("onclick", "");
  if (isEven(levy_c)) {
    levy.appendChild(closer_1);
    levy.appendChild(closer_2);
    levy.appendChild(closer_3);
    levy.appendChild(closer_4);
  }
  levy.setAttribute("data-levy", levy_c);
  $('.closer').click(function() {
    var c = $(this).parent().data("levy");
    if ($(this).hasClass("closer_4")) {
      $('div[data-levy="' + (c - 1) + '"]').css("background-color", "red");
      $(this).parent().css("background-color", "red");
      value = $(this).parent().width() + $('div[data-levy="' + (c - 1) + '"]').width() + 20;
      $('div[data-levy="' + (c - 1) + '"]').width(value);
      $(this).parent().remove();
    }
    if ($(this).hasClass("closer_2")) {
      $('div[data-levy="' + (c + 1) + '"]').css("background-color", "red");
      $(this).parent().css("background-color", "red");
      value = $(this).parent().width() + $('div[data-levy="' + (c + 1) + '"]').width() + 20;
      $(this).parent().width(value);
      $('div[data-levy="' + (c + 1) + '"]').remove();
    }
    all_levyt = $(".levyt > .levysarake").children().length;
    var p = $(this).parent();
    var current = $(this).attr("data-levy");
  });
}

function open_ladonta_settings(e) {
  if (e === true) {
    document.querySelector(".ladonta_container").classList.add("two");
  }
  else if (e === false) {
    document.querySelector(".ladonta_container").classList.remove("two");
  }
}