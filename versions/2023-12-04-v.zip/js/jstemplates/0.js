function rooms__change_asjarj(order) {
  asj = order.dataset.tochange;
  mode_room = asj.toLowerCase();
  ir_value = document.querySelector(".asjarj" + mode_room.toLowerCase() + "").innerHTML = parseFloat(order.value);
}

function hide__room(room) {
  thiswall = room.parentElement.parentElement;
  if (thiswall.classList.contains('hidden')) {
    thiswall.classList.remove('hidden');
    room.innerHTML =
      '<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M14 1.41L12.59 0L7 5.59L1.41 0L0 1.41L5.59 7L0 12.59L1.41 14L7 8.41L12.59 14L14 12.59L8.41 7L14 1.41Z" fill="#EB1010"></path></svg>';
    asj = room.dataset.tochange;
    mode_room = asj.toLowerCase();
    tohide__room = document.querySelectorAll(".tohide__room_" + mode_room);
    for (var i = tohide__room.length - 1; i >= 0; i--) {
      tohide__room[i].classList.remove("hidden");
    }
  }
  else {
    thiswall.classList.add('hidden');
    room.innerHTML =
      '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="14px" height="14px" viewBox="0 0 14 14" version="1.1"><g id="surface1"><path style=" stroke:none;fill-rule:nonzero;fill:rgb(0%,0%,0%);fill-opacity:1;" d="M 13.933594 6.820312 C 12.898438 4.839844 10.105469 3.535156 7 3.535156 C 3.894531 3.535156 1.101562 4.839844 0.0664062 6.773438 C -0.0234375 6.910156 -0.0234375 7.046875 0.0664062 7.179688 C 1.101562 9.160156 3.894531 10.464844 7 10.464844 C 10.105469 10.464844 12.898438 9.160156 13.933594 7.226562 C 14.023438 7.089844 14.023438 6.953125 13.933594 6.820312 Z M 7 9.566406 C 4.34375 9.566406 1.957031 8.574219 1.011719 7 C 1.957031 5.425781 4.34375 4.433594 7 4.433594 C 9.65625 4.433594 12.042969 5.425781 12.988281 7 C 12.042969 8.53125 9.65625 9.566406 7 9.566406 Z M 7 9.566406 "/><path style=" stroke:none;fill-rule:nonzero;fill:rgb(0%,0%,0%);fill-opacity:1;" d="M 9.566406 3.894531 C 9.429688 3.667969 9.160156 3.625 8.9375 3.757812 C 8.710938 3.894531 8.664062 4.164062 8.800781 4.390625 C 9.070312 4.75 9.207031 5.199219 9.207031 5.648438 C 9.207031 6.863281 8.214844 7.855469 7 7.855469 C 5.785156 7.855469 4.792969 6.863281 4.792969 5.648438 C 4.792969 5.246094 4.929688 4.792969 5.15625 4.433594 C 5.289062 4.210938 5.246094 3.9375 5.019531 3.804688 C 4.792969 3.667969 4.523438 3.714844 4.390625 3.9375 C 4.027344 4.480469 3.847656 5.0625 3.847656 5.695312 C 3.847656 7.40625 5.246094 8.800781 6.953125 8.800781 C 8.710938 8.800781 10.105469 7.40625 10.105469 5.648438 C 10.105469 5.019531 9.925781 4.433594 9.566406 3.894531 Z M 9.566406 3.894531 "/></g></svg>';
    asj = room.dataset.tochange;
    mode_room = asj.toLowerCase();
    tohide__room = document.querySelectorAll(".tohide__room_" + mode_room);
    for (var i = tohide__room.length - 1; i >= 0; i--) {
      tohide__room[i].classList.add("hidden");
    }
  }
}
// Huone risti
const inputsName = document.querySelectorAll('.inputname');
const allLinksName = document.querySelectorAll('.house__wall_status');
inputsName.forEach(item => {
  item.addEventListener('input', () => {
    const room = item.getAttribute('data-room');
    allLinksName.forEach(element => {
      if (element.getAttribute('data-room') === room) {
        element.innerHTML = item.value;
      }
    });
  });
});

function changeHeights(num) {
  const allHeights = document.querySelectorAll('.wall_height');
  allHeights.forEach(function(item) {
    item.value = num;
  });
  document.querySelector("#house > div:nth-child(1) > div").style.height = num / 10 + "px";
  document.querySelector("#house > div:nth-child(3) > div").style.height = num / 10 + "px";
  document.querySelector("#house > div:nth-child(2) > div.house__wall.house__wall_one").style.height = num / 10 + "px";
  document.querySelector("#house > div:nth-child(2) > div.house__wall.house__wall_two").style.height = num / 10 + "px";
  document.querySelector("#house > div:nth-child(2) > div.house__wall.house__wall_three").style.height = num / 10 + "px";
  document.querySelector("#house > div:nth-child(2) > div.house__wall.house__wall_four").style.height = num / 10 + "px";
}

function changeWidths(num) {
  const allWidths = document.querySelectorAll('.wall_width');
  allWidths.forEach(function(item) {
    item.value = num;
  });
  document.querySelector("#house > div:nth-child(1) > div").style.width = num / 10 + "px";
  document.querySelector("#house > div:nth-child(3) > div").style.width = num / 10 + "px";
  document.querySelector("#house > div:nth-child(2) > div.house__wall.house__wall_one").style.width = num / 10 + "px";
  // document.querySelector("#house > div:nth-child(2) > div.house__wall.house__wall_two").style.width = num/10 + "px";
  document.querySelector("#house > div:nth-child(2) > div.house__wall.house__wall_three").style.width = num / 10 + "px";
  // document.querySelector("#house > div:nth-child(2) > div.house__wall.house__wall_four").style.width = num/10 + "px";
}

function changeWidths_2(num) {
  const allWidths = document.querySelectorAll('.wall_width_2');
  allWidths.forEach(function(item) {
    item.value = num;
  });
  document.querySelector("#house > div:nth-child(2) > div.house__wall.house__wall_two").style.width = num / 10 + "px";
  document.querySelector("#house > div:nth-child(2) > div.house__wall.house__wall_four").style.width = num / 10 + "px";
}

function change_roof() {
  const roof_height = document.querySelector('#wall_one_roof_h').value;
  const roof_width = document.querySelector('#wall_one_roof_w').value;
  document.querySelector('.question-container').classList.add("two");
  document.querySelector('.question-container').classList.remove("out");
  document.querySelector('.modal-yes').addEventListener("click", function() {
    changeHeights(roof_height);
    changeWidths(roof_width);
  });
  document.querySelector("#house > div:nth-child(1) > div").style.width = roof_width / 10 + "px";
}

function change_floor() {
  const floor_height = document.querySelector('#wall_one_floor_h').value;
  const floor_width = document.querySelector('#wall_one_floor_w').value;
  document.querySelector('.question-container').classList.add("two");
  document.querySelector('.question-container').classList.remove("out");
  document.querySelector('.modal-yes').addEventListener("click", function() {
    changeHeights(floor_height);
    changeWidths(floor_width);
  });
  document.querySelector("#house > div:nth-child(3) > div").style.width = floor_width / 10 + "px";
}

function change_a() {
  const a_height = document.querySelector('#wall_one_a_h').value;
  const a_width = document.querySelector('#wall_one_a_w').value;
  document.querySelector('.question-container').classList.add("two");
  document.querySelector('.question-container').classList.remove("out");
  document.querySelector('.modal-yes').addEventListener("click", function() {
    changeHeights(a_height);
    changeWidths(a_width);
  });
  document.querySelector("#house > div:nth-child(2) > div.house__wall.house__wall_one").style.width = a_width / 10 + "px";
}

function change_b() {
  const b_height = document.querySelector('#wall_one_b_h').value;
  const b_width = document.querySelector('#wall_one_b_w').value;
  document.querySelector('.question-container').classList.add("two");
  document.querySelector('.question-container').classList.remove("out");
  document.querySelector('.modal-yes').addEventListener("click", function() {
    changeHeights(b_height);
    changeWidths_2(b_width);
  });
  document.querySelector("#house > div:nth-child(2) > div.house__wall.house__wall_two").style.width = b_width / 10 + "px";
}

function change_c() {
  const c_height = document.querySelector('#wall_one_c_h').value;
  const c_width = document.querySelector('#wall_one_c_w').value;
  document.querySelector('.question-container').classList.add("two");
  document.querySelector('.question-container').classList.remove("out");
  document.querySelector('.modal-yes').addEventListener("click", function() {
    changeHeights(c_height);
    changeWidths(c_width);
  });
  document.querySelector("#house > div:nth-child(2) > div.house__wall.house__wall_three").style.width = c_width / 10 + "px";
}

function change_d() {
  const d_height = document.querySelector('#wall_one_d_h').value;
  const d_width = document.querySelector('#wall_one_d_w').value;
  document.querySelector('.question-container').classList.add("two");
  document.querySelector('.question-container').classList.remove("out");
  document.querySelector('.modal-yes').addEventListener("click", function() {
    changeHeights(d_height);
    changeWidths_2(d_width);
  });
  document.querySelector("#house > div:nth-child(2) > div.house__wall.house__wall_four").style.width = d_width / 10 + "px";
}
$('.project__building div.project__building_room').click(function() {
  $("#project_start").slideUp(200);
  refresh__drawcontrols();
  $('#step_drawscreen').val('rooms');
  k_saved_input = document.querySelector(".k_saved").value;
  a_saved_input = document.querySelector(".a_saved").value;
  b_saved_input = document.querySelector(".b_saved").value;
  c_saved_input = document.querySelector(".c_saved").value;
  d_saved_input = document.querySelector(".d_saved").value;
  l_saved_input = document.querySelector(".l_saved").value;
  if (k_saved_input.length > 5) {
    k_wall = document.querySelectorAll(".house__wall_status_r");
    for (var w = 0; w < c_wall.length; w++) {
      if (k_wall[w].innerHTML.search("vaaka")) {
        k_wall[w].classList.add("saumatok");
      }
      else {
        k_wall[w].classList.add("tomeasure");
      }
    }
  }
  if (a_saved_input.length > 5) {
    a_wall = document.querySelectorAll(".house__wall_status_a");
    for (var w = 0; w < a_wall.length; w++) {
      if (a_wall[w].innerHTML.search("vaaka")) {
        a_wall[w].classList.add("saumatok");
      }
      else {
        a_wall[w].classList.add("tomeasure");
      }
    }
  }
  if (b_saved_input.length > 5) {
    b_wall = document.querySelectorAll(".house__wall_status_b");
    for (var w = 0; w < b_wall.length; w++) {
      if (b_wall[w].innerHTML.search("vaaka")) {
        b_wall[w].classList.add("saumatok");
      }
      else {
        b_wall[w].classList.add("tomeasure");
      }
    }
  }
  if (c_saved_input.length > 5) {
    c_wall = document.querySelectorAll(".house__wall_status_c");
    for (var w = 0; w < c_wall.length; w++) {
      if (c_wall[w].innerHTML.search("vaaka")) {
        c_wall[w].classList.add("saumatok");
      }
      else {
        c_wall[w].classList.add("tomeasure");
      }
    }
  }
  if (d_saved_input.length > 5) {
    d_wall = document.querySelectorAll(".house__wall_status_d");
    for (var w = 0; w < d_wall.length; w++) {
      if (d_wall[w].innerHTML.search("vaaka")) {
        d_wall[w].classList.add("saumatok");
      }
      else {
        d_wall[w].classList.add("tomeasure");
      }
    }
  }
  if (l_saved_input.length > 5) {
    l_wall = document.querySelectorAll(".house__wall_status_l");
    for (var w = 0; w < l_wall.length; w++) {
      if (l_wall[w].innerHTML.search("vaaka")) {
        l_wall[w].classList.add("saumatok");
      }
      else {
        l_wall[w].classList.add("tomeasure");
      }
    }
  }
  $(this).addClass("tomeasure");
  $("#roomname").val("Tila " + $(this).text());
  $("#wall_one_a").val("SEINÄ " + $(this).text() + "_A");
  $("#wall_one_b").val("SEINÄ " + $(this).text() + "_B");
  $("#wall_one_c").val("SEINÄ " + $(this).text() + "_C");
  $("#wall_one_d").val("SEINÄ " + $(this).text() + "_D");
  $("#wall_one_roof").val("KATTO " + $(this).text() + "_K");
  $("#wall_one_floor").val("LATTIA " + $(this).text() + "_L");
  $(".house__wall_one > div.house__wall_status").text("1." + " SEINÄ " + $(this).text() + "_A");
  $(".house__wall_two > div.house__wall_status").text("2." + " SEINÄ " + $(this).text() + "_B");
  $(".house__wall_three > div.house__wall_status").text("3." + " SEINÄ " + $(this).text() + "_C");
  $(".house__wall_four > div.house__wall_status").text("4." + " SEINÄ " + $(this).text() + "_D");
  $(".house__wall_roof > div.house__wall_status").text("5." + " KATTO " + $(this).text() + "_K");
  $(".house__wall_floor > div.house__wall_status").text("6." + " LATTIA " + $(this).text() + "_L");
});
$('#rooms div.house__wall_status').click(function() {
  $("#rooms").slideUp(200);
  $("#drawscreen_section_zero").show();
  $("#drawscreen_section_zero").slideDown(200);
  var tilaname = $("#roomname").val();
  $("#zero_tila").text(tilaname);
  var text = $(this).text();
  $("#zero_huone").text(text);
  $(this).addClass("tomeasure");
  $(this).parent().find('.wall_height').val();
  $(this).parent().find('.wall_width').val();
  $('#reclamation__popup .modal_close_btn').attr('id', '--' + tilaname);
  if ($(this).parent().find('.wall_width_2').val()) {
    $("#drawarea_w").val($(this).parent().find('.wall_width_2').val());
  }
  else {
    $("#drawarea_w").val($(this).parent().find('.wall_width').val());
  }
  $("#drawarea_h").val($(this).parent().find('.wall_height').val());
  changesize();
});
var tableId = document.querySelector("#project__room > table");

function create_rooms() {
  var colc = document.querySelector("#colcount").innerHTML;
  var floc = document.querySelector("#rowcount").innerHTML;
  var wall_qty = document.querySelector("#wall_qty").value;
  var insert_cells = parseFloat(Math.round(colc) * Math.round(floc) * Math.round(wall_qty));
  var number = Number(insert_cells);
  for (i = 0; i < number; i++) {
    var j = 0; // First Cell
    var newTR = tableId.insertRow(i);
    var newTD1 = newTR.insertCell(j);
    newTD1.innerHTML = " Huone #" + i;
  };
};