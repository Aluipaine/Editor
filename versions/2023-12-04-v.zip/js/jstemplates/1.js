 // Рисование точки опоры на area canvas
 function draw__point() {
   const drawscreen_section_one = document.querySelector('#drawscreen_section_one');
   const drawscreen_section_two = document.querySelector('#drawscreen_section_two');
   const input_step = document.querySelector('#step_drawscreen').value;
   if (input_step == "drawscreen_section_one") {
     mittapiste_count += 1;
     // Создаем блок
     const newDiv = document.createElement("span");
     const ba = document.querySelector("#box-wrapper");
     const inputH = document.createElement('input');
     const inputW = document.createElement('input');
     inputH.setAttribute('type', 'num');
     inputW.setAttribute('type', 'num');
     newDiv.innerHTML = "";
     const newDiv__comment = document.createElement("span");
     newDiv__comment.innerHTML = "Mittapiste #" + mittapiste_count;
     const newDiv__comment_settings = document.createElement("i");
     const newDiv__comment_del = document.createElement("i");
     // Расположение - по центру canvas
     // newDiv.style.bottom = (canvas.offsetHeight / 2) + 'px';
     // newDiv.style.left = (canvas.offsetWidth / 2) + 'px';
     newDiv__comment_del.setAttribute("onclick",
       "obj = this.getAttribute('name');document.querySelector('#'+obj).remove();this.parentElement.remove();mittapiste_count-=1;");
     newDiv__comment_settings.setAttribute("onclick",
       "document.querySelector('#drawscreen_section_one > div.modal-container').classList.add('two');document.querySelector('#drawscreen_section_one > div.modal-container').classList.remove('out');document.querySelector('body').classList.add('modal-active');settings__mitta();change__newdiv_cord();obj = this.getAttribute('name');document.querySelector('#'+obj).remove();this.parentElement.remove();document.querySelector('#setting__canvas_mitta > main > '+'#'+obj).remove();mittapiste_count-=1;"
       );
     newDiv__comment_settings.innerHTML =
       "<svg width='14' height='14' viewBox='0 0 14 14' fill='none' xmlns='http://www.w3.org/2000/svg'><path d='M7.00159 9.45C6.33358 9.45 5.69293 9.19188 5.22058 8.73241C4.74822 8.27295 4.48286 7.64978 4.48286 7C4.48286 6.35022 4.74822 5.72705 5.22058 5.26759C5.69293 4.80812 6.33358 4.55 7.00159 4.55C7.6696 4.55 8.31025 4.80812 8.7826 5.26759C9.25495 5.72705 9.52032 6.35022 9.52032 7C9.52032 7.64978 9.25495 8.27295 8.7826 8.73241C8.31025 9.19188 7.6696 9.45 7.00159 9.45ZM12.3485 7.679C12.3773 7.455 12.3989 7.231 12.3989 7C12.3989 6.769 12.3773 6.538 12.3485 6.3L13.8669 5.159C14.0037 5.054 14.0396 4.865 13.9533 4.711L12.514 2.289C12.4277 2.135 12.2334 2.072 12.075 2.135L10.2831 2.835C9.90892 2.562 9.52032 2.324 9.06695 2.149L8.80068 0.294C8.7719 0.126 8.62077 0 8.1086 0H5.56231C5.38241 0 5.23128 0.126 5.2025 0.294L4.93623 2.149C4.48286 2.324 4.09425 2.562 3.72004 2.835L1.92815 2.135C1.76983 2.072 1.57552 2.135 1.48917 2.289L0.0498936 4.711C-0.0436593 4.865 -0.000480936 5.054 0.13625 5.159L1.65468 6.3C1.6259 6.538 1.60431 6.769 1.60431 7C1.60431 7.231 1.6259 7.455 1.65468 7.679L0.13625 8.841C-0.000480936 8.946 -0.0436593 9.135 0.0498936 9.289L1.48917 11.711C1.57552 11.865 1.76983 11.921 1.92815 11.865L3.72004 11.158C4.09425 11.438 4.48286 11.676 4.93623 11.851L5.2025 13.706C5.23128 13.874 5.38241 14 5.56231 14H8.1086C8.62077 14 8.7719 13.874 8.80068 13.706L9.06695 11.851C9.52032 11.669 9.90892 11.438 10.2831 11.158L12.075 11.865C12.2334 11.921 12.4277 11.865 12.514 11.711L13.9533 9.289C14.0396 9.135 14.0037 8.946 13.8669 8.841L12.3485 7.679Z' fill='#222222'/></svg>";
     newDiv__comment_del.innerHTML =
       '<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M14 1.41L12.59 0L7 5.59L1.41 0L0 1.41L5.59 7L0 12.59L1.41 14L7 8.41L12.59 14L14 12.59L8.41 7L14 1.41Z" fill="#EB1010"></path></svg>';
     let id = "mp" + Math.random().toString(16).slice(2).toLowerCase();
     newDiv.setAttribute("id", id);
     newDiv.dataset.no = mittapiste_count;
     newDiv__comment_settings.classList.add("m_btn");
     newDiv__comment_settings.classList.add("newDiv__comment_settings");
     newDiv__comment_del.classList.add("newDiv__comment_del");
     newDiv__comment_settings.setAttribute("name", id);
     newDiv__comment_del.setAttribute("name", id);
     newDiv__comment.appendChild(newDiv__comment_settings);
     newDiv__comment.appendChild(newDiv__comment_del);
     newDiv.setAttribute("onclick", "this.classList.toggle('comment__visible')");
     newDiv.classList = "mittapiste_element";
     newDiv.setAttribute("name", id);
     document.querySelector("#box-wrapper > main").prepend(newDiv);
     document.querySelector(".drawarea__controls_elementsone").prepend(newDiv__comment);
     //touchedElement('#box-wrapper > main', '#drawarea_w', '#drawarea_h', newDiv, 'elem', inputW, inputH);
   }
   if (input_step == "drawscreen_section_two") {
     settings__aukko();
     change__newdiv_cord();
   }
 }
 origo_position = "left_bottom";

 function move_origo(e) {
   if (document.querySelector("#drawarea__origo_central")) {
     if (e.innerHTML == "Origo oikealle") {
       document.querySelector("#drawarea__origo_central").style.left = (eval(document.querySelector("#drawarea_w").value / 5) - 1) + "px";
       e.innerHTML = "Origo ylös";
       document.querySelector("#drawarea__origo_central").style.bottom = "1px";
       origo_position = "right_bottom";
     }
     else if (e.innerHTML == "Origo ylös") {
       e.innerHTML = "Origo vasemmalle";
       document.querySelector("#drawarea__origo_central").style.bottom = (eval(document.querySelector("#drawarea_h").value / 5) - 1) + "px";
       document.querySelector("#drawarea__origo_central").style.left = (eval(document.querySelector("#drawarea_w").value / 5) - 1) + "px";
       origo_position = "right_top";
     }
     else if (e.innerHTML == "Origo vasemmalle") {
       document.querySelector("#drawarea__origo_central").style.left = "1px";
       e.innerHTML = "Origo alas";
       document.querySelector("#drawarea__origo_central").style.bottom = (eval(document.querySelector("#drawarea_h").value / 5) - 1) + "px";
       origo_position = "left_top";
     }
     else if (e.innerHTML == "Origo alas") {
       document.querySelector("#drawarea__origo_central").style.left = "1px";
       document.querySelector("#drawarea__origo_central").style.bottom = "1px";
       e.innerHTML = "Origo oikealle";
       origo_position = "left_bottom";
     }
     else {
       document.querySelector("#drawarea__origo_central").style.left = "1px";
       e.innerHTML = "Origo oikealle";
       document.querySelector("#drawarea__origo_central").style.bottom = "1px";
       origo_position = "right_bottom";
     }
   }
 }

 function draw__hole() {
   // aukko_count += 1;
   const input_step = document.querySelector('#step_drawscreen').value;
   const drawscreen_section_two = document.querySelector('#drawscreen_section_two');
   const drawscreen_section_three = document.querySelector('#drawscreen_section_three');
   if (input_step == "drawscreen_section_two") {
     const newDiv = document.createElement("span");
     newDiv.innerHTML = "";
     var newDiv__comment = document.createElement("span");
     newDiv__comment.innerHTML = "Aukko" + "#" + aukko_count;
     var newDiv__comment_settings = document.createElement("i");
     var newDiv__comment_del = document.createElement("i");
     newDiv__comment_del.setAttribute("onclick",
       "obj = this.getAttribute('name');document.querySelector('#'+obj).remove();this.parentElement.remove();aukko_count-=1;");
     newDiv__comment_settings.setAttribute("onclick",
       "document.querySelector('#drawscreen_section_two > div.modal-container').classList.add('two');document.querySelector('#drawscreen_section_two > div.modal-container').classList.remove('out');document.querySelector('body').classList.add('modal-active');settings__mitta();change__newdiv_cord();obj = this.getAttribute('name');document.querySelector('#'+obj).remove();this.parentElement.remove();aukko_count-=1;"
       );
     newDiv__comment_settings.innerHTML =
       "<svg width='14' height='14' viewBox='0 0 14 14' fill='none' xmlns='http://www.w3.org/2000/svg'><path d='M7.00159 9.45C6.33358 9.45 5.69293 9.19188 5.22058 8.73241C4.74822 8.27295 4.48286 7.64978 4.48286 7C4.48286 6.35022 4.74822 5.72705 5.22058 5.26759C5.69293 4.80812 6.33358 4.55 7.00159 4.55C7.6696 4.55 8.31025 4.80812 8.7826 5.26759C9.25495 5.72705 9.52032 6.35022 9.52032 7C9.52032 7.64978 9.25495 8.27295 8.7826 8.73241C8.31025 9.19188 7.6696 9.45 7.00159 9.45ZM12.3485 7.679C12.3773 7.455 12.3989 7.231 12.3989 7C12.3989 6.769 12.3773 6.538 12.3485 6.3L13.8669 5.159C14.0037 5.054 14.0396 4.865 13.9533 4.711L12.514 2.289C12.4277 2.135 12.2334 2.072 12.075 2.135L10.2831 2.835C9.90892 2.562 9.52032 2.324 9.06695 2.149L8.80068 0.294C8.7719 0.126 8.62077 0 8.1086 0H5.56231C5.38241 0 5.23128 0.126 5.2025 0.294L4.93623 2.149C4.48286 2.324 4.09425 2.562 3.72004 2.835L1.92815 2.135C1.76983 2.072 1.57552 2.135 1.48917 2.289L0.0498936 4.711C-0.0436593 4.865 -0.000480936 5.054 0.13625 5.159L1.65468 6.3C1.6259 6.538 1.60431 6.769 1.60431 7C1.60431 7.231 1.6259 7.455 1.65468 7.679L0.13625 8.841C-0.000480936 8.946 -0.0436593 9.135 0.0498936 9.289L1.48917 11.711C1.57552 11.865 1.76983 11.921 1.92815 11.865L3.72004 11.158C4.09425 11.438 4.48286 11.676 4.93623 11.851L5.2025 13.706C5.23128 13.874 5.38241 14 5.56231 14H8.1086C8.62077 14 8.7719 13.874 8.80068 13.706L9.06695 11.851C9.52032 11.669 9.90892 11.438 10.2831 11.158L12.075 11.865C12.2334 11.921 12.4277 11.865 12.514 11.711L13.9533 9.289C14.0396 9.135 14.0037 8.946 13.8669 8.841L12.3485 7.679Z' fill='#222222'/></svg>";
     newDiv__comment_del.innerHTML =
       "svg width='14' height='14' viewBox='0 0 14 14' fill='none' xmlns='http://www.w3.org/2000/svg'><path d='M14 1.41L12.59 0L7 5.59L1.41 0L0 1.41L5.59 7L0 12.59L1.41 14L7 8.41L12.59 14L14 12.59L8.41 7L14 1.41Z' fill='#EB1010'/></svg>";
     var id = "id" + Math.random().toString(16).slice(2).toLowerCase();
     newDiv.setAttribute("id", id);
     newDiv__comment_settings.classList.add("m_btn");
     newDiv__comment_settings.classList.add("newDiv__comment_settings");
     newDiv__comment_del.classList.add("newDiv__comment_del");
     newDiv__comment_settings.setAttribute("name", id);
     newDiv__comment_del.setAttribute("name", id);
     newDiv__comment.appendChild(newDiv__comment_settings);
     newDiv__comment.appendChild(newDiv__comment_del);
     document.querySelector("#box-wrapper > main").prepend(newDiv);
     document.querySelector(".drawarea__controls_elementstwo").prepend(newDiv__comment);
     newDiv.classList.add("aukko");
     // grabbing
   }
   if (input_step == "drawscreen_section_three") {
     var newDiv = document.createElement("span");
     newDiv.innerHTML = "";
     var newDiv__comment = document.createElement("span");
     newDiv__comment.innerHTML = "Läpivienti";
     var newDiv__comment_settings = document.createElement("i");
     var newDiv__comment_del = document.createElement("i");
     newDiv__comment_del.setAttribute("onclick", "obj = this.getAttribute('name');document.querySelector('#'+obj).remove();this.parentElement.remove();");
     newDiv__comment_settings.setAttribute("onclick",
       "document.querySelector('#drawscreen_section_one > div.modal-container').classList.add('two');document.querySelector('#drawscreen_section_one > div.modal-container').classList.remove('out');document.querySelector('body').classList.add('modal-active');settings__mitta();change__newdiv_cord();obj = this.getAttribute('name');document.querySelector('#'+obj).remove();this.parentElement.remove();"
       );
     newDiv__comment_settings.innerHTML =
       "<svg width='14' height='14' viewBox='0 0 14 14' fill='none' xmlns='http://www.w3.org/2000/svg'><path d='M7.00159 9.45C6.33358 9.45 5.69293 9.19188 5.22058 8.73241C4.74822 8.27295 4.48286 7.64978 4.48286 7C4.48286 6.35022 4.74822 5.72705 5.22058 5.26759C5.69293 4.80812 6.33358 4.55 7.00159 4.55C7.6696 4.55 8.31025 4.80812 8.7826 5.26759C9.25495 5.72705 9.52032 6.35022 9.52032 7C9.52032 7.64978 9.25495 8.27295 8.7826 8.73241C8.31025 9.19188 7.6696 9.45 7.00159 9.45ZM12.3485 7.679C12.3773 7.455 12.3989 7.231 12.3989 7C12.3989 6.769 12.3773 6.538 12.3485 6.3L13.8669 5.159C14.0037 5.054 14.0396 4.865 13.9533 4.711L12.514 2.289C12.4277 2.135 12.2334 2.072 12.075 2.135L10.2831 2.835C9.90892 2.562 9.52032 2.324 9.06695 2.149L8.80068 0.294C8.7719 0.126 8.62077 0 8.1086 0H5.56231C5.38241 0 5.23128 0.126 5.2025 0.294L4.93623 2.149C4.48286 2.324 4.09425 2.562 3.72004 2.835L1.92815 2.135C1.76983 2.072 1.57552 2.135 1.48917 2.289L0.0498936 4.711C-0.0436593 4.865 -0.000480936 5.054 0.13625 5.159L1.65468 6.3C1.6259 6.538 1.60431 6.769 1.60431 7C1.60431 7.231 1.6259 7.455 1.65468 7.679L0.13625 8.841C-0.000480936 8.946 -0.0436593 9.135 0.0498936 9.289L1.48917 11.711C1.57552 11.865 1.76983 11.921 1.92815 11.865L3.72004 11.158C4.09425 11.438 4.48286 11.676 4.93623 11.851L5.2025 13.706C5.23128 13.874 5.38241 14 5.56231 14H8.1086C8.62077 14 8.7719 13.874 8.80068 13.706L9.06695 11.851C9.52032 11.669 9.90892 11.438 10.2831 11.158L12.075 11.865C12.2334 11.921 12.4277 11.865 12.514 11.711L13.9533 9.289C14.0396 9.135 14.0037 8.946 13.8669 8.841L12.3485 7.679Z' fill='#222222'/></svg>";
     newDiv__comment_del.innerHTML =
       "<svg width='14' height='14' viewBox='0 0 14 14' fill='none' xmlns='http://www.w3.org/2000/svg'><path d='M14 1.41L12.59 0L7 5.59L1.41 0L0 1.41L5.59 7L0 12.59L1.41 14L7 8.41L12.59 14L14 12.59L8.41 7L14 1.41Z' fill='#EB1010'/></svg>";
     var id = "id" + Math.random().toString(16).slice(2).toLowerCase();
     newDiv.setAttribute("id", id);
     newDiv__comment_settings.classList.add("m_btn");
     newDiv__comment_settings.classList.add("newDiv__comment_settings");
     newDiv__comment_del.classList.add("newDiv__comment_del");
     newDiv__comment_settings.setAttribute("name", id);
     newDiv__comment_del.setAttribute("name", id);
     newDiv__comment.appendChild(newDiv__comment_settings);
     newDiv__comment.appendChild(newDiv__comment_del);
     document.querySelector("#box-wrapper > main").prepend(newDiv);
     document.querySelector(".drawarea__controls_elementsthree").prepend(newDiv__comment);
     newDiv.classList.add("lapivienti");
     newDiv.addEventListener('mousedown', mouseDown, false);
     window.addEventListener('mouseup', mouseUp, false);

     function mouseUp() {
       window.removeEventListener('mousemove', divMove, true);
     }

     function mouseDown(e) {
       window.addEventListener('mousemove', divMove, true);
     }

     function divMove(e) {
       newDiv.style.position = 'absolute';
       var mousePressX = e.clientX;
       var mousePressY = e.clientY;
       var wDiff = e.clientX - mousePressX;
       var hDiff = e.clientY - mousePressY;
       newDiv.style.bottom = (e.clientY - (e.clientY / 2)) + 'px';
       newDiv.style.left = (e.clientX - (e.clientX / 1.5)) + 'px';
     }
   }
 }
 // 2.1 Cord
 function drawarea__update_cord() {
   if (maxval) {
     mval_cord = maxval.split("|")[0];
     mval_dir = maxval.split("|")[1];
     if (mval_dir === "y" && mval_cord > 3650 || mval_dir === "x" && mval_cord > 9999) {
       return;
     }
   }
   var height = document.querySelector('#box_h').value;
   var width = document.querySelector('#box_w').value;
   var c_up = parseFloat(document.querySelector(".box__upper_mm").value);
   var c_low = parseFloat(document.querySelector(".box__lower_mm").value);
   var c_left = parseFloat(document.querySelector(".box__left_mm").value);
   var c_right = parseFloat(document.querySelector(".box__right_mm").value);
   c_width = parseFloat(width) - (parseFloat(c_left)) - (parseFloat(c_right));
   c_height = parseFloat(height) - (parseFloat(c_up)) - (parseFloat(c_low));
   document.querySelector('.drawarea__w_cord').innerHTML = Math.floor(c_width);
   document.querySelector('.drawarea__h_cord').innerHTML = Math.floor(c_height);
   document.querySelector('.drawarea__h_cord').style.right = (parseFloat(box_upper.offsetHeight) + 15) + 'px';
   // document.querySelector('.drawarea__h_cord').style.left = ( (-1) * parseFloat(c_low) ) + 'px';
   // document.querySelector('.drawarea__w_cord').style.right = (parseFloat(c_right) ) + 'px';
   document.querySelector('.drawarea__w_cord').style.left = (parseFloat(box_left.offsetWidth) + 15) + 'px';
 }

 function updatearea(maxval) {
   // 2.1 Cord
   if (maxval) {
     mval_cord = maxval.split("|")[0];
     mval_dir = maxval.split("|")[1];
     if (mval_dir === "y" && mval_cord > 3650 || mval_dir === "x" && mval_cord > 9999) {
       return;
     }
   }
   var height = document.querySelector('.drawarea_h').value;
   var width = document.querySelector('.drawarea_w').value;
   var c_up = parseFloat(document.querySelector(".box__upper_mm").value);
   var c_low = parseFloat(document.querySelector(".box__lower_mm").value);
   var c_left = parseFloat(document.querySelector(".box__right_mm").value);
   var c_right = parseFloat(document.querySelector(".box__left_mm").value);
   c_width = parseFloat(width) - (parseFloat(c_left)) - (parseFloat(c_right));
   c_height = parseFloat(height) - (parseFloat(c_up)) - (parseFloat(c_low));
   document.querySelector('.drawarea_w').value = c_width;
   document.querySelector('.drawarea_h').value = c_height;
   document.querySelector("#box_left").style.height = 1 + "px";
   document.querySelector("#box_upper").style.width = 1 + "px";
   document.querySelector("#box_right").style.height = 1 + "px";
   document.querySelector("#box_lower").style.width = 1 + "px";
   document.querySelector(".box__lower_lowerdecor").style.left = -1 * parseFloat(height);
   document.querySelector(".box__upper_mm").value = "0";
   document.querySelector(".box__lower_mm").value = "0";
   document.querySelector(".box__right_mm").value = "0";
   document.querySelector(".box__left_mm").value = "0";
   document.querySelector("#box_upper").style.height = "1px";
   document.querySelector("#box_lower").style.height = "1px";
   document.querySelector("#box_right").style.width = "1px";
   document.querySelector("#box_left").style.width = "1px";
   changesize();
 }

 function changesize__frominput(maxval) {
   if (maxval) {
     mval_cord = maxval.split("|")[0];
     mval_dir = maxval.split("|")[1];
     if (mval_dir === "y" && mval_cord > 3650 || mval_dir === "x" && mval_cord > 9999) {
       return;
     }
   }
   var box = document.querySelector("#box-wrapper");
   var height = document.querySelector('#box_h').value;
   var width = document.querySelector('#box_w').value;
   var box_left = document.querySelector("#box_left");
   var box_upper = document.querySelector("#box_upper");
   var box_right = document.querySelector("#box_right");
   var box_lower = document.querySelector("#box_lower");
   var c_up = parseFloat(document.querySelector(".box__upper_mm").value);
   var c_low = parseFloat(document.querySelector(".box__lower_mm").value);
   var c_left = parseFloat(document.querySelector(".box__left_mm").value);
   var c_right = parseFloat(document.querySelector(".box__right_mm").value);
   box_upper.style.height = (((c_up / height)) * box.offsetHeight) + 1 + 'px';
   box_lower.style.height = (((c_low / height)) * box.offsetHeight) + 1 + 'px';
   box_left.style.width = (((c_left / width)) * box.offsetWidth) + 1 + 'px';
   box_right.style.width = (((c_right / width)) * box.offsetWidth) + 1 + 'px';
   drawarea__update_cord();
   gridify();
 }

 function changesize(maxval) {
   if (maxval) {
     mval_cord = maxval.split("|")[0];
     mval_dir = maxval.split("|")[1];
     if (mval_dir === "y" && mval_cord > 3650 || mval_dir === "x" && mval_cord > 9999) {
       return;
     }
   }
   height = document.querySelector('.drawarea_h').value;
   width = document.querySelector('.drawarea_w').value;
   document.querySelector('.box__lower_lowerdecor').style.maxWidth = height / 5 + "px";
   document.querySelector('.box__lower_lowerdecor').style.left = (-1) * ((height / 5) - 20) + "px";
   document.querySelector('#box_h').value = height;
   document.querySelector('#box_w').value = width;
   document.querySelector(".box__lower_lowerdecor").style.left = -1 * parseFloat(height);
   document.querySelector("#box-wrapper").style.height = height / 5 + "px";
   document.querySelector("#box-wrapper").style.width = width / 5 + "px";
   document.querySelector("#box-wrapper").style.minHeight = height / 5 + "px";
   document.querySelector("#box-wrapper").style.minWidth = width / 5 + "px";
   document.querySelector("#box-wrapper").style.maxHeight = height / 5 + "px";
   document.querySelector("#box-wrapper").style.maxWidth = width / 5 + "px";
   // } else {
   //   document.querySelector('.box__lower_lowerdecor').style.maxWidth = height/10 + "px";
   //   document.querySelector('.box__lower_lowerdecor').style.left = (-1) * ((height/10) - 20) + "px";
   //   document.querySelector('#box_h').value = height;
   //   document.querySelector('#box_w').value = width;
   //   document.querySelector(".box__lower_lowerdecor").style.left = -1 * parseFloat(height);
   //   document.querySelector("#box-wrapper").style.height = height/10 + "px";
   //   document.querySelector("#box-wrapper").style.width = width/10 + "px";
   // }
   document.querySelector('#box-wrapper > main').style.width = 100 + "%";
   document.querySelector("#box_left").style.height = (100 + "%");
   document.querySelector("#box_upper").style.width = (100 + "%");
   document.querySelector("#box_right").style.height = (100 + "%");
   document.querySelector("#box_lower").style.width = (100 + "%");
   document.querySelector("#box_left").style.maxHeight = (100 + "%");
   document.querySelector("#box_upper").style.maxWidth = (100 + "%");
   document.querySelector("#box_right").style.maxHeight = (100 + "%");
   document.querySelector("#box_lower").style.maxWidth = (100 + "%");
   document.querySelector("#box_left").style.maxWidth = (100 + "%");
   document.querySelector("#box_upper").style.maxHeight = (100 + "%");
   document.querySelector("#box_right").style.maxWidth = (100 + "%");
   document.querySelector("#box_lower").style.maxHeight = (100 + "%");
   // document.querySelector('.box-wrapper').style.height = 70 + "vh";
   // document.querySelector('.box-wrapper').style.width = '';
   // document.querySelector('.box-wrapper').style.aspectRatio = `${width} / ${height}`;
   gridify();
 }

 function changesize__bottom(maxval) {
   if (maxval) {
     mval_cord = maxval.split("|")[0];
     mval_dir = maxval.split("|")[1];
     if (mval_dir === "y" && mval_cord > 3650 || mval_dir === "x" && mval_cord > 9999) {
       return;
     }
   }
   const height = document.querySelector('#box_h').value;
   const width = document.querySelector('#box_w').value;
   // document.querySelector(".canvas").style.height = 100 + "%";
   // document.querySelector(".canvas").style.width = 100 + "%";
   document.querySelector("#box_left").style.height = (100 + "%");
   document.querySelector("#box_upper").style.width = (100 + "%");
   document.querySelector("#box_right").style.height = (100 + "%");
   document.querySelector("#box_lower").style.width = (100 + "%");
   document.querySelector("#box_left").style.maxHeight = (100 + "%");
   document.querySelector("#box_upper").style.maxWidth = (100 + "%");
   document.querySelector("#box_right").style.maxHeight = (100 + "%");
   document.querySelector("#box_lower").style.maxWidth = (100 + "%");
   document.querySelector("#box_left").style.maxWidth = (100 + "%");
   document.querySelector("#box_upper").style.maxHeight = (100 + "%");
   document.querySelector("#box_right").style.maxWidth = (100 + "%") - 1 + "px";
   document.querySelector("#box_lower").style.maxHeight = (100 + "%");
   document.querySelector('.box-wrapper').style.width = "";
   document.querySelector('.box-wrapper').style.height = '70vh';
   document.querySelector('.box-wrapper').style.aspectRatio = `${width} / ${height}`;
   document.querySelector('#box-wrapper > main').style.width = 100 + "%";
   document.querySelector('#box-wrapper > main').style.aspectRatio = `${width} / ${height}`;
   document.querySelector('.box__lower_lowerdecor').style.maxWidth = width / 5 + "px";
   document.querySelector('.box__lower_lowerdecor').style.left = (-1) * ((height / 5) - 20) + "px";
   document.querySelector('.drawarea_h').value = height;
   document.querySelector('.drawarea_w').value = width;
   document.querySelector(".box__lower_lowerdecor").style.left = -1 * parseFloat(height);
   gridify();
 }
 mittapiste_count = 0;
 lapivienti_count = 0;
 mp_previous_vord = null;
 au_previous_vord = null;
 lv_previous_vord = null;
 prevdata = null;

 function settings__mitta() {
   const input_step = document.querySelector('#step_drawscreen').value;
   const drawscreen_section_one = document.querySelector('#drawscreen_section_one');
   const drawscreen_section_two = document.querySelector('#drawscreen_section_two');
   const drawscreen_section_three = document.querySelector('#drawscreen_section_three');
   document.querySelector("#setting__canvas_mitta").style.height = document.querySelector("#box-wrapper").style.height;
   document.querySelector("#setting__canvas_mitta").style.width = document.querySelector("#box-wrapper").style.width;
   if (input_step == "drawscreen_section_one") {
     const mitta_settings = document.querySelector("#box-wrapper > main").cloneNode(true);
     const mitta_origo = document.querySelector("#box-wrapper > div.drawarea__origo").cloneNode(true);
     document.querySelector("#setting__canvas_mitta").innerHTML = "";
     document.querySelector("#setting__canvas_mitta").append(mitta_settings);
     document.querySelector("#setting__canvas_mitta").prepend(mitta_origo);
     document.querySelector("#box-wrapper")
     const newDiv = document.createElement("span");
     const inW = document.createElement('input');
     const inH = document.createElement('input');
     inW.setAttribute('type', 'num');
     inH.setAttribute('type', 'num');
     newDiv.classList.add("settings__mittapiste");
     newDiv.setAttribute("id", "settings__mittapiste");
     newDiv.innerHTML = "";
     document.querySelector("#setting__canvas_mitta > main").prepend(newDiv);
     newDiv.style.left = "0";
     newDiv.style.bottom = "0";
     newDiv.style.top = "unset";
     newDiv.style.right = "unset";
     //touchedElement('.setting__canvas > .canvas', '#drawarea_w', '#drawarea_h', newDiv, 'elem', document.querySelector('#cord_left'), document.querySelector('#cord_up') );
   }
   if (input_step == "drawscreen_section_three") {
     var lapiviennit_settings = document.querySelector("#box-wrapper > main").cloneNode(true);
     var lapiviennit_origo = document.querySelector("#box-wrapper > div.drawarea__origo").cloneNode(true);
     document.querySelector("#setting__canvas_lapiviennit").innerHTML = "";
     document.querySelector("#setting__canvas_lapiviennit").append(lapiviennit_settings);
     document.querySelector("#setting__canvas_lapiviennit").prepend(lapiviennit_origo);
     document.querySelector("#setting__canvas_lapiviennit").style.height = document.querySelector("#box-wrapper").style.height;
     document.querySelector("#setting__canvas_lapiviennit").style.width = document.querySelector("#box-wrapper").style.width;
     var newDiv = document.createElement("span");
     newDiv.classList.add("settings__lv");
     newDiv.setAttribute("id", "settings__lv");
     newDiv.innerHTML = "";
     document.querySelector("#setting__canvas_lapiviennit > main").prepend(newDiv);
     // touchedElement('#setting__canvas_lapiviennit > main', '#box_w', '#box_h', newDiv, 'elem', document.querySelector('#lvcord_left'), document.querySelector('#lvcord_low') );
   }
 }

 function settings__aukko() {
   const input_step = document.querySelector('#step_drawscreen').value;
   var aukot_settings = document.querySelector("#box-wrapper > main").cloneNode(true);
   var aukot_origo = document.querySelector("#box-wrapper > div.drawarea__origo").cloneNode(true);
   document.querySelector("#setting__canvas_aukot").innerHTML = "";
   document.querySelector("#setting__canvas_aukot").append(aukot_settings);
   document.querySelector("#setting__canvas_aukot").prepend(aukot_origo);
   document.querySelector("#setting__canvas_aukot").style.height = document.querySelector("#box-wrapper").style.height;
   document.querySelector("#setting__canvas_aukot").style.width = document.querySelector("#box-wrapper").style.width;
   var newDiv = document.createElement("span");
   newDiv.classList.add("settings__aukko");
   newDiv.setAttribute("id", "settings__aukko");
   newDiv.innerHTML = "";
   document.querySelector("#setting__canvas_aukot > main").prepend(newDiv);
   if (input_step == "drawscreen_section_two") {
     // touchedElement('#setting__canvas_aukot > main', '#box_w', '#box_h', newDiv, 'elem', document.querySelector('#aukotcord_left'), document.querySelector('#aukotcord_up') );
     document.querySelector("#aukko_comment").value = "";
     document.querySelector("#aukko_comment_from").value = "";
     document.querySelector("#aukko_comment_to").value = "";
   }
   document.querySelector('#type__door').click();
 }

 function null__origo_cord() {
   const drawscreen_section_one = document.querySelector('#drawscreen_section_one');
   const drawscreen_section_two = document.querySelector('#drawscreen_section_two');
   const drawscreen_section_three = document.querySelector('#drawscreen_section_three');
   const input_step = document.querySelector('#step_drawscreen').value;
   if (input_step == "drawscreen_section_one") {
     document.querySelector("#cord_up").value = "0";
     document.querySelector("#cord_left").value = "0";
     document.getElementById("settings__mittapiste").style.bottom = "0";
     document.getElementById("settings__mittapiste").style.left = '0';
   }
   if (input_step == "drawscreen_section_two") {
     document.querySelector("#aukotcord_up").value = "0";
     document.querySelector("#aukotcord_left").value = "0";
     document.getElementById("settings__aukko").style.bottom = "0";
     document.getElementById("settings__aukko").style.left = "0";
   }
   if (input_step == "drawscreen_section_three") {
     document.querySelector("#lvcord_low").value = "0";
     document.querySelector("#lvcord_left").value = "0";
     document.getElementById("settings__lv").style.bottom = "0";
     document.getElementById("settings__lv").style.left = "0";
   }
 }

 function get_from_custom_mp(arg) {
   mp_s = canvas.querySelectorAll(".mp");
   bottomcord = 0;
   leftcord = 0;
   if (input_step == "drawscreen_section_two") {
     for (var i = mp_s.length - 1; i >= 0; i--) {
       if (arg === parseFloat(mp_s[i].dataset.no)) {
         bottomcord = parseFloat(mp_s[i].style.bottom) * 5;
         leftcord = parseFloat(mp_s[i].style.left) * 5;
       }
     }
     document.querySelector("#aukotcord_left").value = leftcord;
     document.querySelector("#aukotcord_low").value = bottomcord;
   }
   if (input_step == "drawscreen_section_three") {
     for (var i = mp_s.length - 1; i >= 0; i--) {
       if (arg === parseFloat(mp_s[i].dataset.no)) {
         bottomcord = parseFloat(mp_s[i].style.bottom) * 5;
         leftcord = parseFloat(mp_s[i].style.left) * 5;
       }
     }
     document.querySelector("#lvcord_left").value = leftcord;
     document.querySelector("#lvcord_low").value = bottomcord;
   }
 }

 function change__newdiv_cord() {
   const drawscreen_section_one = document.querySelector('#drawscreen_section_one');
   const drawscreen_section_two = document.querySelector('#drawscreen_section_two');
   const drawscreen_section_three = document.querySelector('#drawscreen_section_three');
   const drawscreen_section_eight = document.querySelector('#drawscreen_section_eight');
   const input_step = document.querySelector('#step_drawscreen').value;
   if (input_step == "drawscreen_section_one") {
     const newDiv = document.getElementById("settings__mittapiste");
     newDiv.style.bottom = eval(document.getElementById("cord_up").value / 5 ) + 'px';
     newDiv.style.left = eval(document.getElementById("cord_left").value / 5 ) + "px";
   }
   if (input_step == "drawscreen_section_two") {

   }
   if (input_step == "drawscreen_section_three") {
     const newDiv = document.getElementById("settings__lv");
     newDiv.style.bottom = eval(document.getElementById("lvcord_low").value / 5) + 'px';
     newDiv.style.left = eval(document.getElementById("lvcord_left").value / 5) + "px";
   }
 }

 function give__origo_cord() {
   const drawscreen_section_one = document.querySelector('#drawscreen_section_one');
   const drawscreen_section_two = document.querySelector('#drawscreen_section_two');
   const drawscreen_section_three = document.querySelector('#drawscreen_section_three');
   input_step = document.querySelector('#step_drawscreen').value;
   if (input_step == "drawscreen_section_one") {
     getElementCoords("#cord_up", "#cord_left");
   }
   if (input_step == "drawscreen_section_two") {
     getElementCoords("#aukotcord_low", "#aukotcord_left");
   }
   if (input_step == "drawscreen_section_three") {
     getElementCoords("#lvcord_low", "#lvcord_left");
   }
 }
 // Создание отверстия
 function mitta__create_mitta(mode, type, mode_name, mode_ycord, mode_xcord, mode_hcord, mode_wcord, mode_count, mode_id, mode_specifications) {
   const newDiv = document.createElement("span");
   const newDiv__comment = document.createElement("span");
   const newDiv__hidden_attention = document.createElement("input");
   const newDiv__hidden_attentioncommmets = document.createElement("input");
   const comment__container = document.createElement("div");
   const comment__text = document.createElement("p");
   const comment__from = document.createElement("strong");
   const comment__to = document.createElement("strong");
   comment__container.classList.add("comment__container");
   comment__from.classList.add("comment__from");
   comment__to.classList.add("comment__to");
   newDiv.appendChild(comment__container);
   comment__container.appendChild(comment__text);
   comment__container.appendChild(comment__from);
   comment__container.appendChild(comment__to);
   newDiv.appendChild(newDiv__hidden_attention);
   newDiv.appendChild(newDiv__hidden_attentioncommmets);
   newDiv__comment_settings = document.createElement("i");
   newDiv__comment_del = document.createElement("i");
   newDiv__comment_settings.innerHTML =
     "<svg width='14' height='14' viewBox='0 0 14 14' fill='none' xmlns='http://www.w3.org/2000/svg'><path d='M7.00159 9.45C6.33358 9.45 5.69293 9.19188 5.22058 8.73241C4.74822 8.27295 4.48286 7.64978 4.48286 7C4.48286 6.35022 4.74822 5.72705 5.22058 5.26759C5.69293 4.80812 6.33358 4.55 7.00159 4.55C7.6696 4.55 8.31025 4.80812 8.7826 5.26759C9.25495 5.72705 9.52032 6.35022 9.52032 7C9.52032 7.64978 9.25495 8.27295 8.7826 8.73241C8.31025 9.19188 7.6696 9.45 7.00159 9.45ZM12.3485 7.679C12.3773 7.455 12.3989 7.231 12.3989 7C12.3989 6.769 12.3773 6.538 12.3485 6.3L13.8669 5.159C14.0037 5.054 14.0396 4.865 13.9533 4.711L12.514 2.289C12.4277 2.135 12.2334 2.072 12.075 2.135L10.2831 2.835C9.90892 2.562 9.52032 2.324 9.06695 2.149L8.80068 0.294C8.7719 0.126 8.62077 0 8.1086 0H5.56231C5.38241 0 5.23128 0.126 5.2025 0.294L4.93623 2.149C4.48286 2.324 4.09425 2.562 3.72004 2.835L1.92815 2.135C1.76983 2.072 1.57552 2.135 1.48917 2.289L0.0498936 4.711C-0.0436593 4.865 -0.000480936 5.054 0.13625 5.159L1.65468 6.3C1.6259 6.538 1.60431 6.769 1.60431 7C1.60431 7.231 1.6259 7.455 1.65468 7.679L0.13625 8.841C-0.000480936 8.946 -0.0436593 9.135 0.0498936 9.289L1.48917 11.711C1.57552 11.865 1.76983 11.921 1.92815 11.865L3.72004 11.158C4.09425 11.438 4.48286 11.676 4.93623 11.851L5.2025 13.706C5.23128 13.874 5.38241 14 5.56231 14H8.1086C8.62077 14 8.7719 13.874 8.80068 13.706L9.06695 11.851C9.52032 11.669 9.90892 11.438 10.2831 11.158L12.075 11.865C12.2334 11.921 12.4277 11.865 12.514 11.711L13.9533 9.289C14.0396 9.135 14.0037 8.946 13.8669 8.841L12.3485 7.679Z' fill='#222222'/></svg>";
   newDiv__comment_del.innerHTML =
     "<svg width='14' height='14' viewBox='0 0 14 14' fill='none' xmlns='http://www.w3.org/2000/svg'><path d='M14 1.41L12.59 0L7 5.59L1.41 0L0 1.41L5.59 7L0 12.59L1.41 14L7 8.41L12.59 14L14 12.59L8.41 7L14 1.41Z' fill='#EB1010'/></svg>";
   newDiv__comment_settings.classList.add("m_btn");
   newDiv__comment_settings.classList.add("newDiv__comment_settings");
   newDiv__comment_del.classList.add("newDiv__comment_del");
   document.querySelector("#box-wrapper > main").prepend(newDiv);
   newDiv.innerHTML = "";
   if (mode) {
     name = mode_name;
     realname = name.split("#")[0];
     newDiv__comment.innerHTML = realname + "#" + mode_count;
     let id = mode_id;
     newDiv.setAttribute("id", id);
     newDiv__comment_settings.setAttribute("name", id);
     newDiv__comment_del.setAttribute("name", id);
     newDiv__comment.setAttribute("name", id);
     if (type == "mp") {
       mittapiste_count += 1;
       //  newDiv.style.bottom = parseFloat(mode_ycord)/5 + "px";
       // newDiv.style.left = parseFloat(mode_xcord)/5 + "px";
       newDiv__hidden_attention.type = "hidden";
       newDiv__hidden_attention.name = "attentions";
       newDiv__hidden_attentioncommmets.type = "hidden";
       newDiv__hidden_attentioncommmets.name = "commmets";
       newDiv.style.bottom = parseFloat(mode_ycord) / 5 + "px";
       newDiv.style.left = parseFloat(mode_xcord) / 5 + "px";
       document.querySelector(".drawarea__controls_elementsone").prepend(newDiv__comment);
       document.querySelector(".drawarea__controls_elementsone").prepend(newDiv__hidden_attention);
       document.querySelector(".drawarea__controls_elementsone").prepend(newDiv__hidden_attentioncommmets);
       // COMMENT COMING LATER
       // if (document.querySelector("#mittapiste_comment").value != '') {
       //   newDiv__hidden_attentioncommmets.value += document.querySelector("#mittapiste_comment").value + '<br> Tältä: ' + document.querySelector("#mittapiste_comment_from").value + '<br> Tälle: ' + document.querySelector("#mittapiste_comment_to").value;
       //   comment__text.innerHTML = document.querySelector("#mittapiste_comment").value;
       //   comment__from.innerHTML = document.querySelector("#mittapiste_comment_from").value;
       //   comment__to.innerHTML = document.querySelector("#mittapiste_comment_to").value;
       // }
       newDiv.setAttribute("onclick", "this.classList.toggle('comment__visible')");
       newDiv.classList.add("mp");
       newDiv.dataset.no = mode_count;
       things_array = ['"' + newDiv__comment.innerText + '|' + '' + parseFloat(newDiv.style.bottom) * 5 + '|' + '' + parseFloat(newDiv.style.left) * 5 + '|' +
         newDiv.dataset.no + '|' + id + '|' + mode_room + '__"'
       ];
       t_array = JSON.parse(things_array);
       mp_prevdata = t_array;
       submitprogress("", "adding", id, "mp", t_array);
       mp_previous_vord_ = "0|" + parseFloat(newDiv.style.bottom) * 5 + "|" + parseFloat(newDiv.style.left) * 5;
       newDiv__comment_del.setAttribute("onclick", "obj = this.getAttribute('name');submitprogress('','cancel','" + mode_id + "','mp','" + t_array +
         "');mittapiste_count-=1;");
       newDiv__comment_settings.setAttribute("onclick",
         " document.querySelector('#drawscreen_section_one > div.modal-container').classList.add('two');document.querySelector('#drawscreen_section_one > div.modal-container').classList.remove('out');document.querySelector('body').classList.add('modal-active');settings__mitta();change__newdiv_cord(); submitprogress('','cancel','" +
         id + "','mp','" + t_array + "');mittapiste_count-=1;mp_previous_vord = '" + mp_previous_vord_ + "';");
       newDiv__comment.appendChild(newDiv__comment_settings);
       newDiv__comment.appendChild(newDiv__comment_del);
     }
     if (type == "au") {
       newDiv__comment.innerHTML = name;
       const newDiv__height = document.createElement("b");
       const newDiv__width = document.createElement("b");
       const newDiv__y = document.createElement("i");
       const newDiv__x = document.createElement("i");
       newDiv__height.classList.add("newDiv__height");
       newDiv__width.classList.add("newDiv__width");
       newDiv__y.classList.add("newDiv__y");
       newDiv__x.classList.add("newDiv__x");
       newDiv__hidden_attention.type = "hidden";
       newDiv__hidden_attention.name = "aukko__attentions";
       newDiv__hidden_attentioncommmets.type = "hidden";
       newDiv__hidden_attentioncommmets.name = "aukko__commmets";
       newDiv.setAttribute("onclick", "this.classList.toggle('comment__visible')");
       document.querySelector(".drawarea__controls_elementstwo").prepend(newDiv__comment);
       document.querySelector(".drawarea__controls_elementstwo").prepend(newDiv__hidden_attention);
       document.querySelector(".drawarea__controls_elementstwo").prepend(newDiv__hidden_attentioncommmets);
       newDiv.style.bottom = parseFloat(mode_ycord) / 5 + "px";
       newDiv.style.left = parseFloat(mode_xcord) / 5 + "px";
       newDiv.style.width = parseFloat(mode_wcord) / 5 + "px";
       newDiv.style.height = parseFloat(mode_hcord) / 5 + "px";

       newDiv.dataset.no = parseFloat(mode_count);
       // if (document.querySelector("#aukko_comment").value != '') {
       //     newDiv__hidden_attentioncommmets.value += document.querySelector("#aukko_comment").value + '<br> Tältä: ' + document.querySelector("#aukko_comment_from").value + '<br> Tälle: ' + document.querySelector("#aukko_comment_to").value;
       //     comment__text.innerHTML = document.querySelector("#aukko_comment").value;
       //     comment__from.innerHTML = document.querySelector("#aukko_comment_from").value;
       //     comment__to.innerHTML = document.querySelector("#aukko_comment_to").value;
       //   }

       claslist = mode_specifications.split(" ");
       for (var i = claslist.length - 1; i >= 0; i--) {
         newDiv.classList.add(claslist[i]);
       }
       newDiv__height.innerHTML = parseFloat(mode_hcord);
       newDiv__width.innerHTML = parseFloat(mode_wcord);
       au_y = (parseFloat(mode_ycord)) + (parseFloat(mode_hcord));
       au_x = (parseFloat(newDiv.style.left)*5);
       newDiv__y.innerHTML = ("Y: " + au_y);
       newDiv__x.innerHTML = ("X: " + parseFloat(au_x));
       newDiv.appendChild(newDiv__height);
       newDiv.appendChild(newDiv__width);
       newDiv.appendChild(newDiv__y);
       newDiv.appendChild(newDiv__x);
       // Add styles to new hole
       realname = name.split("#")[0];
       newDiv__comment.innerHTML = realname + "# <b class='aukko_count'>" + mode_count + "</b>";
       newDiv.setAttribute("name", id);
       newDiv__comment_settings.setAttribute("name", id);
       newDiv__comment_del.setAttribute("name", id);
       newDiv__comment.setAttribute("name", id);
       newDiv_title = (newDiv__height.innerHTML + "," + newDiv__width.innerHTML + "," + au_y + "," + au_x);
       newDiv.setAttribute("title", newDiv_title);
      things_array = ['"' + newDiv__comment.innerText + '|' + '' + parseFloat(newDiv.style.bottom) * 5 + '|' + '' + parseFloat(newDiv.style.left) * 5 + '|' +
         newDiv.dataset.no + '|' + id + '|' + parseFloat(mode_hcord) + '|' + '' + parseFloat(mode_wcord) + '|' + newDiv.classList + '__"'
       ];
      

       t_array = JSON.parse(things_array);

       au_prevdata = t_array;
       submitprogress("", "adding", id, "aukot", t_array);
       if (au_previous_vord !== null) {
         newDiv.dataset.prevcord = au_previous_vord;
         au_previous_vord = null;
       }
       au_previous_vord = "0|" + parseFloat(newDiv.style.bottom) * 5 + "|" + parseFloat(newDiv.style.left) * 5 + "|" + (parseFloat(newDiv.style.width) + 1) *
         5 + "|" + parseFloat(newDiv.style.height) * 5;
       newDiv__comment_del.setAttribute("onclick", "obj = this.getAttribute('name');submitprogress('','cancel','" + id + "','aukot','" + t_array +
         "');aukko_del(document.querySelector('#'+obj), -1);"); //aukko_del(document.querySelector('#'+obj), -1);
       newDiv__comment_settings.setAttribute("onclick",
         "obj = this.getAttribute('name');aukko_del(document.querySelector('#'+obj), -1);document.querySelector('#drawscreen_section_two > div.modal-container').classList.add('two');document.querySelector('#drawscreen_section_two > div.modal-container').classList.remove('out');document.querySelector('body').classList.add('modal-active');settings__mitta();change__newdiv_cord();this.parentElement.remove();submitprogress('','cancel','" +
         id + "','aukot','" + t_array + "');au_previous_vord = '" + au_previous_vord + "';");
       newDiv__comment.appendChild(newDiv__comment_settings);
       newDiv__comment.appendChild(newDiv__comment_del);

       aukko_lcord = document.createElement("div");
       aukko_lcord.classList.add("aukko__cord");
       aukko_lcord.classList.add("aukko_lcord");
       aukko_lcord.innerHTML = 10+ parseFloat(newDiv.style.left)*5;
       aukko_lcord.style.bottom = (-1) * parseFloat(newDiv.style.bottom) -44 +"px";
       newDiv.appendChild(aukko_lcord);

       aukko_rcord = document.createElement("div");
       aukko_rcord.classList.add("aukko__cord");
       aukko_rcord.classList.add("aukko_rcord");
       aukko_rcord.innerHTML = 10+ parseFloat(newDiv.style.left)*5 + parseFloat(newDiv.style.width)*5;
       aukko_rcord.style.bottom = (-1) * parseFloat(newDiv.style.bottom) -44 +"px";
       newDiv.appendChild(aukko_rcord);

       aukko_tcord = document.createElement("div");
       aukko_tcord.classList.add("aukko__cord");
       aukko_tcord.classList.add("aukko_tcord");
       aukko_tcord.innerHTML = 10 + parseFloat(newDiv.style.bottom)*5 + parseFloat(newDiv.style.height)*5;
       aukko_tcord.style.left = (-1) * parseFloat(newDiv.style.left) -52 + "px";
       newDiv.appendChild(aukko_tcord); 

       aukko_bcord = document.createElement("div");
       aukko_bcord.classList.add("aukko__cord");
       aukko_bcord.classList.add("aukko_bcord");
       aukko_bcord.innerHTML = 10 + parseFloat(newDiv.style.bottom)*5;
       aukko_bcord.style.left = (-1) * parseFloat(newDiv.style.left) -52 + "px";
       newDiv.appendChild(aukko_bcord); 
     }
     if (type == "lv") {
       lapivienti_count += 1;
       newDiv__hidden_attention.type = "hidden";
       newDiv__hidden_attention.name = "attentions";
       newDiv__hidden_attentioncommmets.type = "hidden";
       newDiv__hidden_attentioncommmets.name = "commmets";
       newDiv__comment.innerHTML = mode_name + "#" + mode_count;

       document.querySelector(".drawarea__controls_elementsthree").prepend(newDiv__comment);
       document.querySelector(".drawarea__controls_elementsthree").prepend(newDiv__hidden_attention);
       document.querySelector(".drawarea__controls_elementsthree").prepend(newDiv__hidden_attentioncommmets);
       newDiv.setAttribute("onclick", "this.classList.toggle('comment__visible')");
       newDiv.style.bottom = (eval(mode_ycord) / 5) + "px";
       newDiv.style.left = (eval(mode_xcord) / 5) + "px";
       newDiv.innerHTML = mode_specifications;
       lv_sade = eval(mode_specifications);
       // if (document.querySelector("#lv_comment").value != '') {
       //   newDiv__hidden_attentioncommmets.value += document.querySelector("#lv_comment").value + '<br> Tältä: ' + document.querySelector("#lv_comment_from")
       //     .value + '<br> Tälle: ' + document.querySelector("#lv_comment_to").value;
       //   comment__text.innerHTML = document.querySelector("#lv_comment").value;
       //   comment__from.innerHTML = document.querySelector("#lv_comment_from").value;
       //   comment__to.innerHTML = document.querySelector("#lv_comment_to").value;
       // }
       newDiv__comment.appendChild(newDiv__comment_settings);
       newDiv__comment.appendChild(newDiv__comment_del);
       newDiv.classList.add("lapivienti");
       newDiv.classList.add("lv");
       // Add styles to new lapivienti
       newDiv.style.marginBottom = (-1) * lv_sade / 10 + "px";
       newDiv.style.marginLeft = (-1) * lv_sade / 10 + "px";
       const height = document.querySelector('#box_h').value;
       const width = document.querySelector('#box_w').value;
       if (document.querySelector("#lapiviennit__sade_muucord").value != "") {
         newDiv.style.height = lv_sade / 5 + "px";
         newDiv.style.width = lv_sade / 5 + "px";
         newDiv.classList.add("lapivienti__customsize");
       }
       newDiv.setAttribute("id", mode_id);
       newDiv.dataset.no = mode_count;
       newDiv__comment_settings.setAttribute("name", mode_id);
       newDiv__comment_del.setAttribute("name", mode_id);
       newDiv__comment.setAttribute("name", mode_id);
       // const inH = document.createElement('input');
       // const inW = document.createElement('input');
       // inH.setAttribute('type', 'num');
       // inW.setAttribute('type', 'num');
       // touchedElement('#box-wrapper > main', '#drawarea_w', '#drawarea_h', newDiv, 'elem', inH, inW );
       console.log("Things_arraythings_array: " + things_array);
       t_array = JSON.parse(things_array);
       console.log("Things_arrayt_array: " + t_array);
       submitprogress("", "adding", mode_id, "lv", t_array);
       things_array = ['"' + newDiv__comment.innerText + '|' + '' + parseFloat(newDiv.style.bottom) * 5 + '|' + '' + parseFloat(newDiv.style.left) * 5 + '|' +
         newDiv.dataset.no + '|' + mode_id + '|' + lv_sade + '__"'
       ];
       t_array = JSON.parse(things_array);
       lv_prevdata = t_array;
       console.log("Things_arraythings_array: " + things_array);
       console.log("Things_arrayt_array: " + t_array);
       submitprogress("", "adding", mode_id, "lv", t_array);
       lv_previous_vord_ = "0|" + parseFloat(newDiv.style.bottom) * 5 + "|" + parseFloat(newDiv.style.left) * 5;
       newDiv__comment_del.setAttribute("onclick",
         "obj = this.getAttribute('name');document.querySelector('#'+obj).remove();this.parentElement.remove();lapivienti_count-=1;submitprogress('','cancel','" +
         mode_id + "','lv','" + t_array + "');mittapiste_count-=1;");
       newDiv__comment_settings.setAttribute("onclick",
         "document.querySelector('#drawscreen_section_three > div.modal-container').classList.add('two');document.querySelector('#drawscreen_section_three > div.modal-container').classList.remove('out');document.querySelector('body').classList.add('modal-active');settings__mitta();change__newdiv_cord();obj = this.getAttribute('name');document.querySelector('#'+obj).remove();this.parentElement.remove();lapivienti_count-=1;submitprogress('','cancel','" +
         mode_id + "','lv','" + t_array + "');lv_previous_vord = '" + lv_previous_vord_ + "';");
       // newDiv__comment_del.setAttribute("onclick", "obj = this.getAttribute('name');submitprogress('','cancel','"+id+"','lv','"+t_array+"');mittapiste_count-=1;");
       // newDiv__comment_settings.setAttribute("onclick", " document.querySelector('#drawscreen_section_one > div.modal-container').classList.add('two');document.querySelector('#drawscreen_section_one > div.modal-container').classList.remove('out');document.querySelector('body').classList.add('modal-active');settings__mitta();change__newdiv_cord(); submitprogress('','cancel','"+id+"','lv','"+t_array+"');mittapiste_count-=1;lv_previous_vord = '"+lv_previous_vord_+"';");
       if (lv_previous_vord !== null) {
         newDiv.dataset.prevcord = lv_previous_vord;
         lv_previous_vord = null;
       }

        aukko_lcord = document.createElement("div");
        aukko_lcord.classList.add("lv__cord");
        aukko_lcord.classList.add("lv_lcord");
        aukko_lcord.innerHTML = parseFloat(newDiv.style.bottom)*5;
        aukko_lcord.style.bottom = (-1) * parseFloat(newDiv.style.width)/2 - 12 + "px";
        newDiv.appendChild(aukko_lcord);


        aukko_bcord = document.createElement("div");
        aukko_bcord.classList.add("lv__cord");
        aukko_bcord.classList.add("lv_bcord");
        aukko_bcord.innerHTML = parseFloat(newDiv.style.left)*5;
        aukko_bcord.style.left = (-1) * parseFloat(newDiv.style.height)/2 - 15 + "px";
        newDiv.appendChild(aukko_bcord); 
     }
   }
   else {
     input_step = document.querySelector('#step_drawscreen').value;
     if (input_step == "drawscreen_section_one") {
       mittapiste_count += 1;
       newDiv__comment.innerHTML = document.querySelector("#mittapiste__name").value + "#" + mittapiste_count;
       newDiv__hidden_attention.type = "hidden";
       newDiv__hidden_attention.name = "attentions";
       newDiv__hidden_attentioncommmets.type = "hidden";
       newDiv__hidden_attentioncommmets.name = "commmets";
       document.querySelector(".drawarea__controls_elementsone").prepend(newDiv__comment);
       document.querySelector(".drawarea__controls_elementsone").prepend(newDiv__hidden_attention);
       document.querySelector(".drawarea__controls_elementsone").prepend(newDiv__hidden_attentioncommmets);


        newDiv.style.left = eval(document.querySelector("#cord_left").value) / 5 + "px";
       
        newDiv.style.bottom = eval(document.querySelector("#cord_up").value) / 5 + "px";
       
       
       if (document.querySelector("#cord_up").value == "") {
         newDiv.style.bottom = 0;
       }
       if (document.querySelector("#m__a_sahko").checked) {
         newDiv__hidden_attention.value += document.querySelector("#m__a_sahko").value + '. ';
       }
       if (document.querySelector("#m__a_putki").checked) {
         newDiv__hidden_attention.value += document.querySelector("#m__a_putki").value + '. ';
       }
       if (document.querySelector("#m__a_tornado").checked) {
         newDiv__hidden_attention.value += document.querySelector("#m__a_tornado").value + '. ';
       }
       if (document.querySelector("#mittapiste_comment").value != '') {
         newDiv__hidden_attentioncommmets.value += document.querySelector("#mittapiste_comment").value + '<br> Tältä: ' + document.querySelector(
           "#mittapiste_comment_from").value + '<br> Tälle: ' + document.querySelector("#mittapiste_comment_to").value;
         comment__text.innerHTML = document.querySelector("#mittapiste_comment").value;
         comment__from.innerHTML = document.querySelector("#mittapiste_comment_from").value;
         comment__to.innerHTML = document.querySelector("#mittapiste_comment_to").value;
       }
       newDiv.setAttribute("onclick", "this.classList.toggle('comment__visible')");
       newDiv.classList.add("mp");
       let id = "mp" + Math.random().toString(16).slice(2).toLowerCase().toLowerCase();
       newDiv.dataset.no = mittapiste_count;
       newDiv__comment_settings.setAttribute("name", id);
       newDiv__comment_del.setAttribute("name", id);
       newDiv__comment.setAttribute("name", id);
       newDiv.setAttribute("id", id);
       newDiv__comment.appendChild(newDiv__comment_settings);
       newDiv__comment.appendChild(newDiv__comment_del);
       // const inH = document.createElement('input');
       // const inW = document.createElement('input');
       // inH.setAttribute('type', 'num');
       // inW.setAttribute('type', 'num');
       // touchedElement('#box-wrapper > main', '#drawarea_w', '#drawarea_h', newDiv, 'elem', inH, inW );
       things_array = ['"' + newDiv__comment.innerText + '|' + '' + parseFloat(newDiv.style.bottom) * 5 + '|' + '' + parseFloat(newDiv.style.left) * 5 + '|' +
         newDiv.dataset.no + '|' + id + '|' + current_room + '__"'
       ];
       t_array = JSON.parse(things_array);
       mp_prevdata = t_array;
       submitprogress("", "adding", id, "mp", t_array);
       mp_previous_vord_ = "0|" + parseFloat(newDiv.style.bottom) * 5 + "|" + parseFloat(newDiv.style.left) * 5;
       newDiv__comment_del.setAttribute("onclick", "obj = this.getAttribute('name');submitprogress('','cancel','" + id + "','mp','" + t_array +
         "');mittapiste_count-=1;");
       newDiv__comment_settings.setAttribute("onclick",
         " document.querySelector('#drawscreen_section_one > div.modal-container').classList.add('two');document.querySelector('#drawscreen_section_one > div.modal-container').classList.remove('out');document.querySelector('body').classList.add('modal-active');settings__mitta();change__newdiv_cord(); submitprogress('','cancel','" +
         id + "','mp','" + t_array + "');mittapiste_count-=1;mp_previous_vord = '" + mp_previous_vord_ + "';");
       if (mp_previous_vord !== null) {
         newDiv.dataset.prevcord = mp_previous_vord;
         mp_previous_vord = null;
       }
     }
     if (input_step == "drawscreen_section_two") {
       changedimensions_aukko();
       const newDiv__height = document.createElement("b");
       const newDiv__width = document.createElement("b");
       const newDiv__y = document.createElement("i");
       const newDiv__x = document.createElement("i");

       

       newDiv__height.classList.add("newDiv__height");
       newDiv__width.classList.add("newDiv__width");
       newDiv__y.classList.add("newDiv__y");
       newDiv__x.classList.add("newDiv__x");
       newDiv__hidden_attention.type = "hidden";
       newDiv__hidden_attention.name = "aukko__attentions";
       newDiv__hidden_attentioncommmets.type = "hidden";
       newDiv__hidden_attentioncommmets.name = "aukko__commmets";
       newDiv.setAttribute("onclick", "this.classList.toggle('comment__visible')");
       document.querySelector(".drawarea__controls_elementstwo").prepend(newDiv__comment);
       document.querySelector(".drawarea__controls_elementstwo").prepend(newDiv__hidden_attention);
       document.querySelector(".drawarea__controls_elementstwo").prepend(newDiv__hidden_attentioncommmets);
       newDiv.style.width = eval(parseFloat(document.querySelector("#hole__width").value) / 5) + "px";
       // parseFloat(parseFloat(document.querySelector("#hole__height").value)/5) + "px";
       newDiv.style.height = eval(parseFloat(document.querySelector("#hole__height").value) / 5) + "px";
       newDiv.style.bottom = (eval(document.getElementById("aukotcord_low").value) / 5) + "px";
       newDiv.style.left = (eval(document.getElementById("aukotcord_left").value) / 5) + 'px';
       if (document.querySelector("#aukotcord_low").value == "") {
         newDiv.style.bottom = 0 + 'px';
       }
       if (document.querySelector("#aukotcord_left").value == "") {
         newDiv.style.left = 0 + 'px';
       }
       if (document.querySelector("#m__a_sahko").checked) {
         newDiv__hidden_attention.value += document.querySelector("#m__a_sahko").value + '. ';
       }
       if (document.querySelector("#m__a_putki").checked) {
         newDiv__hidden_attention.value += document.querySelector("#m__a_putki").value + '. ';
       }
       if (document.querySelector("#m__a_tornado").checked) {
         newDiv__hidden_attention.value += document.querySelector("#m__a_tornado").value + '. ';
       }
       if (document.querySelector("#aukko_comment").value != '') {
         newDiv__hidden_attentioncommmets.value += document.querySelector("#aukko_comment").value + '<br> Tältä: ' + document.querySelector(
           "#aukko_comment_from").value + '<br> Tälle: ' + document.querySelector("#aukko_comment_to").value;
         comment__text.innerHTML = document.querySelector("#aukko_comment").value;
         comment__from.innerHTML = document.querySelector("#aukko_comment_from").value;
         comment__to.innerHTML = document.querySelector("#aukko_comment_to").value;
       }
       newDiv.classList.add("aukko");
       newDiv__height.innerHTML = (eval(document.getElementById("hole__height").value));
       newDiv__width.innerHTML = (eval(document.getElementById("hole__width").value));
       newDiv__y.innerHTML = ("Y: " + eval(document.getElementById("aukotcord_up").value));
       newDiv__x.innerHTML = ("X: " + eval(document.getElementById("aukotcord_left").value));
       newDiv.appendChild(newDiv__height);
       newDiv.appendChild(newDiv__width);
       newDiv.appendChild(newDiv__y);
       newDiv.appendChild(newDiv__x);
       // Add styles to new hole
       newDiv.dataset.no = "";
       if (document.querySelector("#type__door").checked) {
         newDiv.classList.add("ovi");
         aukko_count(newDiv, 1);
       }
       if (document.querySelector("#type__window").checked) {
         newDiv.classList.add("ikkuna");
         aukko_count(newDiv, 1);
       }
       if (document.querySelector("#type__palkki").checked) {
         newDiv.classList.add("palkki");
         aukko_count(newDiv, 1);
       }
       if (document.querySelector("#type__collar").checked) {
         newDiv.classList.add("pilari");
         aukko_count(newDiv, 1);
       }
       if (document.querySelector("#type__ventilation").checked) {
         newDiv.classList.add("tuuletus");
         aukko_count(newDiv, 1);
       }
       newDiv__comment.innerHTML = document.querySelector("#aukko__name").value + "# <b class='aukko_count'>" + newDiv.dataset.no + "</b>";
       let id = "aukko" + Math.random().toString(16).slice(2).toLowerCase().toLowerCase();
       newDiv.setAttribute("id", id);
       newDiv__comment_settings.setAttribute("name", id);
       newDiv__comment_del.setAttribute("name", id);
       newDiv__comment.setAttribute("name", id);
       newDiv__comment.appendChild(newDiv__comment_settings);
       newDiv__comment.appendChild(newDiv__comment_del);
       // const inH = document.createElement('input');
       // const inW = document.createElement('input');
       // inH.setAttribute('type', 'num');
       // inW.setAttribute('type', 'num');
       // touchedElement('#box-wrapper > main', '#box_w', '#box_h', newDiv, 'elem', inH, inW );
       newDiv_title = (eval(document.getElementById("hole__height").value)) + "," + (eval(document.getElementById("hole__width").value)) + "," +
         eval(document.getElementById("aukotcord_up").value) + "," + eval(document.getElementById("aukotcord_left").value);
       newDiv.setAttribute("title", newDiv_title);
       things_array = ['"' + newDiv__comment.innerText + '|' + '' + parseFloat(newDiv.style.bottom) * 5 + '|' + '' + parseFloat(newDiv.style.left) * 5 + '|' +
         newDiv.dataset.no + '|' + id + '|' + (eval(document.getElementById("hole__height").value)) + '|' + '' + eval(document.getElementById(
           "hole__width").value) + '|' + newDiv.classList + '__"'
       ];
       console.log("Things_arraythings_array: " + things_array);
       t_array = JSON.parse(things_array);
       console.log("Things_arrayt_array: " + t_array);
       au_prevdata = t_array;
       submitprogress("", "adding", id, "aukot", t_array);
       if (au_previous_vord !== null) {
         newDiv.dataset.prevcord = au_previous_vord;
         au_previous_vord = null;
       }
       au_previous_vord = "0|" + parseFloat(newDiv.style.bottom) * 5 + "|" + parseFloat(newDiv.style.left) * 5 + "|" + (parseFloat(newDiv.style.width) + 1) *
         5 + "|" + parseFloat(newDiv.style.height) * 5;
       newDiv__comment_del.setAttribute("onclick", "obj = this.getAttribute('name');submitprogress('','cancel','" + id + "','aukot','" + t_array +
         "');aukko_del(document.querySelector('#'+obj), -1);"); //aukko_del(document.querySelector('#'+obj), -1);
       newDiv__comment_settings.setAttribute("onclick",
         "obj = this.getAttribute('name');aukko_del(document.querySelector('#'+obj), -1);document.querySelector('#drawscreen_section_two > div.modal-container').classList.add('two');document.querySelector('#drawscreen_section_two > div.modal-container').classList.remove('out');document.querySelector('body').classList.add('modal-active');settings__mitta();change__newdiv_cord();this.parentElement.remove();submitprogress('','cancel','" +
         id + "','aukot','" + t_array + "');au_previous_vord = '" + au_previous_vord + "';");

       aukko_lcord = document.createElement("div");
       aukko_lcord.classList.add("aukko__cord");
       aukko_lcord.classList.add("aukko_lcord");
       aukko_lcord.innerHTML = 10+ parseFloat(newDiv.style.left)*5;
       aukko_lcord.style.bottom = (-1) * parseFloat(newDiv.style.bottom) -55 +"px";
       newDiv.appendChild(aukko_lcord);

       aukko_rcord = document.createElement("div");
       aukko_rcord.classList.add("aukko__cord");
       aukko_rcord.classList.add("aukko_rcord");
       aukko_rcord.innerHTML = 10+ parseFloat(newDiv.style.left)*5 + parseFloat(newDiv.style.width)*5;
       aukko_rcord.style.bottom = (-1) * parseFloat(newDiv.style.bottom) -55 +"px";
       newDiv.appendChild(aukko_rcord);

       aukko_tcord = document.createElement("div");
       aukko_tcord.classList.add("aukko__cord");
       aukko_tcord.classList.add("aukko_tcord");
       aukko_tcord.innerHTML = 10+ parseFloat(newDiv.style.bottom)*5 + parseFloat(newDiv.style.height)*5;
       aukko_tcord.style.left = (-1) * parseFloat(newDiv.style.left) -55 + "px";
       newDiv.appendChild(aukko_tcord); 

       aukko_bcord = document.createElement("div");
       aukko_bcord.classList.add("aukko__cord");
       aukko_bcord.classList.add("aukko_bcord");
       aukko_bcord.innerHTML = 10+ parseFloat(newDiv.style.bottom)*5;
       aukko_bcord.style.left = (-1) * parseFloat(newDiv.style.left) -55 + "px";
       newDiv.appendChild(aukko_bcord); 
     }
     if (input_step == "drawscreen_section_three") {
       lapivienti_count += 1;
       newDiv__hidden_attention.type = "hidden";
       newDiv__hidden_attention.name = "attentions";
       newDiv__hidden_attentioncommmets.type = "hidden";
       newDiv__hidden_attentioncommmets.name = "commmets";
       newDiv__comment.innerHTML = document.querySelector("#lv__name").value + "#" + lapivienti_count;
       document.querySelector(".drawarea__controls_elementsthree").prepend(newDiv__comment);
       document.querySelector(".drawarea__controls_elementsthree").prepend(newDiv__hidden_attention);
       document.querySelector(".drawarea__controls_elementsthree").prepend(newDiv__hidden_attentioncommmets);
       newDiv.setAttribute("onclick", "this.classList.toggle('comment__visible')");
       newDiv.style.bottom = (eval(document.getElementById("lvcord_low").value) / 5) + "px";
       newDiv.style.left = (eval(document.getElementById("lvcord_left").value) / 5) + "px";
       newDiv.innerHTML = document.getElementById("lapiviennit__sade_muucord").value;
       lv_sade = eval(document.getElementById("lapiviennit__sade_muucord").value);
       if (document.querySelector("#lv_comment").value != '') {
         newDiv__hidden_attentioncommmets.value += document.querySelector("#lv_comment").value + '<br> Tältä: ' + document.querySelector("#lv_comment_from")
           .value + '<br> Tälle: ' + document.querySelector("#lv_comment_to").value;
         comment__text.innerHTML = document.querySelector("#lv_comment").value;
         comment__from.innerHTML = document.querySelector("#lv_comment_from").value;
         comment__to.innerHTML = document.querySelector("#lv_comment_to").value;
       }
       newDiv__comment.appendChild(newDiv__comment_settings);
       newDiv__comment.appendChild(newDiv__comment_del);
       newDiv.classList.add("lapivienti");
       newDiv.classList.add("lv");
       // Add styles to new lapivienti
       newDiv.style.marginBottom = (-1) * lv_sade / 10 + "px";
       newDiv.style.marginLeft = (-1) * lv_sade / 10 + "px";
       const height = document.querySelector('#box_h').value;
       const width = document.querySelector('#box_w').value;
       if (document.querySelector("#lapiviennit__sade_muucord").value != "") {
         newDiv.style.height = lv_sade / 5 + "px";
         newDiv.style.width = lv_sade / 5 + "px";
         newDiv.classList.add("lapivienti__customsize");
       }
       let id = "lv" + Math.random().toString(16).slice(2).toLowerCase().toLowerCase();
       newDiv.setAttribute("id", id);
       newDiv.dataset.no = lapivienti_count;
       newDiv__comment_settings.setAttribute("name", id);
       newDiv__comment_del.setAttribute("name", id);
       newDiv__comment.setAttribute("name", id);
       // const inH = document.createElement('input');
       // const inW = document.createElement('input');
       // inH.setAttribute('type', 'num');
       // inW.setAttribute('type', 'num');
       // touchedElement('#box-wrapper > main', '#drawarea_w', '#drawarea_h', newDiv, 'elem', inH, inW );


       things_array = ['"' + newDiv__comment.innerText + '|' + '' + parseFloat(newDiv.style.bottom) * 5 + '|' + '' + parseFloat(newDiv.style.left) * 5 + '|' +
         newDiv.dataset.no + '|' + id + '|' + lv_sade + '__"'
       ];
       t_array = JSON.parse(things_array);
       lv_prevdata = t_array;
       console.log("Things_arraythings_array: " + things_array);
       console.log("Things_arrayt_array: " + t_array);
       submitprogress("", "adding", id, "lv", t_array);
       lv_previous_vord_ = "0|" + parseFloat(newDiv.style.bottom) * 5 + "|" + parseFloat(newDiv.style.left) * 5;
       newDiv__comment_del.setAttribute("onclick",
         "obj = this.getAttribute('name');document.querySelector('#'+obj).remove();this.parentElement.remove();lapivienti_count-=1;submitprogress('','cancel','" +
         id + "','lv','" + t_array + "');mittapiste_count-=1;");
       newDiv__comment_settings.setAttribute("onclick",
         "document.querySelector('#drawscreen_section_three > div.modal-container').classList.add('two');document.querySelector('#drawscreen_section_three > div.modal-container').classList.remove('out');document.querySelector('body').classList.add('modal-active');settings__mitta();change__newdiv_cord();obj = this.getAttribute('name');document.querySelector('#'+obj).remove();this.parentElement.remove();lapivienti_count-=1;submitprogress('','cancel','" +
         id + "','lv','" + t_array + "');lv_previous_vord = '" + lv_previous_vord_ + "';");
       // newDiv__comment_del.setAttribute("onclick", "obj = this.getAttribute('name');submitprogress('','cancel','"+id+"','lv','"+t_array+"');mittapiste_count-=1;");
       // newDiv__comment_settings.setAttribute("onclick", " document.querySelector('#drawscreen_section_one > div.modal-container').classList.add('two');document.querySelector('#drawscreen_section_one > div.modal-container').classList.remove('out');document.querySelector('body').classList.add('modal-active');settings__mitta();change__newdiv_cord(); submitprogress('','cancel','"+id+"','lv','"+t_array+"');mittapiste_count-=1;lv_previous_vord = '"+lv_previous_vord_+"';");
       if (lv_previous_vord !== null) {
         newDiv.dataset.prevcord = lv_previous_vord;
         lv_previous_vord = null;
       }

        aukko_lcord = document.createElement("div");
        aukko_lcord.classList.add("lv__cord");
        aukko_lcord.classList.add("lv_lcord");
        aukko_lcord.innerHTML = parseFloat(newDiv.style.bottom)*5;
        aukko_lcord.style.bottom = (-1) * parseFloat(newDiv.style.width)/2 - 12 + "px";
        newDiv.appendChild(aukko_lcord);


        aukko_bcord = document.createElement("div");
        aukko_bcord.classList.add("lv__cord");
        aukko_bcord.classList.add("lv_bcord");
        aukko_bcord.innerHTML = parseFloat(newDiv.style.left)*5;
        aukko_bcord.style.left = (-1) * parseFloat(newDiv.style.height)/2 - 15 + "px";
        newDiv.appendChild(aukko_bcord); 
       // touchedElement('#box-wrapper > main', '#box_w', '#box_h', newDiv, 'elem', inH, inW );
     }
   }

   // document.querySelector(".drawarea__bottom");
 }