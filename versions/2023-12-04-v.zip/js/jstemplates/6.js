function aloita_tyosto_kiinnikkeet() {
  let levyt = document.querySelectorAll(".levy");
  evt = 0;
  // k_main_levy = document.querySelectorAll("#drawscreen_section_tyostot .levy")[0].getAttribute("title");
  // k_min_h = parseFloat(document.querySelector("#p_two").value);
  // k_min_w = parseFloat(document.querySelector("#v_two").value);
  // k_main_levy_ = k_main_levy.split(",");
  if (document.querySelector("#kiinniketys__pkiinnike_one").checked === true) {
    evt = 1;
    levyt.forEach(element => tyosta(element, evt));
  }
  if (document.querySelector("#kiinniketys__pkiinnike_two").checked === true) {
    evt = 2;
    levyt.forEach(element => tyosta(element, evt));
  }
  if (document.querySelector("#kiinniketys__pkiinnike_three").checked === true) {
    evt = 3;
    levyt.forEach(element => tyosta(element, evt));
  }
  if (document.querySelector("#kiinniketys__pkiinnike_four").checked === true) {
    evt = 4;
    levyt.forEach(element => tyosta(element, evt));
  }
  if (document.querySelector("#kiinniketys__vkiinnike_one").checked === true) {
    evt = 5;
    levyt.forEach(element => tyosta(element, evt));
  }
  if (document.querySelector("#kiinniketys__vkiinnike_two").checked === true) {
    evt = 6;
    levyt.forEach(element => tyosta(element, evt));
  }
  if (document.querySelector("#kiinniketys__vkiinnike_three").checked === true) {
    evt = 7;
    levyt.forEach(element => tyosta(element, evt));
  }
  if (document.querySelector("#kiinniketys__vkiinnike_four").checked === true) {
    evt = 8;
    levyt.forEach(element => tyosta(element, evt));
  }
}

function tyosta(levy, evt) {
  levy_c_x = 0;
  levy_c_y = 0;
  var left_cord = 0,
    bottom_cord = 0;
  if (levy.querySelector(".levy_tyostot_y")) {
    var levy_tyostot_y = levy.querySelector(".levy_tyostot_y");
  }
  else {
    var levy_tyostot_y = document.createElement("div");
    levy_tyostot_y.classList.add("levy_tyostot_y");
    levy.append(levy_tyostot_y);
  }
  if (levy.querySelector(".levy_tyostot_x")) {
    var levy_tyostot_x = levy.querySelector(".levy_tyostot_x");
  }
  else {
    var levy_tyostot_x = document.createElement("div");
    levy_tyostot_x.classList.add("levy_tyostot_x");
    levy.append(levy_tyostot_x);
  }
  k_one = document.querySelector("#kiinniketys__kiinnike_one");
  k_two = document.querySelector("#kiinniketys__kiinnike_two");
  k_three = document.querySelector("#kiinniketys__kiinnike_three");
  k_four = document.querySelector("#kiinniketys__kiinnike_four");
  k_five = document.querySelector("#kiinniketys__kiinnike_five");
  k_six = document.querySelector("#kiinniketys__kiinnike_six");
  levy_meta = (levy.title).split(",")
  l_d = 8;
  k_main_levy = levy.getAttribute("title");
  k_min_h = parseFloat(document.querySelector("#p_two").value);
  k_min_w = parseFloat(document.querySelector("#v_two").value);
  k_main_levy_ = k_main_levy.split(",");
  //PYSTYKIINNIKKEET
  if (evt === 1 || evt === 2 || evt === 3 || evt === 4) {
    let tyosto_levy = levy.querySelectorAll(".tyostot__tyosto_pysty");
    for (var i = tyosto_levy.length - 1; i >= 0; i--) {
      tyosto_levy[i].remove()
    }
    height_levy = parseFloat(levy.getAttribute("title").split(",")[0]);
    l_i = document.querySelector("#p_target").value;
    p_left = parseFloat(document.querySelector("#settings__levy_vr_arvo").value);
    p_right = parseFloat(document.querySelector("#settings__levy_or_arvo").value);
    p_h_ = (height_levy - (p_left + p_right));
    p_kaava1 = p_h_ / l_i;
    if (p_h_ < k_min_h) {
      p_h = -1;
      p_kaava1 = 0;
      p_c_kaava1 = Math.ceil(p_kaava1);
      p_t_kaava1 = 1 + Math.trunc(p_kaava1);
    }
    else {
      p_h = p_h_;
      p_c_kaava1 = Math.ceil(p_kaava1);
      p_t_kaava1 = 1 + Math.trunc(p_kaava1);
    }
    if (evt === 1 && k_min_h < parseFloat(k_main_levy_[0]) || evt === 2 && k_min_h < parseFloat(k_main_levy_[0])) {
      for (var j = 1; j < p_c_kaava1; j++) {
        if (evt === 1) {
          var x = document.createElement("div");
          var x_cord = document.createElement("input");
          x_cord.setAttribute("onchange", "change__tyostocord(this,1);");
          x_cord.classList.add("x_cord_mki");
          x.classList.add("tyostot__tyosto");
          x.classList.add("tyostot__tyosto_pysty");
          left_cord = ((parseFloat(l_i) * j) / 5) + "px";
          x.style.right = left_cord;
          x.style.height = "100%";
          x.style.width = parseFloat(8 / 5) + "px";
          x.style.position = "absolute";
          levy_tyostot_x.prepend(x);
          levy.append(levy_tyostot_x);
          x_cord.type = "text";
          x_cord.classList.add("x_cord");
          x_cord.setAttribute("onclick", "tyosto__del(this);");
          cord = parseFloat((parseFloat(l_i) * (j))) - parseFloat((parseFloat(l_i) * (j - 1)));
          x_cord.value = cord.toFixed(0);
          x_cord.dataset.from = x_cord.value;
          x_cord.style.right = cord / 10;
          x_cord.style.float = "left";
          x.prepend(x_cord);
          var x_del = document.createElement("div");
          x_del.classList.add("x_del");
          x_del.setAttribute("onclick", "tyosto__del(this);");
          x.prepend(x_del);
        }
        else if (evt === 2) {
          var x = document.createElement("div");
          right_cord = ((parseFloat(l_i) * j) / 5) + "px";
          x.style.left = right_cord;
          x.classList.add("tyostot__tyosto");
          x.classList.add("tyostot__tyosto_pysty");
          x.style.height = "100%";
          x.style.width = parseFloat(8 / 5) + "px";
          x.style.position = "absolute";
          levy_tyostot_x.prepend(x);
          levy.append(levy_tyostot_x);
          cord = parseFloat((parseFloat(l_i) * (j))) - parseFloat((parseFloat(l_i) * (j - 1)));
          var x_cord = document.createElement("input");
          x_cord.setAttribute("onchange", "change__tyostocord(this,1);");
          x_cord.classList.add("x_cord_mki");
          x_cord.type = "text";
          x_cord.classList.add("x_cord");
          x_cord.value = cord.toFixed(0);
          x_cord.dataset.from = x_cord.value;
          x_cord.style.float = "right";
          // x_cord.style.left = cord/10;
          x.prepend(x_cord);
          var x_del = document.createElement("div");
          x_del.classList.add("x_del");
          x_del.setAttribute("onclick", "tyosto__del(this);");
          x.prepend(x_del);
        }
        // if(evt === 1) {
        //   x_cord.style.float = "left";
        // }
        // else if(evt === 2) {
        //   x_cord.style.float = "right";
        // }
      }
    }
    if (evt === 3 && k_min_h < parseFloat(k_main_levy_[0]) || evt === 4 && k_min_h < parseFloat(k_main_levy_[0])) {
      lahinmodmitta = (p_h / 25);
      areas = Math.ceil(p_c_kaava1);
      modcount = Math.floor((lahinmodmitta) / areas);
      l_i = parseFloat(modcount * 25);
      p_t_kaava1 = Math.floor(p_h / l_i);
      if (evt === 4) {
        if (isEven(p_t_kaava1)) {}
        else {
          p_t_kaava1 += 1;
        }
      }
      for (var j = 0; j < p_t_kaava1; j++) {
        if (j !== 0) {
          var x = document.createElement("div");
          tas_vord = (j * l_i) / 5 + "px";
          x.style.left = tas_vord;
          x.classList.add("tyostot__tyosto");
          x.classList.add("tyostot__tyosto_pysty");
          x.style.height = "100%";
          x.style.width = parseFloat(8 / 5) + "px";
          x.style.position = "absolute";
          levy_tyostot_x.prepend(x);
          var x_cord = document.createElement("input");
          x_cord.setAttribute("onchange", "change__tyostocord(this,1);");
          x_cord.classList.add("x_cord_mki");
          x_cord.type = "text";
          x_cord.classList.add("x_cord");
          cord = (j * (l_i) - (j - 1) * (parseFloat(l_i)));
          x_cord.value = cord.toFixed(0);
          x_cord.dataset.from = x_cord.value;
          x_cord.style.float = "right";
          // x_cord.style.left = cord/10 + "px";
          x.prepend(x_cord);
          var x_del = document.createElement("div");
          x_del.classList.add("x_del");
          x_del.setAttribute("onclick", "tyosto__del(this);");
          x.prepend(x_del);
        }
      }
    }
    t_last_right(levy, levy_tyostot_x, evt);
    t_last_left(levy, levy_tyostot_x, evt);
  }
  //VAAKAKIINNIKKEET
  if (evt === 5 || evt === 6 || evt === 7 || evt === 8) {
    let tyosto_levy = levy.querySelectorAll(".tyostot__tyosto_vaaka");
    for (var i = tyosto_levy.length - 1; i >= 0; i--) {
      tyosto_levy[i].remove()
    }
    l_i = document.querySelector("#v_target").value;
    v_u = parseFloat(document.querySelector("#settings__levy_yr_arvo").value);
    v_b = parseFloat(document.querySelector("#settings__levy_ar_arvo").value);
    width_levy = parseFloat(document.querySelector("#k_settings__levy_levysizeh").value);
    v_w_ = (width_levy - (v_u + v_b));
    v_kaava1 = v_w_ / l_i;
    if (v_w_ < k_min_w) {
      v_w = -1;
      p_kaava1 = 0;
      v_c_kaava1 = 0;
      v_t_kaava1 = 0;
    }
    else {
      v_w = v_w_;
      v_c_kaava1 = parseFloat(1 + Math.ceil(v_kaava1));
      v_t_kaava1 = parseFloat(1 + Math.trunc(v_kaava1));
    }
    // l_i = 
    if (evt === 5 && k_min_w < parseFloat(k_main_levy_[1]) || evt === 6 && k_min_w < parseFloat(k_main_levy_[1])) {
      for (var g = 1; g < v_t_kaava1; g++) {
        if (evt === 5) {
          var x = document.createElement("div");
          bottom_cord = (parseFloat(l_i) * g) / 5 + "px";
          x.style.bottom = bottom_cord;
          x.classList.add("tyostot__tyosto");
          x.classList.add("tyostot__tyosto_vaaka");
          x.style.width = "100%";
          x.style.height = parseFloat(8 / 5) + "px";
          x.style.position = "absolute";
          levy_tyostot_y.prepend(x);
          var x_cord = document.createElement("input");
          x_cord.setAttribute("onchange", "change__tyostocord(this,1);");
          x_cord.classList.add("x_cord_mki");
          x_cord.type = "text";
          cord = parseFloat((parseFloat(l_i) * (g))) - parseFloat((parseFloat(l_i) * (g - 1)));
          x_cord.value = cord.toFixed(0);
          x_cord.dataset.from = x_cord.value;
          x_cord.style.top = "-15px";
          x.prepend(x_cord);
          var x_del = document.createElement("div");
          x_del.classList.add("x_del");
          x_del.setAttribute("onclick", "tyosto__del(this);");
          x.prepend(x_del);
          levy.append(levy_tyostot_y);
        }
        else if (evt === 6) {
          var x = document.createElement("div");
          top_cord = (parseFloat(l_i) * g) / 5 + "px";
          x.style.bottom = top_cord;
          x.classList.add("tyostot__tyosto");
          x.classList.add("tyostot__tyosto_vaaka");
          x.style.width = "100%";
          x.style.height = parseFloat(8 / 5) + "px";
          x.style.position = "absolute";
          levy_tyostot_y.prepend(x);
          var x_cord = document.createElement("input");
          x_cord.setAttribute("onchange", "change__tyostocord(this,1);");
          x_cord.classList.add("x_cord_mki");
          x_cord.type = "text";
          cord = parseFloat((parseFloat(l_i) * (g))) - parseFloat((parseFloat(l_i) * (g - 1)));
          x_cord.value = cord.toFixed(0);
          x_cord.dataset.from = x_cord.value;
          // x_cord.style.top = "-15px";
          x.prepend(x_cord);
          var x_del = document.createElement("div");
          x_del.classList.add("x_del");
          x_del.setAttribute("onclick", "tyosto__del(this);");
          x.prepend(x_del);
          levy.append(levy_tyostot_y);
        }
      }
    }
    if (evt === 8) {
      if (isEven(v_t_kaava1)) {}
      else {
        v_t_kaava1 += 1;
      }
    }
    if (evt === 7 && k_min_w < parseFloat(k_main_levy_[1]) || evt === 8 && k_min_w < parseFloat(k_main_levy_[1])) {
      areas = Math.ceil(v_kaava1);
      lahinmodmitta = (v_w / 25);
      modcount = Math.floor((lahinmodmitta) / areas);
      l_i = parseFloat(modcount * 25);
      v_t_kaava1 = Math.floor(v_w / l_i);
      for (var g = 1; g < v_t_kaava1; g++) {
        if (g !== 0) {
          var x = document.createElement("div");
          tas_vord = (g * l_i) / 5 + "px";
          x.style.bottom = tas_vord;
          x.classList.add("tyostot__tyosto");
          x.classList.add("tyostot__tyosto_vaaka");
          x.style.width = "100%";
          x.style.height = parseFloat(8 / 5) + "px";
          x.style.position = "absolute";
          levy_tyostot_y.appendChild(x);
          var x_cord = document.createElement("input");
          x_cord.setAttribute("onchange", "change__tyostocord(this,1);");
          x_cord.classList.add("x_cord_mki");
          x_cord.type = "text";
          cord = (g * l_i) - ((g - 1) * l_i);
          x_cord.value = cord.toFixed(0);
          x_cord.dataset.from = x_cord.value;
          // x_cord.style.bottom = "19px";
          x.prepend(x_cord);
          var x_del = document.createElement("div");
          x_del.classList.add("x_del");
          x_del.setAttribute("onclick", "tyosto__del(this);");
          x.prepend(x_del);
        }
      }
    }
    t_last_top(levy, levy_tyostot_y, evt);
    t_last_bottom(levy, levy_tyostot_y, evt);
  }
  // levy.setAttribute("data-levy_x",(parseFloat(levy_c_x-levy_c_y)));
  // levy.setAttribute("data-levy_y",(parseFloat(levy_c_y)));
  l_meta = {};
}

function t_last_top(levy, tyosto, evt) {
  var interval = parseFloat(document.querySelector("#settings__levy_yr_arvo").value);
  var x = document.createElement("div");
  x.classList.add("tyostot__tyosto");
  x.classList.add("tyostot__tyosto_vaaka");
  x.classList.add("viim__tyosto_vaaka");
  x.classList.add("no_siirto");
  x.style.width = "100%";
  x.style.height = parseFloat(8 / 5) + "px";
  x.style.position = "absolute";
  x.style.bottom = (parseFloat(levy_meta[1] - interval)) / 5 + "px";
  tyosto.prepend(x);
  if (evt === 5 || evt === 7 || evt === 8) {
    var x_cord = document.createElement("input");
    // x_cord.setAttribute("onchange","change__tyostocord(this,1);");
    x_cord.classList.add("x_cord_mki");
    x_cord.type = "text";
    v_u = parseFloat(document.querySelector("#settings__levy_yr_arvo").value);
    v_b = parseFloat(document.querySelector("#settings__levy_ar_arvo").value);
    v_w = (levy_meta[1] - (v_u + v_b));
    var i_ = 0;
    let gg = levy.querySelectorAll(".levy_tyostot_y > div > input");
    for (var g = 0; g < gg.length; g++) {
      i_ += parseFloat(gg[g].value);
    }
    // x_cord.style.bottom = (v_w - i_)/10+"px";
    x_cord.value = (v_w - i_);
    x_cord.dataset.from = x_cord.value;
    x.prepend(x_cord);
    var x_last_cord = document.createElement("input");
    x_last_cord.type = "text";
    x_last_cord.classList.add("x_cord");
    x_last_cord.classList.add("y_cord_border");
    x_last_cord_cord = parseFloat(levy_meta[1]) - parseFloat(x.style.bottom) * 5;
    x_last_cord.value = v_u;
    x.prepend(x_last_cord);
  }
  else {
    var x_cord = document.createElement("input");
    x_cord.setAttribute("onchange", "change__tyostocord(this,1);");
    x_cord.classList.add("x_cord_mki");
    x_cord.type = "text";
    x_cord.classList.add("x_cord");
    x_cord.classList.add("y_cord_border");
    cord = parseFloat(x.style.bottom) * 5;
    x_cord.value = v_u;
    x_cord.dataset.from = x_cord.value;
    x.prepend(x_cord);
  }
}

function t_last_right(levy, tyosto, evt) {
  var interval = parseFloat(document.querySelector("#settings__levy_or_arvo").value);
  p_left = parseFloat(document.querySelector("#settings__levy_vr_arvo").value);
  p_right = parseFloat(document.querySelector("#settings__levy_or_arvo").value);
  p_h = (levy_meta[0] - (p_left + p_right));
  var x = document.createElement("div");
  x.classList.add("tyostot__tyosto");
  x.classList.add("tyostot__tyosto_pysty");
  x.classList.add("viim__tyosto_pysty");
  x.classList.add("no_siirto");
  x.style.height = "100%";
  x.style.width = parseFloat(8 / 5) + "px";
  x.style.position = "absolute";
  x.style.left = ((parseFloat(8 / 5) * (-5)) + parseFloat(levy_meta[0] - interval)) / 5 + "px";
  tyosto.prepend(x);
  if (evt === 2 || evt === 3 || evt === 4) {
    var x_cord = document.createElement("input");
    // x_cord.setAttribute("onchange","change__tyostocord(this,1);");
    x_cord.classList.add("x_cord_mki");
    x_cord.type = "text";
    var i_ = 0;
    let jj = levy.querySelectorAll(".levy_tyostot_x > div > input");
    for (var j = 0; j < jj.length; j++) {
      i_ += parseFloat(jj[j].value);
    }
    cord = (parseFloat(p_h - i_));
    x_cord.value = cord.toFixed(0);
    x_cord.dataset.from = x_cord.value;
    if (evt === 1) {
      // x_cord.style.right = cord/10 + "px";
    }
    else if (evt === 2 || evt === 3 || evt === 4) {
      // x_cord.style.left = cord/10 + "px";
      x_cord.style.float = "right";
    }
    x.prepend(x_cord);
    var x_last_cord = document.createElement("input");
    x_last_cord.type = "text";
    x_last_cord.classList.add("x_cord");
    x_last_cord.classList.add("x_cord_border");
    x_last_cord_cord = parseFloat(levy_meta[0]) - parseFloat(x.style.left) * 5;
    x_last_cord.value = p_right;
    x.prepend(x_last_cord);
  }
  else {
    var x_cord = document.createElement("input");
    // x_cord.setAttribute("onchange","change__tyostocord(this,1);");
    x_cord.classList.add("x_cord_mki");
    x_cord.type = "text";
    x_cord.classList.add("x_cord");
    x_cord.classList.add("x_cord_border");
    cord = parseFloat(x.style.left) * 5;
    x_cord.value = p_right;
    x_cord.dataset.from = x_cord.value;
    x.prepend(x_cord);
  }
}

function t_last_left(levy, tyosto, evt) {
  var interval = parseFloat(document.querySelector("#settings__levy_vr_arvo").value);
  var x = document.createElement("div");
  x.classList.add("tyostot__tyosto");
  x.classList.add("tyostot__tyosto_pysty");
  x.classList.add("alku__tyosto_pysty");
  x.classList.add("no_siirto");
  x.style.height = "100%";
  x.style.width = parseFloat(8 / 5) + "px";
  x.style.position = "absolute";
  x.style.left = parseFloat(interval) / 5 + "px";
  tyosto.prepend(x);
  if (evt === 1) {
    var x_cord = document.createElement("input");
    x_cord.setAttribute("onchange", "change__tyostocord(this,1);");
    x_cord.classList.add("x_cord_mki");
    x_cord.type = "text";
    var i_ = 0;
    let jj = levy.querySelectorAll(".levy_tyostot_x > div > input");
    for (var j = 0; j < jj.length; j++) {
      i_ += parseFloat(jj[j].value);
    }
    cord = (parseFloat(p_h - i_));
    x_cord.value = cord.toFixed(2);
    x_cord.dataset.from = x_cord.value;
    if (evt === 1) {
      // x_cord.style.right = cord/10 + "px";
    }
    x.prepend(x_cord);
    var x_last_cord = document.createElement("input");
    x_last_cord.type = "text";
    x_last_cord.classList.add("x_cord");
    x_last_cord.classList.add("x_cord_border");
    x_last_cord_cord = parseFloat(levy_meta[0]) - parseFloat(x.style.left) * 5;
    x_last_cord.value = p_left;
    x.prepend(x_last_cord);
  }
  else {
    var x_cord = document.createElement("input");
    x_cord.setAttribute("onchange", "change__tyostocord(this,1);");
    x_cord.classList.add("x_cord_mki");
    x_cord.type = "text";
    x_cord.classList.add("x_cord");
    x_cord.classList.add("x_cord_border");
    cord = parseFloat(x.style.left) * 5;
    x_cord.value = p_left;
    x_cord.dataset.from = x_cord.value;
    x.prepend(x_cord);
  }
}

function t_last_bottom(levy, tyosto, evt) {
  var interval = parseFloat(document.querySelector("#settings__levy_ar_arvo").value);
  var x = document.createElement("div");
  x.classList.add("tyostot__tyosto");
  x.classList.add("tyostot__tyosto_vaaka");
  x.classList.add("alku__tyosto_vaaka");
  x.classList.add("no_siirto");
  x.style.width = "100%";
  x.style.height = parseFloat(8 / 5) + "px";
  x.style.position = "absolute";
  x.style.bottom = (parseFloat(interval) / 5 + "px");
  tyosto.prepend(x);
  if (evt === 6) {
    var x_cord = document.createElement("input");
    // x_cord.setAttribute("onchange","change__tyostocord(this,1);");
    x_cord.classList.add("x_cord_mki");
    x_cord.type = "text";
    var i_ = 0;
    let gg = levy.querySelectorAll(".levy_tyostot_y > div > input");
    for (var g = 0; g < gg.length; g++) {
      i_ += parseFloat(gg[g].value);
    }
    v_u = parseFloat(document.querySelector("#settings__levy_yr_arvo").value);
    v_b = parseFloat(document.querySelector("#settings__levy_ar_arvo").value);
    v_w = (levy_meta[1] - (v_u + v_b));
    // x_cord.style.top = "-15px";
    x_cord.type = "text";
    x_cord.value = (v_w - i_);
    x_cord.dataset.from = x_cord.value;
    x.prepend(x_cord);
    var x_last_cord = document.createElement("input");
    x_last_cord.type = "text";
    x_last_cord.classList.add("x_cord");
    x_last_cord.classList.add("y_cord_border");
    x_last_cord_cord = v_b;
    x_last_cord.value = x_last_cord_cord.toFixed(2);
    x.prepend(x_last_cord);
  }
  else {
    var x_cord = document.createElement("input");
    // x_cord.setAttribute("onchange","change__tyostocord(this,1);");
    x_cord.classList.add("x_cord_mki");
    x_cord.type = "text";
    x_cord.classList.add("x_cord");
    x_cord.classList.add("y_cord_border");
    cord = parseFloat(x.style.bottom) * 5;
    x_cord.value = v_b;
    x_cord.dataset.from = x_cord.value;
    x.prepend(x_cord);
  }
  // var x_cord = document.createElement("input");
  // x_cord.value = (interval);
  // x.prepend(x_cord);
}

function kiinnikkeet__siirto() {
  let levytys = document.querySelectorAll('.levyt .levy');
  levytys_array = [];
  for (var i = 0; i < levytys.length; i++) {
    titteli = levytys[i].title.split(",");
    title = titteli[0] + "," + titteli[1];
    levytys_array.push("" + title + "");
  }
  levy_siirto = levytys_array.filter((element, index) => {
    return levytys_array.indexOf(element) === index;
  });
  levy_siirto.sort(function(a, b) {
    return b.replace(",", "") - a.replace(",", "");
  });
  if (document.querySelector(".levy_type")) {
    l_t = document.querySelectorAll(".levy_type");
    for (var i = l_t.length - 1; i >= 0; i--) {
      l_t[i].remove();
    }
  }
  levytypes_target = document.querySelector(".levy_types");
  br = 0
  for (var i = levy_siirto.length - 1; i >= 0; i--) {
    n_m = "'" + levy_siirto[i].replace(",", "x") + "'";
    l = document.createElement("div");
    l.classList.add("levy_type");
    l.setAttribute("onclick", "change__klevy(" + (n_m) + ");");
    l.innerHTML = String(n_m);
    levytypes_target.prepend(l);
    var addclass = 'selected';
    var $cols = $('.levy_type').click(function(e) {
      $cols.removeClass(addclass);
      $(this).addClass(addclass);
    });
  }
  document.querySelectorAll(".levy_type")[0].click();
}

function change__klevy(info) {
  info_cord = String(info).replace("'", "").split("x");
  if (document.querySelector("#drawscreen_section_tyostot .visible")) {
    levy = document.querySelector("#drawscreen_section_tyostot .visible");
  }
  else {
    levy = document.createElement("div");
    levy.classList.add("visible");
    levy.classList.add("levy");
    if (document.querySelector("#settings__sauma_pysty").checked) {
      levy.classList.add("dir_y");
    }
    else if (document.querySelector("#settings__sauma_vaaka").checked) {
      levy.classList.add("dir_x");
    }
    if (document.querySelector(".levy_vis")) {
      if (document.querySelector(".levy_vis").innerHTML.length < 10) {
        document.querySelector(".levy_vis").prepend(levy);
      }
    }
    horizontalinputs_left = document.createElement("section");
    horizontalinputs_right = document.createElement("section");
    horizontalinputs_up = document.createElement("section");
    horizontalinputs_down = document.createElement("section");
    horizontalinputs_left.classList.add("horizontalinputs");
    horizontalinputs_right.classList.add("horizontalinputs");
    horizontalinputs_up.classList.add("verticalinputs");
    horizontalinputs_down.classList.add("verticalinputs");
    horizontalinputs_left.classList.add("horizontalinputs-left");
    horizontalinputs_right.classList.add("horizontalinputs-right");
    horizontalinputs_up.classList.add("verticalinputs-up");
    horizontalinputs_down.classList.add("verticalinputs-down");
    horizontalinputs_left
    horizontalinputs_right
    horizontalinputs_up.style.marginLeft = "30px";
    horizontalinputs_up.style.float = "right";
    horizontalinputs_up.style.top = "top:-30px;";
    horizontalinputs_down.style.marginLeft = "30px";
    horizontalinputs_left.innerHTML =
      '<div style="margin-top: 50px;" class="tyosto_measure"><input type="text" name="_levymod" value="32.5" min="20" max="80" class="lineinput drawarea__mm levy_input" id="k_vrlevy" onchange="change__levykiinnike();"><label for="">VR LEVY</label></div>';
    horizontalinputs_right.innerHTML =
      '<div style="margin-top: 50px;" class="tyosto_measure"><input type="text" name="_levymod" value="32.5" min="20" max="80" class="lineinput drawarea__mm levy_input" id="k_orlevy" onchange="change__levykiinnike();"><label for="">OR LEVY</label></div>';
    horizontalinputs_up.innerHTML =
      ' <div style="" class="tyosto_measure"><input type="text" name="_levymod" value="32.5" min="20" max="80" class="lineinput drawarea__mm levy_input" id="k_yrlevy" onchange="change__levykiinnike();"><label for="">YR LEVY</label></div>';
    horizontalinputs_down.innerHTML =
      ' <div style="" class="tyosto_measure"><input type="text" name="_levymod" value="32.5" min="20" max="80" class="lineinput drawarea__mm levy_input" id="k_arlevy" onchange="change__levykiinnike();"><label for="">AR LEVY</label></div>';
    levy.append(horizontalinputs_left);
    levy.append(horizontalinputs_right);
    levy.append(horizontalinputs_up);
    levy.append(horizontalinputs_down);
  }
  var verticalinputs_up = document.querySelector(".verticalinputs-up");
  var verticalinputs_down = document.querySelector(".verticalinputs-down");
  levy.style.width = (info_cord[0] / 5) + "px";
  levy.style.height = (info_cord[1] / 5) + "px";
  levy.classList.add("levy");
  levy.style.width = (info_cord[0] / 5) + "px";
  verticalinputs_up.style.left = (info_cord[0] / 5) + "px";
  verticalinputs_down.style.left = (info_cord[0] / 5) + "px";
  verticalinputs_down.style.top = (info_cord[1] / 5) + "px";
  levy.title = info_cord[0] + "," + info_cord[1];
  document.querySelector("#k_settings__levy_levysizew").value = parseFloat(info_cord[0]);
  document.querySelector("#k_settings__levy_levysizeh").value = parseFloat(info_cord[1]);
  aloita_tyosto_kiinnikkeet();
}
//////////////////////////////////// Esikatselusta
function change__tyostocord(input, secondsetting) {
  oldvalue = input.dataset.from;
  let c_kiinnikkeet = canvas.querySelectorAll(".tyostot__tyosto");
  k_x = [];
  k_y = [];
  tochange_array_x = [];
  tochange_array_y = [];
  for (var i = c_kiinnikkeet.length - 1; i >= 0; i--) {
    k_x.push(c_kiinnikkeet[i].getBoundingClientRect().left);
    k_y.push(c_kiinnikkeet[i].getBoundingClientRect().bottom);
  }
  if ((input.parentElement.parentElement).classList.contains("levy")) {
    thislevy = input.parentElement;
  }
  else if ((input.parentElement.parentElement.parentElement).classList.contains("levy")) {
    thislevy = input.parentElement.parentElement;
  }
  if ((input.parentElement).classList.contains("tyostot__tyosto")) {
    thistyosto = input.parentElement;
  }
  else if ((input.parentElement.parentElement).classList.contains("tyostot__tyosto")) {
    thistyosto = input.parentElement.parentElement;
  }
  k_x_array = removeDuplicates(k_x);
  k_y_array = removeDuplicates(k_y);
  thisinput_l = input.parentElement.getBoundingClientRect().left;
  thisinput_b = input.parentElement.getBoundingClientRect().bottom;
  tochange_array_x.push(thisinput_l);
  tochange_array_y.push(thisinput_b);
  for (var i = k_x_array.length - 1; i >= 0; i--) {
    if (thisinput_l === k_x_array[i]) {
      tochange_array_x.push(k_x_array[i]);
    }
  }
  for (var i = k_y_array.length - 1; i >= 0; i--) {
    if (thisinput_b === k_y_array[i]) {
      tochange_array_y.push(k_y_array[i]);
    }
  }
  x = removeDuplicates(tochange_array_x);
  y = removeDuplicates(tochange_array_y);
  if (thistyosto.classList.contains("tyostot__tyosto_pysty")) {
    old_cord = parseFloat(thistyosto.style.left);
  }
  else if (thistyosto.classList.contains("tyostot__tyosto_vaaka")) {
    old_cord = parseFloat(thistyosto.style.bottom);
  }
  barent = input.parentElement;
  grandbarent = barent.parentElement;
  elements = grandbarent.querySelectorAll(".tyostot__tyosto");
  currentIndex = Array.from(elements).indexOf(barent);
  newvalue = parseFloat(input.value);
  erotus = oldvalue - newvalue;
  if (secondsetting === 1) {
    new_cord = (parseFloat(old_cord) - (parseFloat(erotus) / 5)) + "px";
    if (thistyosto.classList.contains("tyostot__tyosto_pysty")) {
      thistyosto.style.left = new_cord;
      input.dataset.from = parseFloat(input.value);
      thistyosto.querySelector(".secondcord").value = parseFloat(thistyosto.style.left) * 5;
      for (var i = c_kiinnikkeet.length - 1; i >= 0; i--) {
        if (thisinput_l === c_kiinnikkeet[i].getBoundingClientRect().left) {
          c_kiinnikkeet[i].style.left = new_cord;
          if (c_kiinnikkeet[i].querySelector("input")) {
            c_kiinnikkeet[i].querySelector("input").value = newvalue;
          }
          if (c_kiinnikkeet[i].parentElement.querySelector("input.secondcord")) {
            c_kiinnikkeet[i].parentElement.querySelector("input.secondcord").value = parseFloat(c_kiinnikkeet[i].style.left) * 5;
          }
        }
      }
      thistyosto.querySelector(".secondcord").value = parseFloat(thistyosto.style.left) * 5;
    }
    else if (thistyosto.classList.contains("tyostot__tyosto_vaaka")) {
      thistyosto.style.bottom = new_cord;
      input.dataset.from = parseFloat(input.value);
      thistyosto.querySelector(".secondcord").value = parseFloat(thistyosto.style.bottom) * 5;
      for (var i = c_kiinnikkeet.length - 1; i >= 0; i--) {
        if (thisinput_b === c_kiinnikkeet[i].getBoundingClientRect().bottom) {
          c_kiinnikkeet[i].style.bottom = new_cord;
          if (c_kiinnikkeet[i].querySelector("input")) {
            c_kiinnikkeet[i].querySelector("input").value = newvalue;
          }
          if (c_kiinnikkeet[i].parentElement.querySelector("input.secondcord")) {
            c_kiinnikkeet[i].parentElement.querySelector("input.secondcord").value = parseFloat(c_kiinnikkeet[i].style.bottom) * 5;
          }
        }
      }
    }
    boxHeight = parseFloat(document.querySelector('#box-wrapper > main').offsetHeight);
    boxWidth = parseFloat(document.querySelector('#box-wrapper > main').offsetWidth);
    if (thistyosto.classList.contains("tyostot__tyosto_pysty")) {
      if (grandbarent.querySelectorAll('.tyostot__tyosto')[currentIndex - 1]) {
        n_elem = grandbarent.querySelectorAll('.tyostot__tyosto')[currentIndex - 1];
        if (n_elem.classList.contains("viim__tyosto_pysty") || n_elem.classList.contains("viim__tyosto_vaaka")) {
          n_input = n_elem.querySelectorAll("input")[1];
        }
        else {
          n_input = n_elem.querySelectorAll("input")[0];
        }
        n_elem.querySelector(".secondcord").value = parseFloat(n_elem.style.left) * 5;
        n_input.value = parseFloat(n_elem.querySelector(".secondcord").value) - parseFloat(thistyosto.querySelector(".secondcord").value);
      }
    }
    else if (thistyosto.classList.contains("tyostot__tyosto_vaaka")) {
      if (grandbarent.querySelectorAll('.tyostot__tyosto')[currentIndex - 1]) {
        n_elem = grandbarent.querySelectorAll('.tyostot__tyosto')[currentIndex - 1];
        if (n_elem.classList.contains("viim__tyosto_pysty") || n_elem.classList.contains("viim__tyosto_vaaka")) {
          n_input = n_elem.querySelectorAll("input")[1];
        }
        else {
          n_input = n_elem.querySelectorAll("input")[0];
        }
        n_input.value = parseFloat(n_input.dataset.from) + parseFloat(erotus);
        n_elem.querySelector(".secondcord").value = parseFloat(n_elem.style.bottom) * 5;
        n_elem.querySelector(".secondcord").value = parseFloat(n_elem.style.bottom) * 5;
        n_input.value = parseFloat(n_elem.querySelector(".secondcord").value) - parseFloat(thistyosto.querySelector(".secondcord").value);
      }
    }
    // n_input.dataset.from = parseFloat(n_input.value);
  }
  else if (secondsetting === 2) {
    new_cord = (parseFloat(old_cord) - (parseFloat(erotus))) + "px";
    mki_input_val = parseFloat(thistyosto.querySelector(".x_cord_mki").value);
    if (thistyosto.classList.contains("tyostot__tyosto_pysty")) {
      thistyosto.style.left = parseFloat(input.value) / 5 + "px";
      input.dataset.from = parseFloat(input.value);
      mki_input_val = parseFloat(thistyosto.querySelector(".x_cord_mki").value);
      thistyosto.querySelector(".x_cord_mki").dataset.from = mki_input_val - erotus;
      thistyosto.querySelector(".x_cord_mki").value = mki_input_val - erotus;
      for (var i = c_kiinnikkeet.length - 1; i >= 0; i--) {
        if (thisinput_l === c_kiinnikkeet[i].getBoundingClientRect().left) {
          c_kiinnikkeet[i].style.left = parseFloat(input.value) / 5 + "px";;
          if (c_kiinnikkeet[i].querySelector("input")) {
            c_kiinnikkeet[i].querySelector("input").value = newvalue;
          }
          if (c_kiinnikkeet[i].parentElement.querySelector("input.x_cord_mki")) {
            c_kiinnikkeet[i].parentElement.querySelector("input.x_cord_mki").value = parseFloat(c_kiinnikkeet[i].style.left) * 5;
          }
        }
      }
    }
    else if (thistyosto.classList.contains("tyostot__tyosto_vaaka")) {
      thistyosto.style.bottom = parseFloat(input.value) / 5 + "px";
      input.dataset.from = parseFloat(input.value);
      realval = mki_input_val - erotus;
      console.log("realval " + realval);
      console.log("mki_input_val " + mki_input_val);
      console.log("erotus " + erotus);
      thistyosto.querySelector(".x_cord_mki").dataset.from = parseFloat(realval);
      thistyosto.querySelector(".x_cord_mki").value = parseFloat(realval);
      for (var i = c_kiinnikkeet.length - 1; i >= 0; i--) {
        if (thisinput_b === c_kiinnikkeet[i].getBoundingClientRect().bottom) {
          c_kiinnikkeet[i].style.bottom = parseFloat(input.value) / 5 + "px";;
          if (c_kiinnikkeet[i].querySelector("input")) {
            c_kiinnikkeet[i].querySelector("input").value = newvalue;
          }
          if (c_kiinnikkeet[i].parentElement.querySelector("input.x_cord_mki")) {
            c_kiinnikkeet[i].parentElement.querySelector("input.x_cord_mki").value = parseFloat(c_kiinnikkeet[i].style.bottom) / 5;
          }
        }
      }
    }
    boxHeight = parseFloat(document.querySelector('#box-wrapper > main').offsetHeight);
    boxWidth = parseFloat(document.querySelector('#box-wrapper > main').offsetWidth);
    if (thistyosto.classList.contains("tyostot__tyosto_pysty")) {
      if (grandbarent.querySelectorAll('.tyostot__tyosto')[currentIndex - 1]) {
        n_elem = grandbarent.querySelectorAll('.tyostot__tyosto')[currentIndex - 1];
        if (n_elem.classList.contains("viim__tyosto_pysty") || n_elem.classList.contains("viim__tyosto_vaaka")) {
          n_input = n_elem.querySelectorAll("input")[1];
        }
        else {
          n_input = n_elem.querySelectorAll("input")[0];
        }
        n_elem.querySelector(".secondcord").value = parseFloat(n_elem.style.left) * 5;
        n_input.value = parseFloat(n_elem.querySelector(".secondcord").value) - parseFloat(thistyosto.querySelector(".secondcord").value);
      }
    }
    else if (thistyosto.classList.contains("tyostot__tyosto_vaaka")) {
      if (grandbarent.querySelectorAll('.tyostot__tyosto')[currentIndex - 1]) {
        n_elem = grandbarent.querySelectorAll('.tyostot__tyosto')[currentIndex - 1];
        if (n_elem.classList.contains("viim__tyosto_pysty") || n_elem.classList.contains("viim__tyosto_vaaka")) {
          n_input = n_elem.querySelectorAll("input")[1];
        }
        else {
          n_input = n_elem.querySelectorAll("input")[0];
        }
        n_elem.querySelector(".secondcord").value = parseFloat(n_elem.style.bottom) * 5;
        n_input.value = parseFloat(n_elem.querySelector(".secondcord").value) - parseFloat(thistyosto.querySelector(".secondcord").value);
      }
    }
    // n_input.dataset.from = parseFloat(n_input.value);
  }
}

function tallenna_kiinnikepaikat(levy) {
  kiinnikkeet = levy.querySelectorAll(".tyostot__tyosto");
  l_meta = levy.querySelector(".l_meta");
  l_meta.value = "";
  l_meta_x = [];
  l_meta_y = [];
  kiinnike_inputy = [];
  kiinnike_inputx = [];
  for (var i = kiinnikkeet.length - 1; i >= 0; i--) {
    if (kiinnikkeet[i]) {
      if (kiinnikkeet[i].classList.contains("tyostot__tyosto_vaaka")) {
        kiinnike_inputy.push(kiinnikkeet[i]);
      }
      if (kiinnikkeet[i].classList.contains("tyostot__tyosto_pysty")) {
        kiinnike_inputx.push(kiinnikkeet[i]);
      }
    }
  }
  for (var y = kiinnike_inputy.length - 1; y >= 0; y--) {
    k_input = kiinnike_inputy[y].querySelectorAll("input");
    for (var k = k_input.length - 1; k >= 0; k--) {
      l_meta_y.push(k_input[k].value);
    }
  }
  for (var x = kiinnike_inputx.length - 1; x >= 0; x--) {
    k_input = kiinnike_inputx[x].querySelectorAll("input");
    for (var k = k_input.length - 1; k >= 0; k--) {
      l_meta_x.push(k_input[k].value);
    }
  }
  l_meta.value = ("{" + l_meta_x + "}," + "{" + l_meta_y + "}");
  // console.log("l_meta_x: " + l_meta_x);
  // console.log("l_meta_y: " + l_meta_y);
}

function fixkiinnikkeet(levy) {
  levy_tyostot_x = levy.querySelectorAll(".levy_tyostot_x");
  levy_tyostot_y = levy.querySelectorAll(".levy_tyostot_y");
  for (var i = levy_tyostot_x.length - 1; i >= 0; i--) {
    tyostot = levy_tyostot_x[i].querySelectorAll(".tyostot__tyosto");
    tyosto_array = [];
    for (var j = tyostot.length - 1; j >= 0; j--) {
      tyosto_array.push(tyostot[j]);
      tyostot[j].remove();
    }
    sortedtyosto_array = Array.from(tyosto_array).sort((a, b) => {
      const leftA = parseInt(a.style.left);
      const leftB = parseInt(b.style.left);
      return leftA - leftB;
    });
    for (var j = 0; j < sortedtyosto_array.length; j++) {
      levy_tyostot_x[i].prepend(sortedtyosto_array[j]);
    }
  }
  for (var i = levy_tyostot_y.length - 1; i >= 0; i--) {
    tyosto = levy_tyostot_y[i].querySelectorAll(".tyostot__tyosto");
    tyosto_array = [];
    for (var j = tyosto.length - 1; j >= 0; j--) {
      tyosto_array.push(tyosto[j]);
      tyosto[j].remove();
    }
    sortedtyosto_array = Array.from(tyosto_array).sort((a, b) => {
      const bottomA = parseInt(a.style.bottom);
      const bottomB = parseInt(b.style.bottom);
      return bottomA - bottomB;
    });
    for (var j = 0; j < sortedtyosto_array.length; j++) {
      levy_tyostot_y[i].prepend(sortedtyosto_array[j]);
    }
  }
  title = levy.getAttribute("title");
  k_min_h = parseFloat(document.querySelector("#p_two").value);
  k_min_w = parseFloat(document.querySelector("#v_two").value);
  kiinnikkeet = levy.querySelectorAll(".tyostot__tyosto");
  t_ = title.split(",");
  for (var i = 0; i < kiinnikkeet.length; i++) {
    if (parseFloat(kiinnikkeet[i].style.bottom) > parseFloat(kiinnikkeet[i].parentElement.parentElement.style.height) - 5) {
      kiinnikkeet[i].remove();
    }
  }
  kiinnikkeet = levy.querySelectorAll(".tyostot__tyosto");
  if (parseFloat(t_[0]) < k_min_h) {
    // console.log("IJJJ: " + parseFloat(t_[0]) + " DD " + k_min_h);
    for (var i = kiinnikkeet.length - 1; i >= 0; i--) {
      if (kiinnikkeet[i].classList.contains("no_siirto") !== true && kiinnikkeet[i].classList.contains("tyostot__tyosto_pysty") === true) {
        kiinnikkeet[i].remove();
        // console.log("OK");
      }
      else {
        // console.log("OK");
        // kiinnikkeet[i].remove();
      }
    }
  }
  if (parseFloat(t_[1]) < k_min_w) {
    // console.log("IJJJ: " + parseFloat(t_[1]) + " DD " + k_min_w);
    for (var i = kiinnikkeet.length - 1; i >= 0; i--) {
      if (kiinnikkeet[i].classList.contains("no_siirto") !== true && kiinnikkeet[i].classList.contains("tyostot__tyosto_vaaka") === true) {
        kiinnikkeet[i].remove();
        console.log("OK");
      }
      else {
        // console.log("OK");
        // kiinnikkeet[i].remove();
      }
    }
  }
  levy_width = t_[0] / 5;
  levy_height = t_[1] / 5;
  kiinnikkeet = levy.querySelectorAll(".tyostot__tyosto");
  for (var i = kiinnikkeet.length - 1; i >= 0; i--) {
    if (kiinnikkeet[i].parentElement) {}
    if (kiinnikkeet[i].parentElement.querySelector(".tyostot__tyosto_vaaka")) {
      kiinnike_input_y = kiinnikkeet[i].parentElement.querySelectorAll(".tyostot__tyosto_vaaka");
      // console.log("Y " + kiinnike_input_y.innerHTML);
      for (var y = kiinnike_input_y.length - 1; y >= 0; y--) {
        k_input = kiinnike_input_y[y].querySelectorAll("input");
        for (var k = k_input.length - 1; k >= 0; k--) {
          //console.log("k_input: " + k_input[k].value);
          if (parseFloat(k_input[k].value) < 0) {
            oldvalue = k_input[k].value;
            newvalue = parseFloat(document.querySelector("#p_target").value) + parseFloat(oldvalue);
            k_input[k].value = newvalue;
          }
        }
        // console.log("k_input: " + k_input);
        // if(parseFloat(k_input)<0) {
        //   alert(k_input);
        //   // parseFloat(document.querySelector("#p_target"))-parseFloat(k_input);
        //   // k_input.remove();
        // }
      }
    }
    if (kiinnikkeet[i].parentElement.querySelector(".tyostot__tyosto_pysty")) {
      kiinnike_input_x = kiinnikkeet[i].parentElement.querySelectorAll(".tyostot__tyosto_pysty");
      for (var x = kiinnike_input_x.length - 1; x >= 0; x--) {
        k_input = kiinnike_input_x[x].querySelectorAll("input");
        for (var k = k_input.length - 1; k >= 0; k--) {
          //console.log("k_input: " + k_input[k].value);
          if (parseFloat(k_input[k].value) < 0) {
            oldvalue = k_input[k].value;
            newvalue = parseFloat(document.querySelector("#v_target").value) + parseFloat(oldvalue);
            k_input[k].value = newvalue;
          }
        }
      }
    }
    if (parseFloat(kiinnikkeet[i].style.left) > levy_width) {
      kiinnikkeet[i].parentElement.remove();
    }
    if (parseFloat(kiinnikkeet[i].style.bottom) > levy_height) {
      kiinnikkeet[i].parentElement.remove();
    }
    // let inbuts = levy.querySelectorAll("input");
    // for (var z = 0; z < inbuts.length; z++) {
    //    if (parseFloat(inbuts[z].value) < 0) {
    //       inbuts[z].parentElement.remove();
    //    }
    //    console.log("parseFloat(inbuts[i].value " + parseFloat(inbuts[z].value));
    // }
    boxHeight = parseFloat(document.querySelector('#box-wrapper > main').offsetHeight);
    boxWidth = parseFloat(document.querySelector('#box-wrapper > main').offsetWidth);
    leftend = parseFloat(document.querySelector(".drawarea__right").getBoundingClientRect().left) - 20;
    bottomend = 65;
    t_input = canvas.querySelectorAll(".tyostot__tyosto");
    for (var i = t_input.length - 1; i >= 0; i--) {
      if (t_input[i].querySelector("input")) {
        input = t_input[i].querySelector("input");
        input__left = parseFloat(input.getBoundingClientRect().left);
        input__bottom = parseFloat(input.getBoundingClientRect().top);
        if (input__bottom < bottomend || input__left > leftend) {
          input.parentElement.classList.add("levy_blessedcord");
        }
        else {
          input.remove();
        }
      }
    }
    levy_tyostot_y = levy.querySelector(".levy_tyostot_y");
    if (levy_tyostot_y.querySelectorAll("div").length == 2 || levy_tyostot_y.querySelector("input")) {
      i_s = levy_tyostot_y.querySelectorAll("input");
      console.log(i_s);
      for (var j = i_s.length - 1; j >= 0; j--) {
        if (parseFloat(i_s[j].value) < 0) {
          i_s[j].value = parseFloat(levy_tyostot_y.parentElement.getAttribute("title").split(",")[1]) - 32.5 * 2;
        }
      }
    }
  }
  tyostot__tyosto_vaaka = canvas.querySelectorAll(".tyostot__tyosto_vaaka");
  for (var i = tyostot__tyosto_vaaka.length - 1; i >= 0; i--) {
    if (tyostot__tyosto_vaaka[i].querySelector(".secondcord")) {}
    else {
      if (tyostot__tyosto_vaaka[i].querySelector("input")) {
        // levy_tyostot_y[i].querySelectorAll("input");
        secondcord = document.createElement("input");
        secondcord.type = "text";
        secondcord.classList.add("secondcord");
        secondcord.setAttribute("onchange", "change__tyostocord(this,2)");
        secondcord.value = parseFloat(tyostot__tyosto_vaaka[i].style.bottom) * 5;
        secondcord.dataset.from = parseFloat(tyostot__tyosto_vaaka[i].style.bottom) * 5;
        tyostot__tyosto_vaaka[i].append(secondcord);
      }
    }
  }
  tyostot__tyosto_pysty = canvas.querySelectorAll(".tyostot__tyosto_pysty");
  for (var i = tyostot__tyosto_pysty.length - 1; i >= 0; i--) {
    if (tyostot__tyosto_pysty[i].querySelector(".secondcord")) {}
    else {
      if (tyostot__tyosto_pysty[i].querySelector("input")) {
        secondcord = document.createElement("input");
        secondcord.type = "text";
        secondcord.classList.add("secondcord");
        secondcord.setAttribute("onchange", "change__tyostocord(this,2)");
        secondcord.value = parseFloat(tyostot__tyosto_pysty[i].style.left) * 5;
        secondcord.dataset.from = parseFloat(tyostot__tyosto_pysty[i].style.left) * 5;
        tyostot__tyosto_pysty[i].append(secondcord);
      }
    }
  }
}

function tyosto__del(item) {
  c_kiinnikkeet = canvas.querySelectorAll(".tyostot__tyosto");
  thistyosto = item.parentElement;
  console.log("thistyosto: " + thistyosto);
  if (thistyosto.classList.contains("tyostot__tyosto_pysty")) {
    thisinput_l = parseFloat(thistyosto.getBoundingClientRect().left);
    console.log("thisinput_l: " + thisinput_l);
    for (var i = c_kiinnikkeet.length - 1; i >= 0; i--) {
      console.log("c_kiinnikkeet " + parseFloat(c_kiinnikkeet[i].getBoundingClientRect().left));
      if (Math.round(thisinput_l) == Math.round(parseFloat(c_kiinnikkeet[i].getBoundingClientRect().left))) {
        c_kiinnikkeet[i].remove();
      }
    }
  }
  else if (thistyosto.classList.contains("tyostot__tyosto_vaaka")) {
    thisinput_b = parseFloat(thistyosto.getBoundingClientRect().bottom);
    console.log("thisinput_b: " + thisinput_b);
    for (var i = c_kiinnikkeet.length - 1; i >= 0; i--) {
      console.log("c_kiinnikkeet Btm" + parseFloat(c_kiinnikkeet[i].getBoundingClientRect().bottom));
      if (Math.round(thisinput_b) == Math.round(parseFloat(c_kiinnikkeet[i].getBoundingClientRect().bottom))) {
        c_kiinnikkeet[i].remove();
      }
    }
  }
  // thistyosto.remove();
}
if (document.querySelector("#drawscreen_section_tyostot .levy")) {
  document.querySelector("#drawscreen_section_tyostot .visible").classList.removeClass("levy");
}


function change__levykiinnike(argument) {
  let tyostot = document.querySelectorAll(".levy_input");
  for (var i = 0; i < tyostot.length; i++) {
    var tyosto_id = tyostot[i].getAttribute("id");
    if (tyosto_id == 'k_yrmod' || tyosto_id == 'k_yrlevy') {
      tyostot[i].parentElement.style.marginTop = -(8 / 5) + parseFloat(tyostot[i].value) / 5 + "px";
      document.querySelector("#settings__levy_yr_arvo").value = document.querySelector("#k_yrlevy").value;
    }
    else if (tyosto_id == 'k_armod' || tyosto_id == 'k_arlevy') {
      tyostot[i].parentElement.style.marginTop = -(8 / 5) + parseFloat((-1) * parseFloat(tyostot[i].value) / 5) + "px";
      document.querySelector("#settings__levy_ar_arvo").value = document.querySelector("#k_arlevy").value;
    }
    else if (tyosto_id == 'k_ormod' || tyosto_id == 'k_orlevy') {
      tyostot[i].parentElement.style.marginLeft = -(8 / 5) + parseFloat((-1) * parseFloat(tyostot[i].value) / 5) + "px";
      document.querySelector("#settings__levy_or_arvo").value = document.querySelector("#k_orlevy").value;
    }
    else if (tyosto_id == 'k_vrmod' || tyosto_id == 'k_vrlevy') {
      tyostot[i].parentElement.style.marginLeft = -(8 / 5) + parseFloat(tyostot[i].value) / 5 + "px";
      document.querySelector("#settings__levy_or_arvo").value = document.querySelector("#k_vrlevy").value;
    }
  }
}