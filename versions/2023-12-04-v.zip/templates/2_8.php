<div id="copiedcanvases" style="display: none;">

   <section class="nav rangatnav">
           <nav>
             <ul style="display:flex;flex-direction: column;">
              <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('rooms');">Ristivalikkoon</div></li>
              <li><input type="checkbox" checked id="eight__lvl_one" class="taso_btn drawarea__controls_btn taso__btns_one" onclick="eight__navigation(1);">
              <label for="eight__lvl_one" class="taso__btns_one taso_btn">Näytä kiinnikkeet</label></li>
              
              <li><input type="checkbox" checked id="eight__lvl_two" class="taso_btn drawarea__controls_btn taso__btns_two" onclick="eight__navigation(2)">
              <label for="eight__lvl_two" class="taso__btns_two taso_btn">Näytä Rangat</label></li>
              
              <li><input type="checkbox" checked id="eight__lvl_three" class="taso_btn drawarea__controls_btn taso__btns_three" onclick="eight__navigation(3)">
              <label for="eight__lvl_three" class="taso__btns_three taso_btn">Näytä listat</label></li>
              
             <!--  <input type="checkbox" checked id="eight__lvl_four" class="taso_btn drawarea__controls_btn taso__btns_four" onclick="eight__navigation(4)">
              <label for="eight__lvl_four" class="taso__btns_four taso_btn">Näytä saumat</label> -->
              
              <!-- <input type="checkbox" checked id="eight__lvl_five" class="taso_btn drawarea__controls_btn taso__btns_five" onclick="eight__navigation(5)">
              <label for="eight__lvl_five" class="taso__btns_five taso_btn"></label> -->

              <li><div class="greenbtn" onclick="alert('Tulee myöhemmin');">Lataa Seinän Excel</div></li>
                <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_one');" class="nav__comleted">Origo</div></li>
               <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_two');" class="nav__comleted">Aukot</div></li>
               <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_three');" class="nav__comleted">Läpiviennit</div></li>
               <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_four');" class="nav__comleted">Saumat</div></li>
               <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_five');"class="nav__comleted" >Ladonta</div></li>
               <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_tyostot');"class="nav__comleted" >Kiinnikkeet</div></li>
               <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_eight');" class="nav_current">Seinät</div></li>
               <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_esikatselu');">Levyt</div></li>
               <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_six');">Rangat</div></li>
               <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_seven');">Listat</div></li>
               <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('project_start');">Päävalikkoon</div></li>
               <!-- <li><div onclick="levyta();refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_five');">Seuraava</div></li> -->
             </ul>

           </nav>

         </section>
     
 </div>

