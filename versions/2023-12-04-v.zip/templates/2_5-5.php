<form class="step_screen drawscreen_section form__butsection" action="/updateproject.php" enctype='multipart/form-data' id="drawscreen_section_tyostot">

<section class="tyosto__navigation">
  <section class="nav" style="position:relative;">
     <nav>
        <ul>
           <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('rooms');">Ristivalikkoon</div></li>
           <li>
              <div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_one');" class="nav__comleted">Origo</div>
           </li>
           <li>
              <div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_two');" class="nav__comleted">Aukot</div>
           </li>
           <li>
              <div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_three');" class="nav__comleted">Läpiviennit</div>
           </li>
           <li>
              <div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_four');" class="nav__comleted">Saumat</div>
           </li>
           <li>
              <div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_five');" class="nav__comleted">Ladonta</div>
           </li>
           <li>
              <div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_tyostot');" class="nav_current">Kiinnikkeet</div>
           </li>
           <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_eight');">Seinät</div></li>
           <li>
              <div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_esikatselu');">Levyt</div>
           </li>
           <li>
              <div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_six');">Rangat</div>
           </li>
           <li>
              <div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_seven');">Listat</div>
           </li>
           <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('project_start');">Päävalikkoon</div></li>
         
        </ul>
     </nav>
  </section>
</section>

<div class="ladonta_container">
      <div class="modal-background">
      <div class="modal">
         <div class="modal_close_btn" onclick="open_ladonta_settings(false)"><svg width="20" height="18" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20 1.87367L17.9857 0.0703049L10 7.21983L2.01429 0.0703049L0 1.87367L7.98572 9.0232L0 16.1727L2.01429 17.9761L10 10.8266L17.9857 17.9761L20 16.1727L12.0143 9.0232L20 1.87367Z" fill="#444444"></path></svg></div>
         <div class="row">
            <div class="col-6" style="position: relative;">
              <h1>Levyn Kiinnitykset <br>
               <span id="levy_koko"></span></h1>
               <div class="visible levy_vis" style="">
                   <div class="horizontalinputs horizontalinputs-left">
                      <!-- <div style="" class="tyosto_measure"><label for="" class="k_vrmod">VR MOD</label><input type="text" name="_levymod" value="37.5" class="lineinput drawarea__mm levy_input" id="k_vrmod" onchange="change__levykiinnike();aloita_tyosto_kiinnikkeet();"></div> -->
                      <!-- <div style="margin-top: 50px;" class="tyosto_measure"><input type="text" name="_levymod" value="32.5" min="20" max="80" class="lineinput drawarea__mm levy_input" id="k_vrlevy" onchange="change__levykiinnike();"><label for="">VR LEVY</label></div> -->
                   </div>

                   <div class="horizontalinputs horizontalinputs-right">
                      <!-- <div style="" class="tyosto_measure"><label for="" class="k_ormod">OR MOD</label><input type="text" name="_levymod" value="37.5" class="lineinput drawarea__mm levy_input" id="k_ormod" onchange="change__levykiinnike();aloita_tyosto_kiinnikkeet();"></div> -->
                      <!-- <div style="margin-top: 50px;" class="tyosto_measure"><input type="text" name="_levymod" value="32.5" min="20" max="80" class="lineinput drawarea__mm levy_input" id="k_orlevy" onchange="change__levykiinnike();"><label for="">OR LEVY</label></div> -->
                      
                   </div>

                   <div class="verticalinputs verticalinputs-up" style="left: margin-left:30px;float: right;top:-30px;">
                      <!-- <div style="margin-top: 0%;" class="tyosto_measure"><input type="text" name="_levymod" value="37.5" class="lineinput drawarea__mm levy_input" id="k_yrmod" onchange="change__levykiinnike();aloita_tyosto_kiinnikkeet();"><label for="">YR MOD</label></div> -->
                      <!-- <div style="" class="tyosto_measure"><input type="text" name="_levymod" value="32.5" min="20" max="80" class="lineinput drawarea__mm levy_input" id="k_yrlevy" onchange="change__levykiinnike();"><label for="">YR LEVY</label></div> -->
                   </div>

                   <div class="verticalinputs verticalinputs-down" style=" margin-left:30px;float: right;op: -33px;">
                     <!-- <div class="tyosto_measure"><input type="text" name="_levymod" value="37.5" class="lineinput drawarea__mm levy_input" id="k_armod" onchange="change__levykiinnike();aloita_tyosto_kiinnikkeet();"><label for="">AR MOD</label></div> -->
                     <!-- <div style="" class="tyosto_measure"><input type="text" name="_levymod" value="32.5" min="20" max="80" class="lineinput drawarea__mm levy_input" id="k_arlevy" onchange="change__levykiinnike();"><label for="">AR LEVY</label></div> -->
                   </div>
               </div>
               <div>
                 <table class="myinfo" style="margin-top: 190px;">
                   <tr>
                     <td>Tyyppi</td>
                     <td>Nimi</td>
                     <td>Väri</td>
                     <td>Väli </td>
                   </tr>
                   <tr>
                     <td>Saumaranka: </td>
                     <td></td>
                     <td>Punainen</td>
                     <td></td>
                   </tr>
                   <tr>
                     <td>Levyn väliranka: </td>
                     <td></td>
                     <td>Vihreä</td>
                     <td></td>
                   </tr>
                   <tr>
                     <td>Ikkunaranka: </td>
                     <td></td>
                     <td>Oranssi</td>
                     <td></td>
                   </tr>
                   <tr>
                     <td>Erikoisranka: </td>
                     <td></td>
                     <td>Lila</td>
                     <td></td>
                   </tr>
                 </table>
               </div>
            </div>
            <div class="col-6" style="position: relative;">
             <div class="trow">
               <h5>Tämän projektin levyt:</h5>
               <div class="levy_types">
                 
               </div>
             </div>
               
               <h1>Levyn parametrit, paksuus: <span id="k_thickness">6</span>mm</h1>
               <!-- <input type="hidden" value="drawscreen_section_tyostot" name="step" class="step">
               <input type="hidden" value="" name="wall" class="wall">
               <input type="hidden" value="" name="room" class="room">
               <input type="hidden" value="" name="id" class="id">
               <input type="hidden" value="" name="settings" class="settings">
               <input type="hidden" value="" name="mittapisteet" class="mittapisteet">
               <input type="hidden" value="" name="aukot" class="aukot">
               <input type="hidden" value="" name="reijat" class="reijat">
               <input type="hidden" value="" name="saumat" class="saumat">
               <input type="hidden" value="" name="levyt" class="levyt">
               <input type="hidden" value="" name="rangat" class="rangat">
               <input type="hidden" value="" name="listat" class="listat">
               <input type="hidden" value="" name="kokonaisalue" class="kokonaisalue">
               <input type="hidden" value="" name="levytettava_alue" class="levytettava_alue">
               <input type="hidden" value="" name="poisjaava_alue" class="poisjaava_alue">
               <input type="hidden" value="" name="keskusmittapiste_cord" class="keskusmittapiste_cord">
               <input type="hidden" value="" name="reklamaatiot" class="reklamaatiot"> -->
               <section>
                 
                 <section class="levy_settings">
                   <!-- <h2>Levyasetukset</h2> -->
                   <div class="row">
                     <div class="col-6">
                       <h2>Pituus</h2>
                     </div>
                     <div class="col-6">
                       <h2>Leveys</h2>
                     </div>
                   </div>
                   <section class="trow">
                      <h4>Levyjen mitat</h4>
                      <fieldset>
                        <div class="modal__row"> <!-- Levyn maksimipituus -->
                         <label for="settings__levy_levysizeh"></label>
                        <input type="text" id="k_settings__levy_levysizeh" placeholder="Tavoiteltu levyn pituus" value="">  <!-- Levyn maksimileveys -->
                         <label for="settings__levy_levysizew"></label>
                         <input type="text" id="k_settings__levy_levysizew" placeholder="Tavoiteltu levyn leveys" value="">
                       </div>
                      </fieldset>
                      <div class="row">
                        <div class="col-6">
                          <h4>Pituussuunnan Läpiviennit</h4>
                          <fieldset>
                            <div class="trow">
                             <div class="modal__row_kvali">
                               <label for="p_target">K-väli, Tavoite </label>
                               <input type="number" id="p_target" placeholder="Tavoiteltu levyn pituus" min="570" value="600">
                             </div>
                             <div class="modal__row_kvali">
                               <label for="p_two">2 reikää max väl</label>
                               <input type="number" id="p_two" placeholder="Tavoiteltu levyn leveys" min="570" value="570" placeholder="0-570">
                             </div>
                             <div class="modal__row_kvali">
                               <label for="p_three">3 reikää max väl</label>
                               <input type="number" id="p_three" placeholder="Tavoiteltu levyn leveys" min="580" value="580" placeholder="580-3050">
                             </div>
                           </div>
                          </fieldset>
                        </div>
                        <div class="col-6">
                          <h4>Leveyssuunnan Läpiviennit </h4>
                          <fieldset>
                            <div class="trow">
                             <div class="modal__row_kvali">
                               <label for="v_target">K-väli, Tavoite </label>
                               <input type="number" id="v_target" placeholder="Tavoiteltu levyn pituus" min="450" value="600">
                             </div>
                             <div class="modal__row_kvali">
                               <label for="v_two">2 reikää max väl</label>
                               <input type="number" id="v_two" placeholder="Tavoiteltu levyn leveys" min="450" value="450">
                             </div>
                             <div class="modal__row_kvali">
                               <label for="v_three">3 reikää max väl</label>
                               <input type="number" id="v_three" placeholder="Tavoiteltu levyn leveys" min="450" value="550">
                             </div>
                           </div>
                          </fieldset>
                        </div>
                      </div>
                      
                      
                   </section>

                  <!--  <section>
                     <h3></h3>
                     <fieldset>
                       <div class="modal__row">
                         <input type="text">
                         <label for=""></label>
                         <input type="text">
                         <label for=""></label>
                         <input type="text">
                         <label for=""></label>
                       </div>
                     </fieldset>
                   </section> -->
                   <section>
                     
                     <h3>Reuna asetukset:</h3>
                     <div class="row poraukset" style="height: 200px">
                       <div class="col-2 trow">
                         <h4>arvo</h4>
                         <h4>min</h4>
                         <h4>max</h4>
                       </div>
                       <div class="col-8 row poraukset"  style="height: 200px">
                         <div class="col-6 trow ">
                           <div class="row">
                             <div class="col-6"><h4>Yläreunasta</h4></div>
                             <div class="col-6"><h4>Alareunasta:</h4></div>
                           </div>
                           <div class="row"> 
                             <div class="col-6">
                               <input type="number" id="settings__levy_yr_arvo" placeholder="Poraus etäisyys arvo" min="25" max="80" value="32.5" min="20" max="80">
                             </div>
                             <div class="col-6">
                               <input type="number" id="settings__levy_ar_arvo" placeholder="Poraus etäisyys arvo" min="25" max="80" value="32.5" min="20" max="80">
                             </div>
                           </div>
                           <div class="row">
                             <div class="col-6">
                               <input type="number" id="settings__levy_yr_min" placeholder="Poraus etäisyys min" min="25" value="25">
                             </div> 
                             <div class="col-6">
                               <input type="number" id="settings__levy_ar_min" placeholder="Poraus etäisyys min" min="25" value="25">
                             </div>
                           </div>
                           <div class="row">
                             <div class="col-6">
                               <input type="number" id="settings__levy_yr_max" placeholder="Poraus etäisyys max" min="25" value="80">
                             </div> 
                             <div class="col-6">
                               <input type="number" id="settings__levy_ar_max" placeholder="Poraus etäisyys max" min="25" value="80">
                             </div>
                           </div>
                         </div>
                         <div class="col-6 trow">
                           <div class="row">
                             <div class="col-6"><h4>Sivusta vas:</h4></div>
                             <div class="col-6"><h4>Sivusta oik:</h4></div>
                           </div>
                           <div class="row">
                             <div class="col-6"><input type="number" id="settings__levy_vr_arvo" placeholder="Poraus etäisyys arvo" min="25" max="80" value="32.5" min="20" max="80"></div>
                             <div class="col-6"><input type="number" id="settings__levy_or_arvo" placeholder="Poraus etäisyys arvo" min="25" max="80" value="32.5" min="20" max="80"></div>
                           </div>
                           <div class="row">
                             <div class="col-6"><input type="number" id="settings__levy_vr_min" placeholder="Poraus etäisyys min" min="25" value="25"> </div>
                             <div class="col-6"><input type="number" id="settings__levy_or_min" placeholder="Poraus etäisyys min" min="25" value="25"> </div>
                           </div>
                           <div class="row">
                             <div class="col-6"><input type="number" id="settings__levy_vr_max" placeholder="Poraus etäisyys max" min="25" value="80"> </div>
                             <div class="col-6"><input type="number" id="settings__levy_or_max" placeholder="Poraus etäisyys max" min="25" value="80"></div>
                           </div>
                         </div>
                       </div>
                     </div>
                     
                     
                   </section>

                   <section>
                      
                       <fieldset class="kiinniketys">
                         <div class="row">
                           <div class="col-6 trow">
                             <input type="checkbox" id="kiinniketys__pkiinnike_one" name="levy_porautus" value="Häntä vasen" checked>
                             <label for="kiinniketys__pkiinnike_one">Häntä vasen</label>
                             <input type="checkbox" id="kiinniketys__pkiinnike_two" name="levy_porautus" value="Häntä oikea">
                             <label for="kiinniketys__pkiinnike_two">Häntä oikea</label>

                             
                             <input type="checkbox" id="kiinniketys__pkiinnike_three" name="levy_porautus" value="Tasamalli">
                             <label for="kiinniketys__pkiinnike_three">Tasamalli pysty </label>
                             <input type="checkbox" id="kiinniketys__pkiinnike_four" name="levy_porautus" value="Pariton tasa">
                             <label for="kiinniketys__pkiinnike_four">Pariton tasa pysty</label>
                           </div>
                           <div class="col-6 trow">
                            <input type="checkbox" id="kiinniketys__vkiinnike_one" name="levy_porautus" value="Häntä ylä" checked>
                             <label for="kiinniketys__vkiinnike_one">Häntä ylä</label>
                             <input type="checkbox" id="kiinniketys__vkiinnike_two" name="levy_porautus" value="Häntä ala">
                             <label for="kiinniketys__vkiinnike_two">Häntä ala</label>
                             <input type="checkbox" id="kiinniketys__vkiinnike_three" name="levy_porautus" value="Tasamalli">
                             <label for="kiinniketys__vkiinnike_three">Tasamalli vaaka</label>
                             <input type="checkbox" id="kiinniketys__vkiinnike_four" name="levy_porautus" value="Pariton tasa">
                             <label for="kiinniketys__vkiinnike_four">Pariton tasa vaaka</label>
                           </div>
                         </div>
                         
                         


                         
                       </fieldset>
                   </section>
                  
                   

                   <section>

                     <!-- <h4>Ruuvien etäisyydet</h4>
                     <table>
                       <tr>
                         <td>MOD</td>
                         <td><input type="text" name="mod_interval" value="37.5" class="lineinput drawarea__mm mod_interval"></td>
                         <td><input type="text" name="mod_interval" value="37.5" class="lineinput drawarea__mm mod_interval"></td>
                       </tr> -->
                       <?php 
                         // $i = intdiv($v[1]/37); 
                         // $mainnum = intdiv($v[1], 37.5); 

                         // function is_decimal( $val ) {
                         //     return is_numeric( $val ) && floor( $val ) != $val;
                         // }

                         // echo $mainnum . "kpl 37,5mm väliä";

                         // $lenght = strlen( $v[1] );
                         // $lastnumbs = $v[1][$lenght-2] . $v[1][$lenght-1];
                         // $half = intdiv($v[1], 2);
                         // $half_2 = $half;
                         // $half_2 +=25;

                         // echo "<tr>";
                         // if($lastnumbs == 75 || $lastnumbs == 25) {
                         //   echo "<td>".$v[1]."</td>"."<td>" .$half . "</td>". "<td>" . $half . "</td>";
                         // }
                         // if($lastnumbs == 50 || $lastnumbs == 00) {
                         //   echo "<td>".$v[1]."</td>"."<td>" . $half_2 . "</td>" . "<td>" . $half . "</td>";
                         // }
                         // echo "</tr>";

                        
                         // $bb = 0.5; 

                        
                       ?>
                     <!-- </table> -->
                     <!-- <div class="drawarea__controls_btn drawarea__controls_btn_" onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_esikatselu');" style="margin-top: auto;">Esikatsele muutokset</div> -->
                     
                   </section>
                  
                 </section>
               </section>

               
            </div>
          </div>
        <div class="modal_close_btn drawarea__controls_btn" onclick="open_ladonta_settings(false)">Tallenna</div>
        
      </div>
      </div>
   </div>
</form>