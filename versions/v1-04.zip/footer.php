  <script src='https://cdnjs.cloudflare.com/ajax/libs/p5.js/1.4.0/p5.min.js'></script>
  <script  src="js/script.js"></script>
  <script src="js/roller.js"></script>
  <script src="js/roller_1.js"></script>
  <script src="js/roller_2.js"></script>
  <script src="js/roller_3.js"></script>

  <script>

    function changeColor() {
      var height = document.querySelector('#drawarea_h').value;
      var width = document.querySelector('#drawarea_w').value;

      document.querySelector("#canvas").style.height = height/10 + "px";
      document.querySelector("#canvas").style.width = width/10 + "px";

      document.querySelector('#box-wrapper').style.height = height/10 + "px";
      document.querySelector('#box-wrapper').style.width = width/10 + "px";

      document.querySelector('#box_h').value = height;
      document.querySelector('#box_w').value = width;
    }
    
  </script>
</body>
</html>
