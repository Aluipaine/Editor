<!DOCTYPE html>
<html lang="fi" >
<head>
  <meta charset="UTF-8">
  <title>WF työmaaeditori</title>
  <link rel="stylesheet" href="./style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>