var box_right = document.getElementById("box_right");
var boxWrapper = document.getElementById("box-wrapper");

var r_initX, r_initY, r_mousePressX, r_mousePressY, r_initW, r_initH, r_initRotate;

function r_repositionElement(x, y) {
    boxWrapper.style.left = x;
    boxWrapper.style.top = y;
}

function r_resize(w, h) {
    box_right.style.width = w + 'px';
    box_right.style.height = h + 'px';

    boxWrapper.style.width = w;
    boxWrapper.style.height = h;
}




// handle r_resize
var bottomMid = document.getElementById("box_right__left-mid");

function r_resizeHandler(event, left = false, top = false, xr_resize = false, yr_resize = false) {
    r_initX = boxWrapper.offsetLeft;
    r_initY = boxWrapper.offsetTop;
    r_mousePressX = event.clientX;
    r_mousePressY = event.clientY;

    r_initW = box_right.offsetWidth;
    r_initH = box_right.offsetHeight;

    function eventMoveHandler(event) {
        var wDiff = event.clientX - r_mousePressX;
        var hDiff = event.clientY - r_mousePressY;

        var newW = r_initW, newH = r_initH, newX = r_initX, newY = r_initY;

        if (xr_resize) {
            if (left) {
                newW = r_initW - wDiff;
                newX = r_initX + wDiff;
            } else {
                newW = r_initW + wDiff;
            }
        }

        if (yr_resize) {
            if (top) {
                newH = r_initH - hDiff;
                newY = r_initY + hDiff;
            } else {
                newH = r_initH + hDiff;
            }
        }

        r_resize(newW, newH);
        r_repositionElement(newX, newY);
    }

    window.addEventListener('mousemove', eventMoveHandler, false);

    window.addEventListener('mouseup', function () {
        window.removeEventListener('mousemove', eventMoveHandler, false);
    }, false);
}


bottomMid.addEventListener('mousedown', e => r_resizeHandler(e, true, false, true, false));