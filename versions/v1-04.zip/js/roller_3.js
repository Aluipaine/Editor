var box_left = document.getElementById("box_left");
var boxWrapper = document.getElementById("box-wrapper");

var left_initX, left_initY, left_mousePressX, left_mousePressY, left_initW, left_initH, left_initRotate;

function left_repositionElement(x, y) {
    boxWrapper.style.left = x;
    boxWrapper.style.top = y;
}

function left_resize(w, h) {
    box_left.style.width = w + 'px';
    box_left.style.height = h + 'px';

    boxWrapper.style.width = w;
    boxWrapper.style.height = h;
}




// handle left_resize
var bottomMid = document.getElementById("box_left__right-mid");

function left_resizeHandler(event, left = false, top = false, xleft_resize = false, yleft_resize = false) {
    left_initX = boxWrapper.offsetLeft;
    left_initY = boxWrapper.offsetTop;
    left_mousePressX = event.clientX;
    left_mousePressY = event.clientY;

    left_initW = box_left.offsetWidth;
    left_initH = box_left.offsetHeight;

    function eventMoveHandler(event) {
        var wDiff = event.clientX - left_mousePressX;
        var hDiff = event.clientY - left_mousePressY;

        var newW = left_initW, newH = left_initH, newX = left_initX, newY = left_initY;

        if (xleft_resize) {
            if (left) {
                newW = left_initW - wDiff;
                newX = left_initX + wDiff;
            } else {
                newW = left_initW + wDiff;
            }
        }

        if (yleft_resize) {
            if (top) {
                newH = left_initH - hDiff;
                newY = left_initY + hDiff;
            } else {
                newH = left_initH + hDiff;
            }
        }

        left_resize(newW, newH);
        left_repositionElement(newX, newY);
    }

    window.addEventListener('mousemove', eventMoveHandler, false);

    window.addEventListener('mouseup', function () {
        window.removeEventListener('mousemove', eventMoveHandler, false);
    }, false);
}


bottomMid.addEventListener('mousedown', e => left_resizeHandler(e, false, false, true, false));