var box_lower = document.getElementById("box_lower");
var boxWrapper = document.getElementById("box-wrapper");

var l_initX, l_initY, l_mousePressX, l_mousePressY, l_initW, l_initH, l_initRotate;

function l_repositionElement(x, y) {
    boxWrapper.style.left = x;
    boxWrapper.style.top = y;
}

function l_resize(w, h) {
    box_lower.style.width = w + 'px';
    box_lower.style.height = h + 'px';

    boxWrapper.style.width = w;
    boxWrapper.style.height = h;
}




// handle l_resize
var bottomMid = document.getElementById("box_lower__top-mid");

function l_resizeHandler(event, left = false, top = false, xl_resize = false, yl_resize = false) {
    l_initX = boxWrapper.offsetLeft;
    l_initY = boxWrapper.offsetTop;
    l_mousePressX = event.clientX;
    l_mousePressY = event.clientY;

    l_initW = box_lower.offsetWidth;
    l_initH = box_lower.offsetHeight;

    function eventMoveHandler(event) {
        var wDiff = event.clientX - l_mousePressX;
        var hDiff = event.clientY - l_mousePressY;

        var newW = l_initW, newH = l_initH, newX = l_initX, newY = l_initY;

        if (xl_resize) {
            if (left) {
                newW = l_initW - wDiff;
                newX = l_initX + wDiff;
            } else {
                newW = l_initW + wDiff;
            }
        }

        if (yl_resize) {
            if (top) {
                newH = l_initH - hDiff;
                newY = l_initY + hDiff;
            } else {
                newH = l_initH + hDiff;
            }
        }

        l_resize(newW, newH);
        l_repositionElement(newX, newY);
    }

    window.addEventListener('mousemove', eventMoveHandler, false);

    window.addEventListener('mouseup', function () {
        window.removeEventListener('mousemove', eventMoveHandler, false);
    }, false);
}


bottomMid.addEventListener('mousedown', e => l_resizeHandler(e, false, true, false, true));