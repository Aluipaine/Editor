
<section class="step_screen drawscreen_section form__butsection" id="drawscreen_section_six">

    <!-- <input type="hidden" value="drawscreen_section_six" name="step" class="step">
    <input type="hidden" value="" name="wall" class="wall">
    <input type="hidden" value="" name="room" class="room">
    <input type="hidden" value="" name="id" class="id">
    <input type="hidden" value="" name="settings" class="settings">
    <input type="hidden" value="" name="mittapisteet" class="mittapisteet">
    <input type="hidden" value="" name="aukot" class="aukot">
    <input type="hidden" value="" name="reijat" class="reijat">
    <input type="hidden" value="" name="saumat" class="saumat">
    <input type="hidden" value="" name="levyt" class="levyt">
    <input type="hidden" value="" name="rangat" class="rangat">
    <input type="hidden" value="" name="listat" class="listat">
    <input type="hidden" value="" name="kokonaisalue" class="kokonaisalue">
    <input type="hidden" value="" name="levytettava_alue" class="levytettava_alue">
    <input type="hidden" value="" name="poisjaava_alue" class="poisjaava_alue">
    <input type="hidden" value="" name="keskusmittapiste_cord" class="keskusmittapiste_cord">
    <input type="hidden" value="" name="reklamaatiot" class="reklamaatiot"> -->
    <section class="nav">
      <nav>
        <ul>

         <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_five');">Edellinen</div></li>
           <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_one');" class="nav__comleted">Origo</div></li>
          <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_two');" class="nav__comleted">Aukot</div></li>
          <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_three');" class="nav__comleted">Reijät</div></li>
          <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_four');" class="nav__comleted">Saumat</div></li>
          <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_five');" class="nav__comleted">Levyt</div></li>
          <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_tyostot');" class="nav__comleted">Kiinnitykset</div></li>
          <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_esikatselu');" class="nav__comleted">Esikatselu</div></li>
          <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_six');" class="nav_current">Rangat</div></li>
          <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_seven');">Listat</div></li>
          <li><div onclick="refresh__drawcontrols();updatearea();$('#step_drawscreen').val('drawscreen_section_seven');">Seuraava</div></li>

      </nav>

    </section>
    <section class="excel">
     <!-- Set for input default center coords  -->
      <table>
        <tr>
          <td>Type (drawing)</td>
          <td>Materialcode</td>
          <td>Pituus (X)</td>
          <td>Leveys (Y)</td>
          <td>Thickness</td>
          <td>Structure</td>
          <td>Quantity</td>
          <td>Plus</td>
          <td>Part number</td>
          <td>Nimi 1</td>
          <td>Nimi 2</td>
          <td>MPR</td>
          <td>Palletgroup</td>
          <td>Prioriteetti</td>
          <td>Asiakas</td>
          <td>Asennus</td>
          <td>Työstöt</td>
          <td></td>
          <td>X KPL</td>
          <td>Y KPL</td>
          <td>Yhteensä</td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td>Tarra</td>
          <td>Diameter</td>
          <td>X1</td>
          <td>X2</td>
          <td>X3</td>
          <td>X4</td>
          <td>X5</td>
          <td>X6</td>
          <td>X7</td>
          <td>X8</td>
          <td>X9</td>
          <td>X10</td>
          <td>Y1</td>
          <td>Y2</td>
          <td>Y3</td>
          <td>Y4</td>
          <td>Y4</td>
          <td>Y6</td>
          <td>Y7</td>
          <td>Y8</td>
          <td>Y9</td>
          <td>Y10</td>
          <td>X</td>
          <td>Y</td>
          <td>X</td>
          <td>Y</td>
          <td>PR1_X</td>
          <td>PR1_Y</td>
          <td>PR1_DX</td>
          <td>PR1_DY</td>
          <td>PR2_X</td>
          <td>PR2_Y</td>
          <td>PR1_DX</td>
          <td>PR2_DY</td>
          <td>PR3_X</td>
          <td>PR3_Y</td>
          <td>PR3_DX</td>
          <td>PR3_DY</td>
          <td>PR4_X</td>
          <td>PR4_Y</td>
          <td>PR4_DX</td>
          <td>PR4_DY</td>
          <td>PF1_X</td>
          <td>PF1_Y</td>
          <td>PF1_DX</td>
          <td>PF1_DY</td>
          <td>PF2_X</td>
          <td>PF2_Y</td>
          <td>PF2_DX</td>
          <td>PF2_DY</td>
          <td>CH 0=OFF 1= ON</td>
          <td>Y Vasen</td>
          <td>Y oikea</td>
          <td>Y Vasen</td>
          <td>Y oikea</td>
          <td>X ala</td>
          <td>x ylä</td>
          <td>X ala</td>
          <td>X ylä</td>
          <td>WH1_X</td>
          <td>VH1_Y</td>
          <td>VH1_L</td>
          <td>VH1_KPL</td>
          <td>VH1_K</td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td>AR Edge 1</td>
          <td>YR Edge 1</td>
          <td>VR Edge 1</td>
          <td>OR Edge 1</td>
          <td>AR Edge 2</td>
          <td>YR Edge 2</td>
          <td>VR Edge 2</td>
          <td>OR Edge 2</td>
          <td>AR Trim</td>
          <td>YR Trim</td>
          <td>VR Trim</td>
          <td>OR Trim</td>
          <td>Yhdistä Xx-XX</td>
          <td>Yhdistä Yx-YX</td>
        </tr>

      </table>

      <button class="get_excel">Lataa Excel</button>
      </section>

  <div class="modal-container">
   <div class="modal-background">
     <div class="modal">
        <div class="modal_close_btn"><svg width="20" height="18" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20 1.87367L17.9857 0.0703049L10 7.21983L2.01429 0.0703049L0 1.87367L7.98572 9.0232L0 16.1727L2.01429 17.9761L10 10.8266L17.9857 17.9761L20 16.1727L12.0143 9.0232L20 1.87367Z" fill="#444444"/></svg></div>
        <h2>Ranka-asetukset</h2>
        <section>
          <h4>Suunta</h4>
          <fieldset>
            <label for="settings__sauma_levysizeh">Tavoiteltu levyn pituus</label>
              <input type="number" id="settings__sauma_levysizeh" placeholder="Tavoiteltu levyn pituus" min="0">
              <label for="settings__sauma_levysizew">Tavoiteltu levyn leveys</label>
              <input type="number" id="settings__sauma_levysizew" placeholder="Tavoiteltu levyn leveys" min="0">
          </fieldset>
        </section>
       <div class="modal_close_btn drawarea__controls_btn" onclick="">Rangoita</div>
     </div>
   </div>
  </div>


</section>


